#!/bin/bash
export LANG='en_US'

# ETL-Framework 框架输入的参数为
# {DAY} {HOUR} {MIN} {WORK_PATH} {HADOOP_HOME} {LIB_JARS_PATH} {JOB_NAME} {queue_name} {username,password} {zk_path}
#   1     2      3       4           5               6             7          8              9                10
#-----------------------------------------------conf begin-------------------------------------------
DAY=${1}
HOUR=${2}
JOB_WORK_PATH=${4}
HADOOP_HOME=${5}
JAVA_HOME="${HADOOP_HOME}/../java6"
LIB_DIR="${6}/../lib.new"
JOB_NAME=${7}
QUEUE_NAME=${8}
HADOOP_UGI=${9}
PAPI_META=${10}

cd $JOB_WORK_PATH/bin
echo $JOB_WORK_PATH
tar xf idmapping_ip_label.tar

################################################################################
# conf begin
DAYS_NUM=30
MAX_FILE_NUM=3
OUTPUT_DIR='/app/dt/udw/idmapping/ip_label'
# conf end

LAST_DAY=${DAY}
DAYS=${LAST_DAY}
for ((i=1;i<${DAYS_NUM};i++));do
    LAST_DAY=`date +%Y%m%d -d ${LAST_DAY}' 1 day ago'`
    DAYS=${LAST_DAY}','${DAYS}
done
DAYS={${DAYS}}
echo ${DAYS}

READ_META=${PAPI_META}
WRITE_META=${PAPI_META}

INPUT_PROJECT="udw_id_attribute_delta.event_day=${DAYS}.is_topid=0"
INPUT_COLS="id_type,id,ip_attr_0,product_clienttype_attr,event_day"
INPUT_INFO_FILE="papi_info_file"

for jar in ${LIB_DIR}/*.jar ; do
    HADOOP_CLASSPATH=$HADOOP_CLASSPATH:$jar
done
export HADOOP_CLASSPATH
echo ${LIB_DIR}

code=253
while [ $code -eq 253 ]; do
${JAVA_HOME}/bin/java -jar ${LIB_DIR}/udw-program-api.jar GetJobInfo \
    -server ${READ_META} \
    -user "InternalUser" \
    -inputProj ${INPUT_PROJECT} \
    -inputCols ${INPUT_COLS} \
    -checkPoint "event_day=${DAYS}.is_topid=0" \
    -ifile ${INPUT_INFO_FILE}

    code=$?
    echo $code
    if [ $code -eq 253 ]; then
        echo "WARN: papi checkPoint ${DAYS} table not ready, sleep 30 min"
        sleep 30m
    fi;
done

echo "papi checkPoint ${DAYS} data ready, OK"
echo `(date)`

${JAVA_HOME}/bin/java -jar ${LIB_DIR}/udw-program-api.jar GetJobInfo \
    -server ${READ_META} \
    -user "InternalUser" \
    -inputProj ${INPUT_PROJECT} \
    -inputCols ${INPUT_COLS} \
    -ifile ${INPUT_INFO_FILE}

if [ $? -ne 0 ];then
    echo "Getting Input Job Info fails"
    exit 1
fi
echo `(date)`

echo "papi GetJobInfo OK"

OUTPUT_DIR="/app/dt/udw/idmapping/ip_label/${DAY}"
${HADOOP_HOME}/bin/hadoop fs -rmr ${OUTPUT_DIR}

INPUT_DIR=${INPUT_INFO_FILE}  
LIB_JARS=""
for jar in ${LIB_DIR}/*.jar; do
    if [ -z $LIB_JARS ]; then
        LIB_JARS="${jar}"
    else LIB_JARS="${LIB_JARS},${jar}";
    fi
done

echo "jars:" $LIB_JARS
${HADOOP_HOME}/bin/hadoop bistreaming -libjars ${LIB_JARS} \
    -D hadoop.job.ugi="${HADOOP_UGI}" \
    -D udw.mapred.input.info=${INPUT_INFO_FILE} \
    -D mapred.map.tasks=10000 \
    -D mapred.reduce.tasks=3000 \
    -D mapred.job.map.capacity=10000 \
    -D mapred.job.reduce.capacity=3000 \
    -D abaci.appmaster.memory.min.mb=1000 \
    -D abaci.job.map.child.memory.mb=3000 \
    -D udw.mapred.streaming.separator=0x0 \
    -D child.max.memory=3000 \
    -D stream.memory.limit=2000 \
    -D mapred.job.priority=NORMAL \
    -D udw.mapred.combine.inputformat=true \
    -D mapred.job.name="${JOB_NAME}" \
    -input ${INPUT_DIR} \
    -output ${OUTPUT_DIR} \
    -inputformat com.baidu.udw.mapred.MultiTableInputFormat \
    -outputformat org.apache.hadoop.mapred.TextOutputFormat \
    -mapper 'bash map_task.sh' \
    -reducer 'bash reduce_task.sh' \
    -jobconf abaci.is.dag.job=true \
    -jobconf abaci.dag.vertex.num=3 \
    -jobconf abaci.dag.next.vertex.list.0=1 \
    -jobconf abaci.dag.next.vertex.list.1=2 \
    -jobconf stream.reduce.streamprocessor.2="cat" \
    -jobconf mapred.reduce.tasks.2=1 \
    -file ./output/bin/mapred.py \
    -file ./output/bin/pybistreaming.py \
    -file ./output/bin/map_task.sh \
    -file ./output/bin/reduce_task.sh \
    -cacheFile hdfs://szwg-lu-hdfs.dmop.baidu.com:54310/app/dt/udw/idmapping/tar/python2.7.tar#python2.7.tar \
    -file ./${INPUT_INFO_FILE} \

err=$?
if [ $err -ne 0 ];then
    echo "M/R Job 1 Info fails, error:" $err
    exit 1
fi
echo `(date)`

# keep MAX_FILE_NUM latest files
MAX_FILE_NUM=3
OUTPUT_DIR='/app/dt/udw/idmapping/ip_label'
FILE_NUM=`${HADOOP_HOME}/bin/hadoop fs -ls ${OUTPUT_DIR} | wc -l`
# hdfs fs 1 more line
let MAX_FILE_NUM=MAX_FILE_NUM+1
if [ ${FILE_NUM} -gt ${MAX_FILE_NUM} ];then
TO_DELETE=`${HADOOP_HOME}/bin/hadoop fs -ls ${OUTPUT_DIR} | awk '{if (FNR!=1) print $8}' | sort | head -1`
${HADOOP_HOME}/bin/hadoop fs -rmr ${TO_DELETE}
fi

cd -
echo "~~~job sucessful~~~"
