// Copyright 2014, Baidu Inc. All rights reserved.
// Author: yeyue(@baidu.com)

#include <iostream>  // NOLINT
#include <string>
#include <vector>
#include <time.h>
#include <cstdlib>
#include <cstring>

#include "thirdparty/boost/algorithm/string.hpp"
#include "thirdparty/boost/lexical_cast.hpp"
#include "thirdparty/glog/logging.h"
#include "toft/storage/file/hdfs_file.h"
#include "wing/frontend/cquery/cquery.h"
#include "wing/frontend/default_aggregate_functions.h"
#include "wing/frontend/function_container.h"
#include "wing/frontend/hive_udf_resolver.h"
#include "wing/ir/proto/type_info.pb.h"
#include "wing/storage/proto/storage.pb.h"

#include "shengong/etl/utils/cquery_basetime_parser.h"

using baidu::shengong::etl::BaseTimeParser;
using baidu::wing::frontend::cquery::CQuery;
using baidu::wing::frontend::Table;

// hdfs path where f_file's columns info is stored
static const char* f_file =
        "/hdfs/nmg01-shengong-hdfs.dmop.baidu.com:54310?username=shengong,password=shengong"
        "/app/shengong/goldwind/event/dim_gw_b/partition_product=gw/f";

namespace {

int gen_f_select_str(const char* path, std::string* fvalue_select_str, std::string* f_select_str) {
    std::vector<std::string> lines;
    CHECK(toft::File::ReadLines(f_file, &lines)) << "Error: error reading dim table.";
    *f_select_str = "wf_id,eq_id,date_time";
    *fvalue_select_str = "wf_id,eq_id,date_time";
    for (size_t i = 0; i < lines.size(); i++) {
        std::vector<std::string> columns;
        boost::split(columns, lines[i], boost::is_any_of("\001"));
        // columns[4] is column name, columns[9] is sample text
        // get column type by sample text
        try {
            double value = boost::lexical_cast<double>(columns[9]);
            *f_select_str += ",coalesce(" + columns[4] + ",-888888.0)";
        } catch(boost::bad_lexical_cast& e) {
            *f_select_str += ",coalesce(" + columns[4] + ",'')";
        }
        *fvalue_select_str += ",fvalues['" + columns[4] + "'] as " + columns[4];
    }
    return 0;
}

} // namespace

int main(int argc, char** argv) {
    CQuery::Init(argc, argv);
    baidu::wing::frontend::HiveUdfResolver::Instance()->AddHiveBuiltinUdfs();
    CQuery::SetConf("hadoop.job.ugi",           "shengong,shengong");
    CQuery::SetConf("fs.default.name",          "hdfs://nmg01-shengong-hdfs.dmop.baidu.com:54310");
    CQuery::SetConf("udw.metastore.zk.server",  "nmg01-shengong-zk.dmop.baidu.com:2181");
    CQuery::SetConf("udw.metastore.zk.path",    "/shengong/metaui");

    BaseTimeParser base_time_parser(getenv("BASETIME"));

    Table gw_ods_f = Table::LoadMetaTable("udw.default.gw_ods_f");
    Table gw_ods_equipment_info = Table::LoadMetaTable("udw.default.dim_gw_equipment");
    Table gw_ods_windfarm_info = Table::LoadMetaTable("udw.default.gw_ods_dim_scadaapp_windfarm");
    Table eq = gw_ods_equipment_info->RenameWithPrefix("equipment_info");
    Table wf = gw_ods_windfarm_info->RenameWithPrefix("windfarm_info");
    std::string output_table_name = "udw.default.gw_dwd_f";
    std::string f_select_str, fvalue_select_str;
    const std::string eq_select_str = "coalesce(equipment_info_protocol_id,'') as protocol_id,"
                                      "coalesce(equipment_info_preadapter_id,'') as preadapter_id,"
                                      "coalesce(equipment_info_eq_name,'') as eq_name,"
                                      "coalesce(equipment_info_eq_x,'') as eq_x,"
                                      "coalesce(equipment_info_eq_y,'') as eq_y,"
                                      "coalesce(equipment_info_eq_comment,'') as eq_comment,"
                                      "coalesce(equipment_info_eq_type,'') as eq_type,"
                                      "coalesce(equipment_info_online_date,'') as online_date,"
                                      "coalesce(equipment_info_eq_row,'') as eq_row,"
                                      "coalesce(equipment_info_eq_col,'') as eq_col";
    const std::string wf_select_str = "coalesce(windfarm_info_wf_name,'') as wf_name,"
                                      "coalesce(windfarm_info_wf_invest_name,'') as wf_invest_name,"
                                      "coalesce(windfarm_info_wf_capacity,0) as wf_capacity,"
                                      "coalesce(windfarm_info_wf_amount,0) as wf_amount,"
                                      "coalesce(windfarm_info_wf_address,'') as wf_address,"
                                      "coalesce(windfarm_info_wf_principle,'') as wf_principle,"
                                      "coalesce(windfarm_info_wf_linkman,'') as wf_linkman,"
                                      "coalesce(windfarm_info_wf_linkphone,'') as wf_linkphone,"
                                      "coalesce(windfarm_info_wf_linkemail,'') as wf_linkemail,"
                                      "coalesce(windfarm_info_wf_comment,'') as wf_comment,"
                                      "coalesce(windfarm_info_wf_map_imgname,'') as wf_map_imgname,"
                                      "coalesce(windfarm_info_wf_x,-888888.0) as wf_x,"
                                      "coalesce(windfarm_info_wf_y,-888888.0) as wf_y,"
                                      "coalesce(windfarm_info_wf_province_id,'') as wf_province_id,"
                                      "coalesce(windfarm_info_wf_height,-888888.0) as wf_height,"
                                      "coalesce(windfarm_info_wf_dept_id,'') as wf_dept_id";

    gen_f_select_str(f_file, &fvalue_select_str, &f_select_str);
    Table gw_dwd_f_join_eq = gw_ods_f
        ->Filter("partition_day=='" + base_time_parser.GetEventDay() + "' and partition_hour=='" + base_time_parser.GetEventHour() + "'")
        // select fvalues,partition_day,partition_hour from gw_ods_f
        ->Select(fvalue_select_str + ",partition_day,partition_hour")
        ->LeftJoin(eq, "eq_id == equipment_info_eq_id and wf_id == equipment_info_wf_id")
        ->LeftJoin(wf, "wf_id == windfarm_info_wf_id")
        // select equipment and windfarm info from the two dim tables
        ->Select(f_select_str + "," + eq_select_str + "," + wf_select_str + ",partition_day,partition_hour");

    std::vector<std::pair<std::string, std::string> > parts;
    parts.push_back(std::make_pair("partition_day", base_time_parser.GetEventDay()));
    parts.push_back(std::make_pair("partition_hour", base_time_parser.GetEventHour()));
    parts.push_back(std::make_pair("partition_product", "gw"));

    gw_dwd_f_join_eq->OutputOverwriteTable(output_table_name, parts, std::vector<std::string>());

    std::string error_message;
    int error_code = CQuery::Run(&error_message);
    if (error_code != 0) {
        std::cerr << "Error: " << error_message << std::endl;
    }
    return error_code;
}
