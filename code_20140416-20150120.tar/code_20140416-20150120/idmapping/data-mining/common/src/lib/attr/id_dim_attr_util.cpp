// Copyright 2014, Baidu Inc.
// Author: yeyue <yeyue@baidu.com>

#include "id_dim_attr_util.h"

namespace bdg {
namespace udw {
namespace mining {

int format_time_by_interval(int interval, int* timestamp) {
    if (interval <= 0) {
        return -1;
    }
    int std_time = *timestamp + (8*60*60);
    interval *= 60;
    *timestamp = (std_time / interval) * interval - (8*60*60);
    return 0;
}

int timestamp2str(int timestamp, std::string* time_str) {
    struct tm *p;
    time_t timep = timestamp;
    p = localtime(&timep);
    char temp_time[25];
    if (p != NULL) {
        int time_res = strftime(temp_time, 20, "%Y%m%d%H%M", p);
        if (time_res != 0) {
            time_str->assign(temp_time);
            return 0;
        }
    }
    return -1;
}

}
}
}

