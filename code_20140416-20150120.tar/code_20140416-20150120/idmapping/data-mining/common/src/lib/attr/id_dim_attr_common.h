// Copyright 2014, Baidu Inc.
// Author: yeyue <yeyue@baidu.com>

#ifndef INF_BUDW_DATA_MINING_ID_DIM_ATTR_COMMON_H
#define INF_BUDW_DATA_MINING_ID_DIM_ATTR_COMMON_H
#include <vector>
#include <string>
#include "id_dim_attr.h"

namespace bdg {
namespace udw {
namespace mining {

enum Product {
    PROD_UNKNOWN = 0,
    PROD_BAIKE = 1,
    PROD_IKNOW = 2,
    PROD_LBS = 3,
    PROD_NOVA = 4,
    PROD_PS = 5,
    PROD_TIEBA = 6,
    PROD_WENKU = 7,
    PROD_WISE = 8,
};

int product_to_enum(const std::string &prod);

enum ClientType {
    CT_UNKNOWN = 0,
    CT_API = 1,
    CT_MOBILE_APP = 2,
    CT_PC_WEB = 3,
    CT_PC_CLIENT = 4,
    CT_PAD_WEB = 5,
    CT_PAD_APP = 6,
    CT_SDK = 7,
    CT_WAP_COMMON = 8,
    CT_WAP_SMART = 9,
};

int client_type_to_enum(const std::string &prod);

struct IdAttribute {
    std::string id;
    int type;
    IdAttr details;
};

//
struct IdAttrIndex {
    const static int TABLE_NAME = 0;
    const static int BUCKET_KEY = 1;
    const static int ID_TYPE = 2;
    const static int ID = 3;
    const static int IP_ATTR_0 = 4;
    const static int IP_ATTR_1 = 5;
    const static int IP_ATTR_2 = 6;
    const static int IP_ATTR_3 = 7;
    const static int IP_CITY = 8;
    const static int QUERY_TOPIC = 9;
    const static int PRODUCT_CLIENTTYPE_ATTR = 10;
    const static int PRODUCT_CLIENTTYPE_DETAIL = 11;
    const static int EVENT_DAY = 12;
    const static int IS_TOPID = 13;
    const static int BUCKETS = 14;
    const static int FRAGMENT = 15;
    const static int SIZE = 16;
};

struct IdAttrIndexV5 {
    const static int TABLE_NAME = 0;
    const static int BUCKET_KEY = 1;
    const static int ID_TYPE = 2;
    const static int ID = 3;
    const static int IP_ATTR_0 = 4;
    const static int IP_ATTR_1 = 5;
    const static int IP_ATTR_2 = 6;
    const static int IP_ATTR_3 = 7;
    const static int IP_CITY = 8;
    const static int QUERY_TOPIC = 9;
    const static int PRODUCT_CLIENTTYPE_ATTR = 10;
    const static int PRODUCT_CLIENTTYPE_DETAIL = 11;
    const static int QUERY_INFO = 12;
    const static int HOST_INFO = 13;
    const static int TIEBA_INFO = 14;
    const static int BUCKET_LIST = 15;
    const static int JOIN_KEY_0 = 16;
    const static int EVENT_DAY = 17;
    const static int IS_TOPID = 18;
    const static int BUCKETS = 19;
    const static int FRAGMENT = 20;
    const static int SIZE = 21;
};

/**
 * @brief udw_id_attribute_all 全体字段
 */
struct IdAttributeAllIndex {
    const static int TABLE_NAME = 0;
    const static int ID_TYPE = 1;
    const static int ID = 2;
    const static int IP_ATTR_0 = 3;
    const static int IP_ATTR_1 = 4;
    const static int IP_ATTR_2 = 5;
    const static int IP_ATTR_3 = 6;
    const static int IP_CITY = 7;
    const static int QUERY_TOPIC = 8;
    const static int PRODUCT_CLIENTTYPE_ATTR = 9;
    const static int PRODUCT_CLIENTTYPE_DETAIL = 10;
    const static int QUERY_INFO = 11;
    const static int HOST_INFO = 12;
    const static int TIEBA_INFO = 13;
    const static int BUCKET_LIST = 14;
    const static int JOIN_KEY_0 = 15;
    const static int EVENT_DAY = 16;
    const static int IS_TOPID = 17;
    const static int VER = 18;
    const static int SIZE = 19;
};

struct IpCityIndex {
    const static int IP = 0;
    const static int TIMESTAMP = 1;
    const static int CITY = 2;
    const static int WEIGHT = 3;
};

struct IpAttr0Index {
    const static int IP = 0;
    const static int TIMESTAMP = 1;
    const static int WEIGHT = 2;
    const static int IP_TAG = 3;
};

struct QueryTopicIndex {
    const static int TOPIC = 0;
};

struct ProductClienttypeAttrIndex {
    const static int PRODUCT = 0;
    const static int CLIENT_TYPE = 1;
    const static int WEIGHT = 2;
};

}
}
}

#endif
