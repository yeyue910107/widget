// Copyright 2014, Baidu Inc.
// Author: yeyue <yeyue@baidu.com>

#include <iostream>
#include <stdlib.h>
#include <cstdlib>
#include <ctype.h>
#include <set>
#include <utility>
#include <boost/algorithm/string.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include "id_dim_attr_common.h"
#include "id_dim_attr.h"
#include "id_dim_attr_util.h"
#include "udw_dm_utils.h"
#include "udw_dm_log.h"
#include "udw_idtype.h"
#include "log.h"

using std::string;
using std::vector;

namespace bdg {
namespace udw {
namespace mining {

int compute_single_attr_vector(
        int day_begin, 
        int day_end, 
        const std::string& raw_details, 
        const int column_index, 
        const int single_attr_index, 
        const int time_index,
        std::vector<std::string>* attr_set) {
    std::string column_str;
    std::vector<std::string> fields;
    std::vector<std::string> attr_fields;
    std::vector<std::string> tmp_set;

    attr_set->clear();
    parse_id_attr_details_to_string(raw_details, column_index, '\0',  column_str);
    if (column_str[0] != '[' || column_str[column_str.size() - 1] != ']') {
        return -1;
    }
    strsplit(column_str, '\"', &attr_fields);
    for (uint32_t i = 1; i < attr_fields.size(); i += 2) {
        fields.clear();
        strsplit(attr_fields[i], ',', &fields);
        if (single_attr_index < 0 || (size_t)single_attr_index >= fields.size()) {
            //UDW_DEBUG("fields out of index.");
            continue;
        }
        std::string single_attr = fields[single_attr_index];
        if (single_attr != "") {
            int timestamp = 0;
            if (time_index >= 0 && (size_t)time_index < fields.size()) {
                timestamp = atoi(fields[time_index].c_str());
            }
            if (timestamp >= day_begin && timestamp < day_end) {
                tmp_set.push_back(single_attr);
            }
        }
    }
    attr_set->resize(tmp_set.size());
    std::copy(tmp_set.begin(), tmp_set.end(), attr_set->begin());

    return 0;
}

int compute_single_attr_set(
        int day_begin, 
        int day_end, 
        const std::string& raw_details, 
        const int column_index, 
        const int single_attr_index, 
        const int time_index,
        std::vector<std::string>* attr_set) {
    std::string column_str;
    std::vector<std::string> fields;
    std::vector<std::string> attr_fields;
    std::set<std::string> tmp_set;

    attr_set->clear();
    parse_id_attr_details_to_string(raw_details, column_index, '\0',  column_str);
    if (column_str[0] != '[' || column_str[column_str.size() - 1] != ']') {
        return -1;
    }
    strsplit(column_str, '\"', &attr_fields);
    for (uint32_t i = 1; i < attr_fields.size(); i += 2) {
        fields.clear();
        strsplit(attr_fields[i], ',', &fields);
        if (single_attr_index < 0 || (size_t)single_attr_index >= fields.size()) {
            //UDW_DEBUG("fields out of index.");
            continue;
        }
        std::string single_attr = fields[single_attr_index];
        if (single_attr != "") {
            int timestamp = 0;
            if (time_index >= 0 && (size_t)time_index < fields.size()) {
                timestamp = atoi(fields[time_index].c_str());
            }
            if (timestamp >= day_begin && timestamp < day_end) {
                tmp_set.insert(single_attr);
            }
        }
    }
    attr_set->resize(tmp_set.size());
    std::copy(tmp_set.begin(), tmp_set.end(), attr_set->begin());

    return 0;
}

int compute_attr_time_map(
        int day_begin, 
        int day_end, 
        int time_interval, 
        const std::string& raw_details, 
        const int column_index,
        const int attr_index,
        const int time_index,
        const int weight_index,
        std::map<std::string, int>* attr_time_map) {
    std::string column_str;
    std::vector<std::string> fields;
    std::vector<std::string> attr_fields;
    char buf[15];

    parse_id_attr_details_to_string(raw_details, column_index, '\0',  column_str);
    if (column_str[0] != '[' || column_str[column_str.size() - 1] != ']') {
        return -1;
    }
    strsplit(column_str, '\"', &attr_fields);
    for (uint32_t i = 1; i < attr_fields.size(); i += 2) {
        fields.clear();
        strsplit(attr_fields[i], ',', &fields);
        if (attr_index < 0 || (size_t)attr_index >= fields.size()) {
            //UDW_DEBUG("fields out of index.");
            continue;
        }
        std::string attr(fields[attr_index]);
        if (attr != "") {
            int timestamp = 0;
            if (time_index >= 0 && (size_t)time_index < fields.size()) {
                timestamp = atoi(fields[time_index].c_str());
            }
            if (timestamp >= day_begin && timestamp < day_end) {
                format_time_by_interval(time_interval, &timestamp);
                //AttrTimePair attr_time_pair = std::make_pair(attr, timestamp);
                snprintf(buf, 12, "%d", timestamp);
                std::string timestamp_str(buf);
                // if attr_index is time_index
                if (attr_index == time_index) {
                    attr = "";
                }
                std::string attr_time_pair(attr + "#" + timestamp_str);
                if (attr_time_map->find(attr_time_pair) != attr_time_map->end()) {
                    int weight = (*attr_time_map)[attr_time_pair];
                    (*attr_time_map)[attr_time_pair] = 
                    atoi(fields[weight_index].c_str()) + weight; 
                }
                else {
                    (*attr_time_map)[attr_time_pair] = atoi(fields[weight_index].c_str());
                }
            }
        }
    }

    return 0;
}

int compute_attr_time_map_with_ip_cnt(
        int day_begin, 
        int day_end, 
        int time_interval, 
        const std::string& raw_details, 
        const int column_index,
        const int attr_index,
        const int time_index,
        const int weight_index,
        const int cnt_index,
        std::map<std::string, int>* attr_time_map) {
    std::string column_str;
    std::vector<std::string> fields;
    std::vector<std::string> attr_fields;
    char buf[15];

    parse_id_attr_details_to_string(raw_details, column_index, '\0',  column_str);
    if (column_str[0] != '[' || column_str[column_str.size() - 1] != ']') {
        return -1;
    }
    strsplit(column_str, '\"', &attr_fields);
    for (uint32_t i = 1; i < attr_fields.size(); i += 2) {
        fields.clear();
        strsplit(attr_fields[i], ',', &fields);
        if (attr_index < 0 || (size_t)attr_index >= fields.size()) {
            //UDW_DEBUG("fields out of index.");
            continue;
        }
        std::string attr(fields[attr_index]);
        if (attr != "") {
            int timestamp = 0;
            if (time_index >= 0 && (size_t)time_index < fields.size()) {
                timestamp = atoi(fields[time_index].c_str());
            }
            if (timestamp >= day_begin && timestamp < day_end) {
                format_time_by_interval(time_interval, &timestamp);
                //AttrTimePair attr_time_pair = std::make_pair(attr, timestamp);
                snprintf(buf, 12, "%d", timestamp);
                std::string timestamp_str(buf);
                std::string ip_cnt_str = "0";
                if (cnt_index < fields.size() && !fields[cnt_index].empty()) {
                    ip_cnt_str = fields[cnt_index];
                }
                //MY_DEBUG("cnt_index is %s", ip_cnt_str.c_str());
                // if attr_index is time_index
                if (attr_index == time_index) {
                    attr = "";
                }
                std::string attr_time_pair(attr + "#" + timestamp_str + "#" + ip_cnt_str);
                if (attr_time_map->find(attr_time_pair) != attr_time_map->end()) {
                    int weight = (*attr_time_map)[attr_time_pair];
                    (*attr_time_map)[attr_time_pair] = 
                    atoi(fields[weight_index].c_str()) + weight; 
                }
                else {
                    (*attr_time_map)[attr_time_pair] = atoi(fields[weight_index].c_str());
                }
            }
        }
    }

    return 0;
}

int merge_topics_distribution(
        std::vector<TopicsDistribution>* topics,
        TopicsDistribution* topic_dist) {
    if (topics->size() == 1) {
        *topic_dist = (*topics)[0];
        return 0;
    }

    std::map<int, double> id_ratio_map;
    
    for (uint32_t i = 0; i < topics->size(); i++) {
        std::vector<Topic> topic_list = (*topics)[i].get_topics();
        for (uint32_t j = 0; j < topic_list.size(); j++) {
            int topic_id = topic_list[j].get_topic_id();
            double ratio = topic_list[j].get_ratio();
            if (id_ratio_map.find(topic_id) == id_ratio_map.end()) {
                id_ratio_map[topic_id] = ratio;
            }
            else {
                id_ratio_map[topic_id] += ratio;
            }
        }
    }
    
    std::map<int, double>::iterator it = id_ratio_map.begin();
    std::vector<Topic> merged_topics;
    for (; it != id_ratio_map.end(); it++) {
        Topic topic;
        topic.set_topic_id(it->first);
        topic.set_ratio(it->second / topics->size());
        merged_topics.push_back(topic);
    }
    topic_dist->set_topics(merged_topics);

    return 0;
}

int gen_topics_distribution(const Json::Value& topic_json, TopicsDistribution* topic_dist) {
    if (!topic_json.isMember("topic")) {
        return -1;
    }
    Json::Value topics_json = topic_json["topic"];
    std::vector<Topic> topics;
    for (uint32_t j = 0; j < topics_json.size(); j++) {
        Topic topic;
        topic.set_topic_id(topics_json[j]["id"].asInt());
        topic.set_ratio(topics_json[j]["ratio"].asDouble());
        topics.push_back(topic);
    }
    topic_dist->set_topics(topics);
    
    return 0;
}

int compute_ip_set(
        int day_begin, 
        int day_end, 
        const std::string& raw_details, 
        std::vector<std::string>* ip_set) {
    return compute_single_attr_set(
            day_begin, 
            day_end, 
            raw_details, 
            IdAttrIndex::IP_ATTR_0, 
            IpAttr0Index::IP, 
            IpAttr0Index::TIMESTAMP, 
            ip_set);
}

// 从分桶粗选后的id属性表中抽取出ip列表,以便在预测阶段去除id对在不同桶内的重复预测
int compute_bucket_ip_set(
        int day_begin, 
        int day_end, 
        const std::string& raw_details, 
        int column_index,
        std::vector<unsigned int>* ip_set) {
    if (ip_set == NULL) {
        return -1;
    }
    std::vector<std::string> str_ip_set;

    // 从ip_attr_1字段解析,格式为["ip1","ip2"],ip已经id化
    compute_single_attr_set(
            day_begin, 
            day_end, 
            raw_details, 
            column_index,
            IpAttr0Index::IP, 
            -1, 
            &str_ip_set);
    ip_set->clear();
    for (size_t i = 0; i != str_ip_set.size(); i++) {
        try {
            ip_set->push_back(boost::lexical_cast<unsigned int>(str_ip_set[i]));
        }
        catch (boost::bad_lexical_cast& e) {
            break;
        }
    }
    return 0;
}

int compute_ip_time_set(
        int day_begin, 
        int day_end, 
        int time_interval, 
        const std::string& raw_details, 
        std::vector<IpTimeAttr>* ip_time_set) {

    return compute_ip_time_set(
        day_begin, 
        day_end, 
        time_interval, 
        raw_details, 
        0,
        ip_time_set);
}

int compute_ip_time_set(
        int day_begin, 
        int day_end, 
        int time_interval, 
        const std::string& raw_details, 
        int is_id,
        std::vector<IpTimeAttr>* ip_time_set) {
    std::map<std::string, int> tmp_map;
    compute_attr_time_map_with_ip_cnt(
            day_begin, 
            day_end, 
            time_interval, 
            raw_details, 
            IdAttrIndex::IP_ATTR_0, 
            IpAttr0Index::IP, 
            IpAttr0Index::TIMESTAMP, 
            IpAttr0Index::WEIGHT, 
            IpAttr0Index::IP_TAG, 
            &tmp_map);

    std::map<std::string, int>::iterator it;
    std::vector<std::string> pair(2);
    for (it = tmp_map.begin(); it != tmp_map.end(); it++) {
        std::string time_str;
        pair.clear();
        strsplit(it->first, '#', &pair);
        int timestamp = atoi(pair[1].c_str());
        timestamp2str(timestamp, &time_str);
        int ip_tag = atoi(pair[2].c_str());
        unsigned int ip_int = 0;
        string ip = pair[0];
        if (!is_id) {
            ip_str_2_int(ip, ip_int);
        } else {
            ip_int = boost::lexical_cast<unsigned int>(ip);
        }
        // Rm internal IP
        if (!is_lan_ip(ip_int)) {
            IpTimeAttr attr(ip, ip_int, timestamp, time_str, it->second, ip_tag);
            ip_time_set->push_back(attr);
        }
    }

    return 0;
}

string string_time_set_to_string(
        const std::vector<StringTimeAttr> &str_time_set) {
    string ret = "";
    vector<string> tmp;
    tmp.clear();
    for (size_t i = 0; i != str_time_set.size(); i++) {
        tmp.push_back(str_time_set[i].to_string());
    }
    ret += json_value_to_string(vector_to_json(tmp));
    return ret;
}

int compute_string_time_set(
        int day_begin, 
        int day_end, 
        int time_interval, 
        int col_index,
        int key_index,
        int ts_index,
        int weight_index,
        const std::string& raw_details, 
        std::vector<StringTimeAttr>* ip_time_set) {
    std::map<std::string, int> tmp_map;
    compute_attr_time_map(
            day_begin, 
            day_end, 
            time_interval, 
            raw_details, 
            col_index, key_index, ts_index, weight_index,
            &tmp_map);

    std::map<std::string, int>::iterator it;
    std::vector<std::string> pair(2);
    for (it = tmp_map.begin(); it != tmp_map.end(); it++) {
        std::string time_str;
        pair.clear();
        strsplit(it->first, '#', &pair);
        int timestamp = atoi(pair[1].c_str());
        string key = pair[0];
        StringTimeAttr attr;
        attr.key = key;
        attr.timestamp = timestamp;
        attr.weight = it->second;
        ip_time_set->push_back(attr);
    }

    return 0;
}


int compute_time_set(
        int day_begin, 
        int day_end,
        int time_interval, 
        const std::string& raw_details, 
        std::vector<IpTimeAttr>* time_set) {
    std::map<std::string, int> tmp_map;
    compute_attr_time_map(
            day_begin, 
            day_end, 
            time_interval, 
            raw_details, 
            IdAttrIndex::IP_ATTR_0, 
            IpAttr0Index::TIMESTAMP, 
            IpAttr0Index::TIMESTAMP, 
            IpAttr0Index::WEIGHT, 
            &tmp_map);

    std::map<std::string, int>::iterator it;
    std::vector<std::string> pair(2);
    for (it = tmp_map.begin(); it != tmp_map.end(); it++) {
        std::string time_str;
        pair.clear();
        strsplit(it->first, '#', &pair);
        int timestamp = atoi(pair[1].c_str());
        timestamp2str(timestamp, &time_str);
        string ip = "";
        unsigned int ip_int = 0;
        ip_str_2_int(ip, ip_int);

        IpTimeAttr attr(ip, ip_int, timestamp, time_str, it->second);
        time_set->push_back(attr);
    }

    return 0;
}

int compute_city_set(
        int day_begin, 
        int day_end,
        const std::string& raw_details, 
        std::vector<std::string>* city_set) {
    return compute_single_attr_set(
            day_begin, 
            day_end, 
            raw_details, 
            IdAttrIndex::IP_CITY, 
            IpCityIndex::CITY, 
            IpCityIndex::TIMESTAMP, 
            city_set);
}

int compute_city_time_set(
        int day_begin, 
        int day_end,
        int time_interval, 
        const std::string& raw_details, 
        std::vector<CityTimeAttr>* city_time_set) {
        std::map<std::string, int> tmp_map;
    compute_attr_time_map(
            day_begin, 
            day_end, 
            time_interval, 
            raw_details, 
            IdAttrIndex::IP_CITY, 
            IpCityIndex::CITY, 
            IpCityIndex::TIMESTAMP, 
            IpCityIndex::WEIGHT, 
            &tmp_map);

    std::map<std::string, int>::iterator it;
    std::vector<std::string> pair(2);
    for (it = tmp_map.begin(); it != tmp_map.end(); it++) {
        std::string time_str;
        pair.clear();
        strsplit(it->first, '#', &pair);
        int timestamp = atoi(pair[1].c_str());
        timestamp2str(timestamp, &time_str);
        CityTimeAttr attr(pair[0], timestamp, time_str, it->second);
        city_time_set->push_back(attr);
    }

    return 0;
}

int parse_topic_distribution_string(
        int day_begin,
        int day_end,
        int time_interval,
        const std::string& s, 
        std::map<int, std::vector<TopicsDistribution> >* time_topics_map) {
    std::vector<std::string> fields;
    std::vector<std::string> nums;

    boost::algorithm::split(fields, s, boost::algorithm::is_any_of(":,}\""));
    std::vector<std::string>::iterator it = fields.begin();
    for (; it != fields.end(); ++it) {
        if (it->size() > 0 && isdigit((*it)[0])) {
            nums.push_back(*it);
        }
    }
    
    time_topics_map->clear();
    size_t i = 0;
    while (i < nums.size()) {
        if (nums[i][nums[i].size() - 1] == '\\') {
            std::string hour = nums[i].substr(0, nums[i].size() - 1);
            size_t j = i + 1;
            TopicsDistribution new_topic_dist;
            std::vector<Topic> topics;
            while (j < nums.size() && nums[j][nums[j].size() - 1] != '\\') {
                Topic topic;
                topic.set_topic_id(atoi(nums[j].c_str()));
                assert(j + 1 < nums.size());
                topic.set_ratio(atof(nums[j + 1].c_str()));
                topics.push_back(topic);
                j += 2;
            }
            new_topic_dist.set_topics(topics);

            int timestamp = atoi(hour.c_str());
            format_time_by_interval(time_interval, &timestamp);
            if (timestamp >= day_begin && timestamp < day_end) {
                if (time_topics_map->find(timestamp) == time_topics_map->end()) {
                    (*time_topics_map)[timestamp] = 
                        std::vector<TopicsDistribution>(1, new_topic_dist);
                }
                else {
                    (*time_topics_map)[timestamp].push_back(new_topic_dist);
                }
            }
            i = j;
        }
    }
    return 0;
}

int compute_topic(
        int day_begin, 
        int day_end,
        const std::string& raw_details, 
        TopicsDistribution* topic_dist) {
    Json::Value attr_json;
    Json::Value topic_json;
    Json::Reader reader;
    std::vector<std::string> fields;
    std::set<std::string> tmp_set;

    parse_id_attr_details(raw_details, IdAttrIndex::QUERY_TOPIC, '\0', &attr_json);
    std::vector<TopicsDistribution> topic_dists;
    for (uint32_t i = 0; i < attr_json.size(); i++) {
        if (!reader.parse(attr_json[i].asString(), topic_json)) {
            continue;
        }
        if (!topic_json.isMember("hour")) {
            continue;
        }
        int timestamp = atoi(topic_json["hour"].asString().c_str());
        if (timestamp >= day_begin && timestamp < day_end) {
            TopicsDistribution new_topic_dist;
            gen_topics_distribution(topic_json, &new_topic_dist);
            topic_dists.push_back(new_topic_dist);
        }
    }
    
    merge_topics_distribution(&topic_dists, topic_dist);
    return 0;
}

int compute_topic_time_set(
        int day_begin, 
        int day_end,
        int time_interval, 
        const std::string& raw_details, 
        std::vector<TopicTimeAttr>* topic_time_set) {
    std::string attr_str;
    std::vector<std::string> fields;
    std::map<int, TopicsDistribution> tmp_map;
    std::map<int, std::vector<TopicsDistribution> > time_topics_map;

    parse_id_attr_details_to_string(raw_details, IdAttrIndex::QUERY_TOPIC, '\0', attr_str); 
    parse_topic_distribution_string(day_begin, day_end, time_interval, attr_str, &time_topics_map);
    
    std::map<int, std::vector<TopicsDistribution> >::iterator it = time_topics_map.begin();
    for (; it != time_topics_map.end(); it++) {
        TopicsDistribution merged_topic_dist;
        merge_topics_distribution(&(it->second), &merged_topic_dist);
        std::string time_str;
        timestamp2str(it->first, &time_str);
        TopicTimeAttr topic_time_attr(merged_topic_dist, it->first, time_str);
        topic_time_set->push_back(topic_time_attr);
    }

    return 0;
}

int compute_client_types(
        const std::string& raw_details, 
        std::vector<std::string>* client_types) {
    return compute_single_attr_set(
            0, 
            INT_MAX, 
            raw_details, 
            IdAttrIndex::PRODUCT_CLIENTTYPE_ATTR, 
            ProductClienttypeAttrIndex::CLIENT_TYPE, 
            -1, 
            client_types);
}

int compute_product_client_type_set(
        const std::string& raw_details, 
        int is_id,
        std::vector<ProductClientTypeAttr>* client_type_set) {
    vector<std::string> products;
    vector<std::string> client_types;
    vector<std::string> weights;

    compute_single_attr_vector(
            0, 
            INT_MAX, 
            raw_details, 
            IdAttrIndex::PRODUCT_CLIENTTYPE_ATTR, 
            ProductClienttypeAttrIndex::PRODUCT, 
            -1, 
            &products);

    compute_single_attr_vector(
            0, 
            INT_MAX, 
            raw_details, 
            IdAttrIndex::PRODUCT_CLIENTTYPE_ATTR, 
            ProductClienttypeAttrIndex::CLIENT_TYPE, 
            -1, 
            &client_types);

    compute_single_attr_vector(
            0, 
            INT_MAX, 
            raw_details, 
            IdAttrIndex::PRODUCT_CLIENTTYPE_ATTR, 
            ProductClienttypeAttrIndex::WEIGHT, 
            -1, 
            &weights);

    if ((products.size() != client_types.size()) 
        || products.size() != weights.size()) {
        return -1;
    }

    for (size_t i = 0; i != products.size(); i++) {
        ProductClientTypeAttr attr;
        if (!is_id) {
            attr.product = product_to_enum(products[i]);
            attr.client_type = client_type_to_enum(client_types[i]);
            attr.weight = boost::lexical_cast<double>(weights[i]);
        } else {
            attr.product = boost::lexical_cast<int>(products[i]);
            attr.client_type = boost::lexical_cast<int>(client_types[i]);
            attr.weight = boost::lexical_cast<double>(weights[i]);

        }
        client_type_set->push_back(attr);
    }

    return 0;
}

int parse_id_attr_details(
        const std::string& raw_details, 
        const int index,
        const char delim,
        Json::Value* attr_json) {
    std::vector<std::string> fields;
    strsplit(raw_details, delim, &fields);
    Json::Reader reader;
    
    if (index < 0 || (size_t)index >= fields.size()) {
        //UDW_DEBUG("fields out of index.");
        return -1;
    }
    if (!reader.parse(fields[index], *attr_json)) {
        //UDW_DEBUG("json parse error");
        return -1;
    }
    
    return 0; 
}

int parse_id_attr_details_to_string(
        const std::string& raw_details, 
        const int index,
        const char delim,
        std::string &str) {
    std::vector<std::string> fields;
    strsplit(raw_details, delim, &fields);
    if (index < 0 || (size_t)index >= fields.size()) {
        //UDW_DEBUG("fields out of index.");
        return -1;
    }
    str = fields[index];
    return 0; 
}

int compute_event_day(
        const std::string &raw_details,
        std::string &event_day) {
    return parse_id_attr_details_to_string(
            raw_details, 
            IdAttrIndex::EVENT_DAY, 
            '\0', 
            event_day);
}

int IdAttr::compute_event_day(
        const std::string &raw_details,
        std::string &event_day) {
    if (this->version == 0) {
        return parse_id_attr_details_to_string(
                raw_details, 
                IdAttrIndex::EVENT_DAY, 
                '\0', 
                event_day);
    } else if (this->version == 5) {
        return parse_id_attr_details_to_string(
                raw_details, 
                IdAttrIndexV5::EVENT_DAY, 
                '\0', 
                event_day);
    }
    return -1;
}

int IdAttr::compute_fragment(
        const std::string &raw_details) {
    if (this->version == 0) {
        return parse_id_attr_details_to_string(
                raw_details, 
                IdAttrIndex::FRAGMENT, 
                '\0', 
                fragment);
    } else if (this->version == 5) {
        return parse_id_attr_details_to_string(
                raw_details, 
                IdAttrIndexV5::FRAGMENT, 
                '\0', 
                this->fragment);
    }
    return -1;
}

int IdAttr::compute_buckets(
        const std::string &raw_details) {
    if (this->version == 0) {
        return parse_id_attr_details_to_string(
                raw_details, 
                IdAttrIndex::BUCKETS, 
                '\0', 
                buckets);
    } else if (this->version == 5) {
        return parse_id_attr_details_to_string(
                raw_details, 
                IdAttrIndexV5::BUCKETS, 
                '\0', 
                buckets);
    }
    return -1;
}

//int IdAttr::compute_client_type() {
    //// assert product_client_type_set had been computed before
    //this->client_type = CT_UNKNOWN;
    //std::vector<ProductClientTypeAttr>& pro_cli_vec
            //= this->product_client_type_set;
    //if (this->id_type == bdg::udw::mining::BAIDUID) {
        //this->client_type = CT_PC_WEB;
        ////baiduid的生成算法本身会有一定的重复
        ////一个baiduid有多个端的时，优先认为是pc的

        //for (size_t i = 0; i < pro_cli_vec.size(); ++i) {
            //if (pro_cli_vec[i].client_type == CT_PC_WEB
                    //|| pro_cli_vec[i].product == PROD_PS) {
                //break;
            //}
            //if (pro_cli_vec[i].client_type == CT_WAP_COMMON
                    //|| pro_cli_vec[i].client_type == CT_WAP_SMART
                    //|| pro_cli_vec[i].client_type == CT_PAD_WEB) {
                //this->client_type = pro_cli_vec[i].client_type;
            //}
        //}
    //}
    //return 0;
//}

const int SECS_PER_DAY = 86400;
const int DAYS_TO_SUM = 30;
const int TIME_INTERVAL = 60;
const int IP_TIME_INTERVAL = 15;
const int TOPIC_TIME_INTERVAL = 1440;

int compute_id_attr(
        const std::string& raw_details,
        IdAttr* id_attr) {
    return compute_id_attr_internal(
            raw_details,
            TIME_INTERVAL,
            IP_TIME_INTERVAL, 
            TOPIC_TIME_INTERVAL,
            0,
            id_attr);
}

const size_t ATTR_SIZE_WITH_BUCKET_FRAGMENT = 16;
const size_t ATTR_SIZE_WITH_BUCKET_FRAGMENT_V5 = 21;

int compute_id_attr_internal(
        const std::string& raw_details,
        const int time_interval,
        const int ip_time_interval,
        const int topic_time_interval,
        int is_id,
        IdAttr* id_attr) {
    vector<string> fields;
    strsplit(raw_details, '\0', &fields);
    if (fields.size() != ATTR_SIZE_WITH_BUCKET_FRAGMENT &&
            fields.size() != ATTR_SIZE_WITH_BUCKET_FRAGMENT_V5) {
        MY_WARNING("raw_details size Wrong! expected[%d or %d], actual[%d]", 
                ATTR_SIZE_WITH_BUCKET_FRAGMENT, 
                ATTR_SIZE_WITH_BUCKET_FRAGMENT_V5,
                fields.size());
        return -1;
    }
    // Handle version
    if (fields.size() == ATTR_SIZE_WITH_BUCKET_FRAGMENT) {
        id_attr->version = 0;
    }
    if (fields.size() == ATTR_SIZE_WITH_BUCKET_FRAGMENT_V5) {
        id_attr->version = 5;
    }
    if (id_attr == NULL) {
        return -1;
    }
    id_attr->ip_set.clear();
    id_attr->time_set.clear();
    id_attr->ip_time_set.clear();
    id_attr->topic_time_set.clear();
    id_attr->bucket_ip_set.clear();

    if (id_attr->compute_event_day(raw_details, id_attr->event_day) != 0) {
        UDW_WARN("compute_event_day failed");
        return -1;
    }
    int today_sec = event_day2timestamp(id_attr->event_day);
    int start_timestamp = today_sec - SECS_PER_DAY * (DAYS_TO_SUM - 1);
    int end_timestamp = today_sec + SECS_PER_DAY;

    parse_id_attr_details_to_string(
            raw_details, 
            IdAttrIndex::IS_TOPID, 
            '\0', 
            id_attr->is_topid);

    if (id_attr->compute_fragment(raw_details) != 0) {
        UDW_WARN("compute_fragment failed");
        return -1;
    }

    if (id_attr->compute_buckets(raw_details) != 0) {
        UDW_WARN("compute_buckets failed");
        return -1;
    }

    if (compute_ip_set(start_timestamp, 
                 end_timestamp, 
                 raw_details, 
                 &(id_attr->ip_set)) == -1) {
        UDW_WARN("compute_ip_set failed");
        return -1;
    }

    // Added for id
    if (!is_id) {
        for (size_t i = 0; i != id_attr->ip_set.size(); i++) {
            unsigned int ip_int = 0;
            ip_str_2_int(id_attr->ip_set[i], ip_int);
            id_attr->int_ip_set.push_back(ip_int);
        }
    } else {
        for (size_t i = 0; i != id_attr->ip_set.size(); i++) {
            id_attr->int_ip_set.push_back(boost::lexical_cast<unsigned int>(id_attr->ip_set[i]));
        }
    }

    if (compute_bucket_ip_set(0, 
                 INT_MAX, 
                 raw_details, 
                 IdAttrIndex::IP_ATTR_1, 
                 &(id_attr->bucket_ip_set)) == -1) {
        UDW_WARN("compute_bucket_ip_set failed");
        return -1;
    }
    if (compute_time_set(start_timestamp, 
                 end_timestamp, 
                 time_interval, 
                 raw_details, 
                 &(id_attr->time_set)) == -1) {
        return -1;
    }
    if (compute_ip_time_set(start_timestamp, 
                 end_timestamp, 
                 ip_time_interval, 
                 raw_details, 
                 is_id,
                 &(id_attr->ip_time_set)) == -1) {
        return -1;
    }
    if (compute_topic_time_set(start_timestamp, 
                 end_timestamp, 
                 topic_time_interval, 
                 raw_details, 
                 &(id_attr->topic_time_set)) == -1) {
        return -1;
    }
    if (compute_product_client_type_set(raw_details, is_id,
                 &(id_attr->product_client_type_set)) == -1) {
        return -1;
    }

    parse_id_attr_details_to_string(raw_details, IdAttrIndex::ID, '\0', id_attr->id);
    parse_id_attr_details_to_string(
            raw_details, 
            IdAttrIndex::BUCKET_KEY,
            '\0',
            id_attr->bucket_key);
    parse_id_attr_details_to_string(
            raw_details, 
            IdAttrIndex::TABLE_NAME,
            '\0', 
            id_attr->table_name);
    std::string id_type_str;
    parse_id_attr_details_to_string(raw_details, IdAttrIndex::ID_TYPE, '\0', id_type_str);
    id_attr->id_type = boost::lexical_cast<int>(id_type_str);
    id_attr->start_timestamp = start_timestamp;
    id_attr->end_timestamp = end_timestamp;
    id_attr->time_interval = time_interval;
    id_attr->ip_time_interval = ip_time_interval;
    id_attr->topic_time_interval = topic_time_interval;

    get_multi_ip_time_set(id_attr->ip_time_set, id_attr->ip_time_sets, id_attr->ip_time_set_size);

    // Version 5
    if (id_attr->version == 5) {
        MY_DEBUG("version 5");
        if (compute_bucket_ip_set(0, 
                 INT_MAX, 
                 raw_details, 
                 IdAttrIndexV5::BUCKET_LIST, 
                 &(id_attr->bucket_ip_set)) == -1) {
            UDW_WARN("compute_bucket_ip_set failed");
            return -1;
        }

        // query
        if (compute_string_time_set(start_timestamp, 
                 end_timestamp, 
                 ip_time_interval, 
                 IdAttrIndexV5::QUERY_INFO,
                 0, 1, 2,
                 raw_details, 
                 &(id_attr->query_time_set)) == -1) {
            return -1;
        }

        // tieba
        if (compute_string_time_set(start_timestamp, 
                 end_timestamp, 
                 ip_time_interval, 
                 IdAttrIndexV5::TIEBA_INFO,
                 0, 1, 2,
                 raw_details, 
                 &(id_attr->tieba_time_set)) == -1) {
            return -1;
        }
        // host
        if (compute_string_time_set(start_timestamp, 
                 end_timestamp, 
                 ip_time_interval, 
                 IdAttrIndexV5::HOST_INFO,
                 0, 1, 2,
                 raw_details, 
                 &(id_attr->host_time_set)) == -1) {
            return -1;
        }
        // userids
        compute_single_attr_set(
            0, 
            INT_MAX, 
            raw_details, 
            IdAttrIndexV5::JOIN_KEY_0,
            IpAttr0Index::IP, 
            -1, 
            &id_attr->userids);

        parse_id_attr_details_to_string(
            raw_details, 
            IdAttrIndexV5::IS_TOPID, 
            '\0', 
            id_attr->is_topid);
    }

    return 0;
}

const int IP_TYPES = 4;

void get_multi_ip_time_set(
        const vector<IpTimeAttr> &ip_attrs, 
        vector<vector<IpTimeAttr> > &ip_attrs_set,
        int &ip_attrs_size) {
    ip_attrs_size = IP_TYPES;
    ip_attrs_set.clear();
    ip_attrs_set.resize(IP_TYPES);
    for (size_t i = 0; i != ip_attrs.size(); i++) {
        int tag = ip_attrs[i].ip_tag;
        if (tag < IP_TYPES) {
            ip_attrs_set[tag].push_back(ip_attrs[i]);
        } else {
            ip_attrs_set[IP_TYPES - 1].push_back(ip_attrs[i]);
        }
    }
}

const int HOUR = 60;

int IdAttr::parse_from_raw_bucketed_attribute(const std::string &raw_attr) {
    return compute_id_attr_internal(raw_attr, HOUR, HOUR, HOUR, 0, this);
}

int IdAttr::parse_from_raw_bucketed_attribute(
            const std::string &raw_attr, 
            const int time_interval, 
            const int ip_time_interval,
            const int topic_time_interval) {
    return compute_id_attr_internal(
            raw_attr, 
            time_interval, 
            ip_time_interval, 
            topic_time_interval, 
            0, 
            this);
}


// 和上面不一样，有的字段已经是ID化了的了
int IdAttr::parse_from_trimmed_bucketed_attribute(const std::string &raw_attr) {
    return compute_id_attr_internal(raw_attr, HOUR, HOUR, HOUR, 1, this);
}

int IdAttr::parse_from_trimmed_bucketed_attribute(
            const std::string &raw_attr, 
            const int time_interval, 
            const int ip_time_interval,
            const int topic_time_interval) {
    return compute_id_attr_internal(
            raw_attr, 
            time_interval, 
            ip_time_interval, 
            topic_time_interval, 
            1, 
            this);
}

// 这样初始化是不行的:const string NUL = "\0"; 要用下面一行的
const string NUL(1, '\0');

std::string IdAttr::serialize_to_trimmed_bucketed_attribute() {
    //id, id_type, bucket, query_topic, ip_city, product_client_type_attr, 
    string ret;

    // TABLE_NAME
    ret += this->table_name + NUL;

    // BUCKET_KEY
    ret += this->bucket_key + NUL;

    // ID_TYPE
    ret += boost::lexical_cast<string>(this->id_type) + NUL;

    //ID
    ret += this->id + NUL;

    // IP_ATTR_0
    Json::Value ip_attr_0;
    for (size_t i = 0; i != this->ip_time_set.size(); i++) {
        ip_attr_0.append(this->ip_time_set[i].to_string());
    }
    ret += json_value_to_string(ip_attr_0) + NUL;

    // IP_ATTR_1
    ret += NUL;

    // IP_ATTR_2
    ret += NUL;
    // IP_ATTR_3
    ret += NUL;
    // IP_CITY
    ret += NUL;

    // QUERY_TOPIC
    Json::Value topics;
    for (size_t i = 0; i!= this->topic_time_set.size(); i++) {
        Json::Value time_topic;
        time_topic["hour"] = boost::lexical_cast<std::string>(this->topic_time_set[i].timestamp);
        time_topic["topics"] = this->topic_time_set[i].topic_dist.to_json_value_without_words();
        topics.append(json_value_to_string(time_topic));
    }
    ret += json_value_to_string(topics) + NUL;

    // PRODUCT_CLIENTTYPE_ATTR
    Json::Value pca;
    for (size_t i = 0; i != this->product_client_type_set.size(); i++) {
        pca.append(this->product_client_type_set[i].to_string());
    }
    ret += json_value_to_string(pca) + NUL;

    // PRODUCT_CLIENTTYPE_DETAIL
    ret += NUL;

    // Handle version 5
    if (this->version == 5) {
        // query info
        ret += string_time_set_to_string(this->query_time_set) + NUL;
        // host info
        ret += string_time_set_to_string(this->host_time_set) + NUL;
        // tieba info
        ret += string_time_set_to_string(this->tieba_time_set) + NUL;

        // bucket_list
        ret += json_value_to_string(vector_to_json(this->bucket_ip_set)) + NUL;
        // join_key_0
        ret += json_value_to_string(vector_to_json(this->userids)) + NUL;

    }

    // EVENT_DAY
    ret += timestamp2event_day(this->end_timestamp - 86400) + NUL;
    // IS_TOPID
    ret += this->is_topid + NUL;
    // BUCKETS
    ret += this->buckets + NUL;
    // FRAGMENT
    ret += this->fragment;

    return ret;
}

string add_bucket_key_fragment(const std::string &raw_attr) {
    vector<string> fields;
    strsplit(raw_attr, '\0', &fields);
    vector<string> bucket_fields;

    for (size_t i = 0; i != fields.size(); i++) {
        if (i == (size_t)IdAttrIndex::BUCKET_KEY) {
            bucket_fields.push_back("");
        }
        bucket_fields.push_back(fields[i]);
    }
    bucket_fields.push_back("");
    bucket_fields.push_back("");

    string bucketed_str = join_str_vector_by_char(bucket_fields, '\0');
    return bucketed_str;
}

string IdAttr::remove_bucket_key_fragment(const std::string &bucket_attr) {
    vector<string> fields;
    strsplit(bucket_attr, '\0', &fields);

    vector<string> raw_fields;
    if (this->version == 0) {
        for (size_t i = 0; i!= fields.size(); i++) {
            if (i != (size_t)IdAttrIndex::BUCKET_KEY 
                    && i != (size_t)IdAttrIndex::FRAGMENT
                    && i != (size_t)IdAttrIndex::BUCKETS) {
                raw_fields.push_back(fields[i]);
            }
        }
    } else if (this->version == 5) {
        for (size_t i = 0; i!= fields.size(); i++) {
            if (i != (size_t)IdAttrIndexV5::BUCKET_KEY 
                    && i != (size_t)IdAttrIndexV5::FRAGMENT
                    && i != (size_t)IdAttrIndexV5::BUCKETS) {
                raw_fields.push_back(fields[i]);
            }
        }
    }

    return join_str_vector_by_char(raw_fields, '\0');
}

int IdAttr::parse_from_raw_attribute(const std::string &raw_attr) {
    return parse_from_raw_bucketed_attribute(add_bucket_key_fragment(raw_attr));
}

int IdAttr::parse_from_raw_attribute(
            const std::string &raw_attr, 
            const int time_interval, 
            const int ip_time_interval,
            const int topic_time_interval) {
    return parse_from_raw_bucketed_attribute(
            add_bucket_key_fragment(raw_attr),
            time_interval,
            ip_time_interval,
            topic_time_interval);
}

int IdAttr::parse_from_trimmed_attribute(const std::string &raw_attr) {
    return parse_from_trimmed_bucketed_attribute(add_bucket_key_fragment(raw_attr));
}

int IdAttr::parse_from_trimmed_attribute(
            const std::string &raw_attr, 
            const int time_interval, 
            const int ip_time_interval,
            const int topic_time_interval) {
    return parse_from_trimmed_bucketed_attribute(
            add_bucket_key_fragment(raw_attr),
            time_interval,
            ip_time_interval,
            topic_time_interval);
}

std::string IdAttr::serialize_to_trimmed_attribute() {
    return remove_bucket_key_fragment(serialize_to_trimmed_bucketed_attribute());
}

}
}
}

