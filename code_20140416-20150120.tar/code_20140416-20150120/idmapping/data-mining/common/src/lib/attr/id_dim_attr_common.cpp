/***************************************************************************
 *
 * Copyright (c) 2013 Baidu.com, Inc. All Rights Reserved
 *
 **************************************************************************/


/*
 * Author: liwei12 <liwei12@baidu.com>
 * 
 *
 * File: id_dim_attr_common.cpp
 * Create Date: 2014-12-11 23:43:17
 *
 */

#include "id_dim_attr_common.h"
#include <string>

namespace bdg {
namespace udw {
namespace mining {

#define MAP(from, to) if (prod == from) {\
    return to;\
}

int product_to_enum(const std::string &prod) {
    MAP("baike", PROD_BAIKE);
    MAP("iknow", PROD_IKNOW);
    MAP("lbs", PROD_LBS);
    MAP("map", PROD_LBS);
    MAP("nova", PROD_NOVA);
    MAP("ps", PROD_PS);
    MAP("tieba", PROD_TIEBA);
    MAP("wenku", PROD_WENKU);
    MAP("wise", PROD_WISE);
    return PROD_UNKNOWN;
}

int client_type_to_enum(const std::string &prod) {
    MAP("mobile", CT_MOBILE_APP);
    MAP("mobile__from_event", CT_MOBILE_APP);
    MAP("mobile_app", CT_MOBILE_APP);
    MAP("mobile_app__from_event", CT_MOBILE_APP);
    MAP("pad_app", CT_PAD_APP);
    MAP("pad_app__from_event", CT_PAD_APP);
    MAP("pad_web", CT_PAD_WEB);
    MAP("pad_web__from_event", CT_PAD_WEB);
    MAP("pc", CT_PC_WEB);
    MAP("pc__from_event", CT_PC_WEB);
    MAP("pc_web", CT_PC_WEB);
    MAP("pc_web__from_event", CT_PC_WEB);
    MAP("__from_event", CT_UNKNOWN);
    MAP("__HIVE_DEFAULT_PARTITION__", CT_UNKNOWN);
    MAP("other", CT_UNKNOWN);
    MAP("other__from_event", CT_UNKNOWN);
    MAP("unknown", CT_UNKNOWN);
    MAP("unknown__from_event", CT_UNKNOWN);
    MAP("mobile_web", CT_WAP_COMMON);
    MAP("wap_common", CT_WAP_COMMON);
    MAP("wap_common__from_event", CT_WAP_COMMON);
    MAP("wap_smart", CT_WAP_SMART);
    MAP("wap_smart__from_event", CT_WAP_SMART);
    MAP("webapp", CT_WAP_SMART);
    MAP("webapp__from_event", CT_WAP_SMART);
    return CT_UNKNOWN;
}

}}}
/* vim: set ts=4 sw=4: */

