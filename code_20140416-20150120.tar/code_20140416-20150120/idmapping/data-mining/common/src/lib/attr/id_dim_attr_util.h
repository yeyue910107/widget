// Copyright 2014, Baidu Inc.
// Author: yeyue <yeyue@baidu.com>

#ifndef INF_BUDW_DATA_MINING_ID_DIM_ATTR_UTIL_H
#define INF_BUDW_DATA_MINING_ID_DIM_ATTR_UTIL_H

#include <time.h>
#include <string>
#include <vector>

namespace bdg {
namespace udw {
namespace mining {

int format_time_by_interval(int interval, int* timestamp);

int timestamp2str(int timestamp, std::string* time_str);

}
}
}
#endif
