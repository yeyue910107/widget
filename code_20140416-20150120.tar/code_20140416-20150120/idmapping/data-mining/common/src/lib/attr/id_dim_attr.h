// Copyright 2014, Baidu Inc.
// Author: yeyue <yeyue@baidu.com>
#ifndef INF_BUDW_DATA_MINING_ID_DIM_ATTR_H
#define INF_BUDW_DATA_MINING_ID_DIM_ATTR_H

#include <stdint.h>
#include <string>
#include <vector>
#include <set>
#include <utility>
#include <json/json.h>
#include "topic.h"
#include "udw_dm_utils.h"
#include <boost/lexical_cast.hpp>

namespace bdg {
namespace udw {
namespace mining {

struct IpTimeAttr {
    std::string ip;
    unsigned int ip_int;
    int32_t timestamp;
    std::string time_str; // minite level(201411110000)
    int32_t weight;       // times
    // 该IP属于的tag 0,1,2,3
    int32_t ip_tag;

    //predict专用
    IpTimeAttr() {}

    IpTimeAttr(
            std::string ip, 
            unsigned int ip_int, 
            int timestamp, 
            std::string time_str, 
            int weight) : 
            ip(ip), ip_int(ip_int), timestamp(timestamp), time_str(time_str), weight(weight) { 
            ip_tag = 0;
    };
    IpTimeAttr(
            std::string ip,
            int timestamp, 
            std::string time_str, 
            int weight) : 
            ip(ip), timestamp(timestamp), time_str(time_str), weight(weight) { 
            ip_str_2_int(ip, this->ip_int);
            ip_tag = 0;
    };
    IpTimeAttr(
            std::string ip, 
            unsigned int ip_int, 
            int timestamp, 
            std::string time_str, 
            int weight,
            int32_t tag) :
            ip(ip), ip_int(ip_int), timestamp(timestamp), time_str(time_str), weight(weight), 
            ip_tag(tag) { 
    };

    std::string to_string() {
        return boost::lexical_cast<std::string>(ip_int) + ","
            + boost::lexical_cast<std::string>(timestamp) + ","
            + boost::lexical_cast<std::string>(weight) + ","
            + boost::lexical_cast<std::string>(ip_tag);
    }
};

struct StringTimeAttr {
    std::string key;
    int32_t timestamp;
    int32_t weight;

    std::string to_string() const{
        return key + ","
            + boost::lexical_cast<std::string>(timestamp) + ","
            + boost::lexical_cast<std::string>(weight);
    }
};

typedef StringTimeAttr QueryTimeAttr;
typedef StringTimeAttr TiebaTimeAttr;
typedef StringTimeAttr HostTimeAttr;

struct CityTimeAttr {
    std::string city;
    int32_t timestamp;
    std::string time_str;
    int32_t weight;

    CityTimeAttr(std::string city, int timestamp, std::string time_str, int weight) : 
            city(city), timestamp(timestamp), time_str(time_str), weight(weight) { };
};

struct TopicTimeAttr {
    TopicsDistribution topic_dist;
    int32_t timestamp;
    std::string time_str;

    TopicTimeAttr(TopicsDistribution topic_dist, int timestamp, std::string time_str) : 
            topic_dist(topic_dist), timestamp(timestamp), time_str(time_str) { };
};

struct ProductClientTypeAttr {
    int product;
    int client_type;
    double weight;

    std::string to_string() {
        return boost::lexical_cast<std::string>(product) + ","
            + boost::lexical_cast<std::string>(client_type) + ","
            + boost::lexical_cast<std::string>(weight);
    }
};

typedef std::pair<std::string, int> AttrTimePair;

inline bool ip_time_cmp(const IpTimeAttr& left, const IpTimeAttr& right) {
    if (left.timestamp < right.timestamp) {
        return true;
    }
    if (left.timestamp > right.timestamp) {
        return false;
    }
    return left.ip_int < right.ip_int; 
}

struct ip_time_cmp_class {
    bool operator() (const IpTimeAttr& left, const IpTimeAttr& right) const {
        return ip_time_cmp(left, right);
    }
};

struct IdAttr {
    int version;
    std::string table_name;
    std::string id;
    int id_type;
    std::string event_day;
    std::string bucket_key;   //ip分桶
    std::string buckets;
    std::string fragment; //来自哪个计算分片 TODO
    int start_timestamp;
    int end_timestamp;
    std::vector<std::string> ip_set;
    std::vector<unsigned int> int_ip_set;
    std::vector<IpTimeAttr> time_set;
    int time_interval;                          // minite level
    std::vector<IpTimeAttr> ip_time_set;
    // 新添加的，带维度的 四个集合
    int32_t ip_time_set_size; // 4(0,60) (60,200) (200,2000) (2000,)
    std::vector<std::vector<IpTimeAttr> > ip_time_sets;
    std::vector<QueryTimeAttr> query_time_set;
    std::vector<TiebaTimeAttr> tieba_time_set;
    std::vector<HostTimeAttr> host_time_set;
    std::vector<std::string> userids;
    std::string is_topid;
    int ip_time_interval;                       // minite level
    std::vector<TopicTimeAttr> topic_time_set;
    int topic_time_interval;                    // minite level
    std::vector<ProductClientTypeAttr> product_client_type_set;

    // 基于product_client_type_set计算, 计算规则见compute_client_type()
    //int client_type;
    std::set<IpTimeAttr, ip_time_cmp_class> ip_time_set_copy;
    // 跨端的id不分端，置为unknown,
    // userid不分端
    // baiudid: pc_web,wap_common,wap_smart,pad_web
    // cuid : mobile_app
    // 2014.12.13目前主要关注baiduid的分端
    // 其他 TODO
    //int compute_client_type();

    // 分桶粗选过滤后的ip列表,避免预测阶段重复计算id对
    std::vector<unsigned int> bucket_ip_set;

    /*
     ip,time,query都是小时级别
     下面三个接口是用于解析 udw_id_attribute_all表。
     格式约定为：https://svn.baidu.com/inf/budw/trunk/data-mining/common/src/lib/attr/id_dim_attr_common.h
        如果是13列，就是IdAttrIndex, 不带BUCKET_KEY、BUCKETS 、FRAGMENT 
        如果是18列，就是IdAttrIndexV5，不带BUCKET_KEY、BUCKETS 、FRAGMENT
     */
    int parse_from_raw_attribute(const std::string &raw_attr);
    int parse_from_raw_attribute(
            const std::string &raw_attr, 
            const int time_interval, 
            const int ip_time_interval,
            const int topic_time_interval);
    int parse_from_trimmed_attribute(const std::string &raw_attr);
    int parse_from_trimmed_attribute(
            const std::string &raw_attr, 
            const int time_interval, 
            const int ip_time_interval,
            const int topic_time_interval);
    std::string serialize_to_trimmed_attribute();

    /*
     ip,time,query都是小时级别
     下面三个接口是用于解析 udw_id_attribute_group_all表。
     
     格式约定为：https://svn.baidu.com/inf/budw/trunk/data-mining/common/src/lib/attr/id_dim_attr_common.h
        如果是16列，就是IdAttrIndex
        如果是21列，就是IdAttrIndexV5
    */
    int parse_from_raw_bucketed_attribute(const std::string &raw_attr);
    int parse_from_raw_bucketed_attribute(
            const std::string &raw_attr, 
            const int time_interval, 
            const int ip_time_interval,
            const int topic_time_interval);
    int parse_from_trimmed_bucketed_attribute(const std::string &raw_attr);
    int parse_from_trimmed_bucketed_attribute(
            const std::string &raw_attr, 
            const int time_interval, 
            const int ip_time_interval,
            const int topic_time_interval);
    std::string serialize_to_trimmed_bucketed_attribute();

    std::string remove_bucket_key_fragment(const std::string &bucket_attr);
    int compute_event_day(
        const std::string &raw_details,
        std::string &event_day);
    int compute_buckets(
        const std::string &raw_details);
    int compute_fragment(
        const std::string &raw_details);
};



/*********************************************************************************************************/
/*  下面的接口是内部使用的，外部不会用到                    */

int compute_id_attr(
        const std::string& attr_detail,
        IdAttr* id_attr);

int compute_id_attr_internal(
        const std::string& attr_detail,
        const int time_interval,
        const int ip_time_interval,
        const int topic_time_interval,
        int is_id,
        IdAttr* id_attr);



/**
 * @brief 从原始id全量属性中抽取几天内的ip集合
 * @param [day_begin,day_end) 天级时间区段 [1415635200, 1415721600)
 * @param raw_details 原始属性字符串 ["10.212.16.57,1415635200,2","10.212.45.11,1415636100,1"]
 * @output ip_set ip集合 ["10.212.16.57", "10.212.45.11"]
 */
int compute_ip_set(
        int day_begin, 
        int day_end, 
        const std::string& raw_details, 
        std::vector<std::string>* ip_set);

/**
 * @brief 从原始id全量属性中抽取几天内的ip+time集合(分时段或时域)
 * @param [day_begin,day_end) 天级时间区段 [1415635200, 1415721600)
 * @param time_interval 时间段 60(min)
 * @param raw_details 原始属性字符串 ["10.212.16.57,1415635200,2","10.212.16.57,1415636100,2","10.212.45.11,1415635200,1"]
 * @output ip_time_set ip+time集合 ["10.212.16.57,1415635200,201411110000,4", "10.212.45.11,1415635200,201411110000,1"]
 */
int compute_ip_time_set(
        int day_begin, 
        int day_end, 
        int time_interval, 
        const std::string& raw_details, 
        int is_id,
        std::vector<IpTimeAttr>* ip_time_set);

int compute_ip_time_set(
        int day_begin, 
        int day_end, 
        int time_interval, 
        const std::string& raw_details, 
        std::vector<IpTimeAttr>* ip_time_set);

/**
 * @brief 从原始id全量属性中抽取几天内的time集合(分时段)
 * @param [day_begin,day_end) 天级时间区段 [1415635200, 1415721600)
 * @param time_interval 时间段 60(min)
 * @param raw_details 原始属性字符串 ["10.212.16.57,1415635200,2","10.212.16.57,1415636100,2","10.212.45.11,1415635200,1"]
 * @output time_set time集合 [",1415635200,201411110000,4", ",1415635200,201411110000,1"]
 */
int compute_time_set(
        int day_begin, 
        int day_end,
        int time_interval, 
        const std::string& raw_details, 
        std::vector<IpTimeAttr>* time_set);

/**
 * @brief 从原始id全量属性中抽取几天内的city集合(和ip类似)
 * @param [day_begin,day_end) 天级时间区段 [1415635200, 1415721600)
 * @param raw_details 原始属性字符串 ["10.212.16.57,1415635200,北京,2","10.212.16.57,1415636100,北京,2","10.212.45.11,1415635200,上海,1"]
 * @output city_set city集合 ["北京", "上海"]
 */
int compute_city_set(
        int day_begin, 
        int day_end,
        const std::string& raw_details, 
        std::vector<std::string>* city_set);

/**
 * @brief 从原始id全量属性中抽取几天内的city+time集合(分时段或时域,和ip类似)
 * @param [day_begin,day_end) 天级时间区段 [1415635200, 1415721600)
 * @param time_interval 时间段 60(min)
 * @param raw_details 原始属性字符串 ["10.212.16.57,1415635200,北京,2","10.212.16.57,1415636100,北京,2","10.212.45.11,1415635200,上海,1"]
 * @output city_time_set city+time集合 ["北京,1415635200,201411110000,4", "上海,1415635200,201411110000,1"]
 */
int compute_city_time_set(
        int day_begin, 
        int day_end,
        int time_interval, 
        const std::string& raw_details, 
        std::vector<CityTimeAttr>* city_time_set);

/**
 * @brief 从原始id全量属性中抽取几天内的topic集合
 * @param [day_begin,day_end) 天级时间区段 [1415635200, 1415721600)
 * @param raw_details 原始属性字符串 ["{\"hour\":\"1414375200\",\"topic\":[{\"id\":904,\"ratio\":0.5},{\"id\":865,\"ratio\":0.3},{\"id\":45,\"ratio\":0.2}]},{\"hour\":1414378800\", \"topic\":[{\"id\":662,\"ratio\":0.6},{\"id\":813,\"ratio\":0.4}]}"]
 * @output topic集合 [{\"id\":904,\"ratio\":0.25},{\"id\":865,\"ratio\":0.15},{\"id\":45,\"ratio\":0.1},{\"id\":662,\"ratio\":0.3},{\"id\":814,\"ratio\":0.2}]
 */
int compute_topic(
        int day_begin, 
        int day_end,
        const std::string& raw_details, 
        TopicsDistribution* topic);

/**
 * @brief 从原始id全量属性中抽取几天内的topic集合
 * @param [day_begin,day_end) 天级时间区段 [1415635200, 1415721600)
 * @param time_interval 时间段 1440(min)
 * @param raw_details 原始属性字符串 ["{\"hour\":\"1414375200\",\"topic\":[{\"id\":904,\"ratio\":0.5},{\"id\":865,\"ratio\":0.3},{\"id\":45,\"ratio\":0.2}]},{\"hour\":1414378800\", \"topic\":[{\"id\":662,\"ratio\":0.6},{\"id\":813,\"ratio\":0.4}]}"]
 * @output topic集合 [{{\"id\":904,\"ratio\":0.25},{\"id\":865,\"ratio\":0.15},{\"id\":45,\"ratio\":0.1},{\"id\":662,\"ratio\":0.3},{\"id\":814,\"ratio\":0.2},1414339200,201410270000},...]
 */
int compute_topic_time_set(
        int day_begin, 
        int day_end,
        int time_interval, 
        const std::string& raw_details, 
        std::vector<TopicTimeAttr>* topic_time_set);

/**
 * @brief 从原始id全量属性中抽取端属性集合
 * @param [day_begin,day_end) 天级时间区段 [1415635200, 1415721600)
 * @param raw_details 原始属性字符串 ["ps,pc_web,1","wise,wap_common,1"]
 * @output client_types 端属性集合 ["pc_web", "wap_common"]
 */
int compute_client_types(
        const std::string& raw_details, 
        std::vector<std::string>* client_types);

int parse_id_attr_details(
        const std::string& raw_details, 
        const int index,
        const char delim,
        Json::Value* attr_json);

int parse_id_attr_details_to_string(
        const std::string& raw_details, 
        const int index,
        const char delim,
        std::string &str);

std::string add_bucket_key_fragment(const std::string &raw_attr);
std::string remove_bucket_key(const std::string &bucket_attr);

void get_multi_ip_time_set(
        const std::vector<IpTimeAttr> &ip_attrs, 
        std::vector<std::vector<IpTimeAttr> > &ip_attrs_set,
        int &ip_attrs_size);
int compute_event_day(
        const std::string &raw_details,
        std::string &event_day);



}
}
}

#endif
