// Copyright 2014, Baidu Inc.
// Author: yeyue <yeyue@baidu.com>

#include <iostream>
#include <fstream>
#include "gtest/gtest.h"
#include <boost/algorithm/string.hpp>
#include "id_dim_attr_common.h"
#include "id_dim_attr.h"
#include "id_dim_attr_util.h"

using std::string;

int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
};

namespace bdg {
namespace udw {
namespace mining {

class TestIdDimAttrSuite : public::testing::Test {
    protected:
        TestIdDimAttrSuite() {};
        virtual ~TestIdDimAttrSuite() {};
        virtual void SetUp() {};
        virtual void TearDown() {};
};

TEST_F(TestIdDimAttrSuite, format_time_by_interval) {
    int timestamp = 1414404900;
    format_time_by_interval(60, &timestamp);
    EXPECT_EQ(1414404000, timestamp);

    timestamp = 1414404900;
    format_time_by_interval(1440, &timestamp);
    EXPECT_EQ(1414339200, timestamp);

    timestamp = 1414360800;
    format_time_by_interval(1440, &timestamp);
    EXPECT_EQ(1414339200, timestamp);

    timestamp = 1414404901;
    format_time_by_interval(2, &timestamp);
    EXPECT_EQ(1414404840, timestamp);

    timestamp = 1414400000;
    format_time_by_interval(0, &timestamp);
    EXPECT_EQ(1414400000, timestamp);

    timestamp = 1414339199;
    format_time_by_interval(1440, &timestamp);
    EXPECT_EQ(1414252800, timestamp);
}

TEST_F(TestIdDimAttrSuite, parse_id_attr_details) { 
    //std::string raw_details = "udw_id_attribute_group_all\t1\t00022A3152A045DFDDD87B53AFDAB940\t[\"117.147.139.49,1414405800,1\"]\t[\"117.147.139.49,1414404900,ps,1\"]\t[\"117.147.139.49,1414404900,0,7,1\"]\t[\"117.147.139.49,1414404900,ps,0,7,1\"]\t[\"117.147.139.49,1414404900,金华,1\",\"117.147.139.49,1414405800,金华,1\"]\t[{\"hour\":\"1414404000\",\"topic\":[{\"id\":548,\"ratio\":0.4999975860118866},{\"id\":797,\"ratio\":0.04820838943123817},{\"id\":22,\"ratio\":0.9958418011665344},{\"id\":855,\"ratio\":0.4419719278812408}]}]\t[\"pc,pc_web,1\",\"wise,wap_common,1\"]\t\t20141027\t0";
    //std::string raw_details = "udw_id_attribute_group_all\t1\t00022A3152A045DFDDD87B53AFDAB940\t[\"117.147.139.49,1414405800,1\"]\t[\"117.147.139.49,1414404900,ps,1\"]\t[\"117.147.139.49,1414404900,0,7,1\"]\t[\"117.147.139.49,1414404900,ps,0,7,1\"]\t[\"117.147.139.49,1414404900,金华,1\",\"117.147.139.49,1414405800,金华,1\"]\t[\"{\\\"hour\\\":\\\"1414404000\\\",\\\"topic\\\":[{\\\"id\\\":548,\\\"ratio\\\":0.4999975860118866},{\\\"id\\\":797,\\\"ratio\\\":0.04820838943123817},{\\\"id\\\":22,\\\"ratio\\\":0.9958418011665344},{\\\"id\\\":855,\\\"ratio\\\":0.4419719278812408}]}\"]\t[\"pc,pc_web,1\",\"wise,wap_common,1\"]\t\t20141027\t0";
    //std::string raw_details = "udw_id_attribute_group_all\01\000022A3152A045DFDDD87B53AFDAB940\0[\"117.147.139.49,1414405800,1\"]\0[\"117.147.139.49,1414404900,ps,1\"]\0[\"117.147.139.49,1414404900,0,7,1\"]\0[\"117.147.139.49,1414404900,ps,0,7,1\"]\0[\"117.147.139.49,1414404900,金华,1\",\"117.147.139.49,1414405800,金华,1\"]\0[\"{\\\"hour\\\":\\\"1414404000\\\",\\\"topic\\\":[{\\\"id\\\":548,\\\"ratio\\\":0.4999975860118866},{\\\"id\\\":797,\\\"ratio\\\":0.04820838943123817},{\\\"id\\\":22,\\\"ratio\\\":0.9958418011665344},{\\\"id\\\":855,\\\"ratio\\\":0.4419719278812408}]}\"]\0[\"pc,pc_web,1\",\"wise,wap_common,1\"]\0\020141027\00";
    //char detail[] = "udw_id_attribute_group_all\01\000022A3152A045DFDDD87B53AFDAB940\0[\"117.147.139.49,1414405800,1\"]\0[\"117.147.139.49,1414404900,ps,1\"]\0[\"117.147.139.49,1414404900,0,7,1\"]\0[\"117.147.139.49,1414404900,ps,0,7,1\"]\0[\"117.147.139.49,1414404900,金华,1\",\"117.147.139.49,1414405800,金华,1\"]\0[\"{\\\"hour\\\":\\\"1414404000\\\",\\\"topic\\\":[{\\\"id\\\":548,\\\"ratio\\\":0.4999975860118866},{\\\"id\\\":797,\\\"ratio\\\":0.04820838943123817},{\\\"id\\\":22,\\\"ratio\\\":0.9958418011665344},{\\\"id\\\":855,\\\"ratio\\\":0.4419719278812408}]}\"]\0[\"pc,pc_web,1\",\"wise,wap_common,1\"]\0\020141027\00";
    std::ifstream ifs("./test_data_attr.txt");
    std::vector<std::string> inputs;
    std::string s;
    while (getline(ifs, s)) {
        inputs.push_back(s);
    }
    ifs.close();
    std::string raw_details = inputs[0];
    Json::Value attr_json;
    parse_id_attr_details(raw_details, IdAttrIndex::IP_CITY, '\0', &attr_json);
    for (uint32_t i = 0; i < attr_json.size(); i++) {
        std::cout << attr_json[i] << std::endl;
    }

}

TEST_F(TestIdDimAttrSuite, compute_ip_set) { 
    std::ifstream ifs("./test_data_attr.txt");
    std::vector<std::string> inputs;
    std::string s;
    while (getline(ifs, s)) {
        inputs.push_back(s);
    }
    ifs.close();
    std::string raw_details = inputs[0];

    std::vector<std::string> ip_set;
    compute_ip_set(1414404900, 1414408500, raw_details, &ip_set);
    EXPECT_EQ(ip_set.size(), 1);
    EXPECT_EQ(ip_set[0], "117.147.139.49");

//    ip_set.clear();
    compute_ip_set(1414404900, 1414408500, inputs[1], &ip_set);
    EXPECT_EQ(ip_set.size(), 2);
    EXPECT_EQ(ip_set[0], "117.147.139.49");
    EXPECT_EQ(ip_set[1], "117.147.139.50");
    
    compute_ip_set(1414404900, 1414408500, inputs[2], &ip_set);
    EXPECT_EQ(ip_set.size(), 0);

}

TEST_F(TestIdDimAttrSuite, compute_ip_set_case1) { 
    std::ifstream ifs("./test_data_attr.txt");
    std::vector<std::string> inputs;
    std::string s;
    while (getline(ifs, s)) {
        inputs.push_back(s);
    }
    ifs.close();
    std::vector<std::string> ip_set;
    compute_ip_set(1414404900, 1414408500, inputs[3], &ip_set);
    EXPECT_EQ(ip_set.size(), 0);

    compute_ip_set(1414404900, 1414408500, inputs[6], &ip_set);
    EXPECT_EQ(ip_set.size(), 0);
}

TEST_F(TestIdDimAttrSuite, compute_ip_time_set) { 
    std::ifstream ifs("./test_data_attr.txt");
    std::vector<std::string> inputs;
    std::string s;
    while (getline(ifs, s)) {
        inputs.push_back(s);
    }
    ifs.close();
    std::string raw_details = inputs[0];

    std::vector<IpTimeAttr> ip_time_set;
    compute_ip_time_set(1414404900, 1414408500, 15, raw_details, &ip_time_set);
    EXPECT_EQ(ip_time_set.size(), 2);
    EXPECT_EQ(ip_time_set[0].ip, "117.147.139.49");
    EXPECT_EQ(ip_time_set[0].timestamp, 1414404900);
    EXPECT_EQ(ip_time_set[0].time_str, "201410271815");
    EXPECT_EQ(ip_time_set[0].weight, 1);
    EXPECT_EQ(ip_time_set[1].ip, "117.147.139.49");
    EXPECT_EQ(ip_time_set[1].timestamp, 1414405800);
    EXPECT_EQ(ip_time_set[1].time_str, "201410271830");
    EXPECT_EQ(ip_time_set[1].weight, 1);

    ip_time_set.clear();
    compute_ip_time_set(1414404900, 1414408500, 60, inputs[1], &ip_time_set);
    EXPECT_EQ(ip_time_set.size(), 2);
    EXPECT_EQ(ip_time_set[0].ip, "117.147.139.49");
    EXPECT_EQ(ip_time_set[0].timestamp, 1414404000);
    EXPECT_EQ(ip_time_set[0].time_str, "201410271800");
    EXPECT_EQ(ip_time_set[0].weight, 2);
    EXPECT_EQ(ip_time_set[1].ip, "117.147.139.50");
    EXPECT_EQ(ip_time_set[1].timestamp, 1414404000);
    EXPECT_EQ(ip_time_set[1].time_str, "201410271800");
    EXPECT_EQ(ip_time_set[1].weight, 2);

    //compute_time_set(0, INT_MAX, 60, inputs[8], &ip_time_set);
    //compute_time_set(0, INT_MAX, 60, inputs[9], &ip_time_set);
}

TEST_F(TestIdDimAttrSuite, compute_time_set) { 
    std::ifstream ifs("./test_data_attr.txt");
    std::vector<std::string> inputs;
    std::string s;
    while (getline(ifs, s)) {
        inputs.push_back(s);
    }
    ifs.close();
    std::string raw_details = inputs[0];

    std::vector<IpTimeAttr> time_set;
    compute_time_set(1414404900, 1414408500, 30, raw_details, &time_set);
    EXPECT_EQ(time_set.size(), 2);
    EXPECT_EQ(time_set[0].ip, "");
    EXPECT_EQ(time_set[0].timestamp, 1414404000);
    EXPECT_EQ(time_set[0].time_str, "201410271800");
    EXPECT_EQ(time_set[0].weight, 1);
    EXPECT_EQ(time_set[1].ip, "");
    EXPECT_EQ(time_set[1].timestamp, 1414405800);
    EXPECT_EQ(time_set[1].time_str, "201410271830");
    EXPECT_EQ(time_set[1].weight, 1);

    //compute_time_set(0, INT_MAX, 60, inputs[8], &time_set);
    //compute_time_set(0, INT_MAX, 60, inputs[9], &time_set);
}

TEST_F(TestIdDimAttrSuite, compute_city_set) { 
    std::ifstream ifs("./test_data_attr.txt");
    std::vector<std::string> inputs;
    std::string s;
    while (getline(ifs, s)) {
        inputs.push_back(s);
    }
    ifs.close();
    std::string raw_details = inputs[0];

    std::vector<std::string> city_set;
    compute_city_set(1414404900, 1414408500, raw_details, &city_set);
    EXPECT_EQ(city_set.size(), 1);
    EXPECT_EQ(city_set[0], "金华");
}

TEST_F(TestIdDimAttrSuite, compute_city_time_set) { 
    std::ifstream ifs("./test_data_attr.txt");
    std::vector<std::string> inputs;
    std::string s;
    while (getline(ifs, s)) {
        inputs.push_back(s);
    }
    ifs.close();
    std::string raw_details = inputs[0];

    std::vector<CityTimeAttr> city_time_set;
    compute_city_time_set(1414404900, 1414408500, 15, raw_details, &city_time_set);
    EXPECT_EQ(city_time_set.size(), 2);
    EXPECT_EQ(city_time_set[0].city, "金华");
    EXPECT_EQ(city_time_set[0].timestamp, 1414404900);
    EXPECT_EQ(city_time_set[0].time_str, "201410271815");
    EXPECT_EQ(city_time_set[0].weight, 1);
    EXPECT_EQ(city_time_set[1].city, "金华");
    EXPECT_EQ(city_time_set[1].timestamp, 1414405800);
    EXPECT_EQ(city_time_set[1].time_str, "201410271830");
    EXPECT_EQ(city_time_set[1].weight, 1);

    city_time_set.clear();
    compute_city_time_set(1414404900, 1414409000, 120, inputs[1], &city_time_set);
    EXPECT_EQ(city_time_set.size(), 1);
    EXPECT_EQ(city_time_set[0].city, "金华");
    EXPECT_EQ(city_time_set[0].timestamp, 1414404000);
    EXPECT_EQ(city_time_set[0].time_str, "201410271800");
    EXPECT_EQ(city_time_set[0].weight, 6);

}

TEST_F(TestIdDimAttrSuite, compute_topic) { 
    std::ifstream ifs("./test_data_attr.txt");
    std::vector<std::string> inputs;
    std::string s;
    while (getline(ifs, s)) {
        inputs.push_back(s);
    }
    ifs.close();
    std::string raw_details = inputs[0];

    TopicsDistribution topic_dist;
    compute_topic(1414404000, 1414408500, raw_details, &topic_dist);
    std::cout << topic_dist.to_string() << std::endl;

    compute_topic(1414404000, 1414408500, inputs[1], &topic_dist);
    std::cout << topic_dist.to_string() << std::endl;

    compute_topic(1414404000, 1414408500, inputs[2], &topic_dist);
    std::cout << topic_dist.to_string() << std::endl;
}

TEST_F(TestIdDimAttrSuite, compute_topic_time_set) { 
    std::ifstream ifs("./test_data_attr.txt");
    std::vector<std::string> inputs;
    std::string s;
    while (getline(ifs, s)) {
        inputs.push_back(s);
    }
    ifs.close();
    std::string raw_details = inputs[0];

    std::vector<TopicTimeAttr> topic_time_set;
    compute_topic_time_set(1414300000, 1414408500, 1440, raw_details, &topic_time_set);
    for (size_t i = 0; i < topic_time_set.size(); i++) { 
        std::cout << topic_time_set[i].topic_dist.to_string()
                  << "," 
                  << topic_time_set[i].timestamp 
                  << ","
                  << topic_time_set[i].time_str
                  << std::endl;
    }
    compute_topic_time_set(1414300000, 1414408500, 60, inputs[1], &topic_time_set);
    for (size_t i = 0; i < topic_time_set.size(); i++) { 
        std::cout << topic_time_set[i].topic_dist.to_string()
                  << "," 
                  << topic_time_set[i].timestamp 
                  << ","
                  << topic_time_set[i].time_str
                  << std::endl;
    }
}

TEST_F(TestIdDimAttrSuite, compute_client_types) { 
    std::ifstream ifs("./test_data_attr.txt");
    std::vector<std::string> inputs;
    std::string s;
    while (getline(ifs, s)) {
        inputs.push_back(s);
    }
    ifs.close();
    std::string raw_details = inputs[0];

    std::vector<std::string> client_types;
    compute_client_types(raw_details, &client_types);
    EXPECT_EQ(client_types.size(), 2);
    EXPECT_EQ(client_types[0], "pc_web");
    EXPECT_EQ(client_types[1], "wap_common");

}

TEST_F(TestIdDimAttrSuite, compute_id_attr) { 
    std::ifstream ifs("./test_data_attr.txt");
    std::vector<std::string> inputs;
    std::string s;
    while (getline(ifs, s)) {
        inputs.push_back(s);
    }
    ifs.close();
    std::string raw_details = inputs[0];
    
    IdAttr id_attr;
    compute_id_attr(raw_details, &id_attr);
    ASSERT_EQ(id_attr.ip_set.size(), 1);
    ASSERT_EQ(id_attr.time_set.size(), 1);
    ASSERT_EQ(id_attr.ip_time_set.size(), 2);
    ASSERT_EQ(id_attr.topic_time_set.size(), 1);
    ASSERT_EQ(id_attr.time_interval, 60);
    ASSERT_EQ(id_attr.ip_time_interval, 15);
    ASSERT_EQ(id_attr.topic_time_interval, 1440);

    compute_id_attr(inputs[1], &id_attr);
    ASSERT_EQ(id_attr.ip_set.size(), 3);
    ASSERT_EQ(id_attr.time_set.size(), 2);
    ASSERT_EQ(id_attr.ip_time_set.size(), 4);
    ASSERT_EQ(id_attr.topic_time_set.size(), 1);

    compute_id_attr(inputs[2], &id_attr);
    ASSERT_EQ(id_attr.ip_set.size(), 1);
    ASSERT_EQ(id_attr.time_set.size(), 2);
    ASSERT_EQ(id_attr.ip_time_set.size(), 1);
    ASSERT_EQ(id_attr.topic_time_set.size(), 0);
}

TEST_F(TestIdDimAttrSuite, id_attr_parse) { 
    std::ifstream ifs("./test_data_attr.txt");
    std::vector<std::string> inputs;
    std::string s;
    while (getline(ifs, s)) {
        inputs.push_back(s);
    }
    ifs.close();
    std::string raw_details = inputs[0];

    IdAttr id_attr;
    int ret = id_attr.parse_from_raw_bucketed_attribute(raw_details);
    ASSERT_EQ(ret, 0);

    std::string trimmed_details = id_attr.serialize_to_trimmed_bucketed_attribute();
    std::string expected_str; 
    std::string nul(1, '\0');
    expected_str = 
            "udw_id_attribute_group_all" + nul
            + nul +
            + "3" + nul
            + "00022A3152A045DFDDD87B53AFDAB940" + nul +
            + "[\"1972603697,1414404000,2,0\"]" + nul
            + nul
            + nul
            + nul
            + nul
            + "[\"{\\\"hour\\\":\\\"1414404000\\\",\\\"topics\\\":[{\\\"id\\\":7" 
            + "97,\\\"ratio\\\":0.60},{\\\"id\\\":855,\\\"ratio\\\":0.40}]}\"]" + nul
            + "[\"0,3,1\",\"8,8,1\"]" + nul
            + nul
            + "20141027" + nul
            + "100" + nul 
            + "2" + nul
            + "3";

    ASSERT_EQ(trimmed_details, expected_str);
    ASSERT_EQ(trimmed_details.size(), expected_str.size());

    std::cout << expected_str << std::endl;
    std::cout << trimmed_details << std::endl;

    IdAttr id_attr_1;
    id_attr_1.parse_from_trimmed_bucketed_attribute(trimmed_details);

    std::string trimmed_details_1 = id_attr_1.serialize_to_trimmed_bucketed_attribute();
    ASSERT_EQ(expected_str, trimmed_details_1);
    ASSERT_EQ(expected_str.size(), trimmed_details_1.size());
}

TEST_F(TestIdDimAttrSuite, id_attr_parse_v5) { 
    std::ifstream ifs("./test_data_attr.txt");
    std::vector<std::string> inputs;
    std::string s;
    while (getline(ifs, s)) {
        inputs.push_back(s);
    }
    ifs.close();
    std::string raw_details = inputs[14];

    IdAttr id_attr;
    int ret = id_attr.parse_from_raw_bucketed_attribute(raw_details);
    ASSERT_EQ(ret, 0);
    ASSERT_EQ(id_attr.ip_time_set_size, 4);
    ASSERT_EQ(id_attr.ip_time_sets.size(), 4);
    ASSERT_EQ(id_attr.ip_time_sets[0].size(), 0);
    ASSERT_EQ(id_attr.ip_time_sets[1].size(), 0);
    ASSERT_EQ(id_attr.ip_time_sets[2].size(), 0);
    ASSERT_EQ(id_attr.ip_time_sets[3].size(), 1);

    std::string trimmed_details = id_attr.serialize_to_trimmed_bucketed_attribute();
    std::string expected_str; 
    std::string nul(1, '\0');
    expected_str = 
            "udw_id_attribute_group_all" + nul
            + nul +
            + "3" + nul
            + "00022A3152A045DFDDD87B53AFDAB940" + nul +
            + "[\"1972603697,1414404000,3,3\"]" + nul
            + nul
            + nul
            + nul
            + nul
            + "[\"{\\\"hour\\\":\\\"1414404000\\\",\\\"topics\\\":[{\\\"id\\\":7" 
            + "97,\\\"ratio\\\":0.60},{\\\"id\\\":855,\\\"ratio\\\":0.40}]}\"]" + nul
            + "[\"0,3,1\",\"8,8,1\"]" + nul
            + nul
            + "[\"北京,1414404000,100\",\"欢迎,1414404000,200\"]" + nul
            + nul
            + "[\"北京,1414404000,100\",\"欢迎,1414404000,200\"]" + nul
            + "[\"1\",\"2\"]" + nul
            + "[\"u1\",\"u2\"]" + nul
            + "20141027" + nul
            + "0" + nul 
            + "0" + nul
            + "0";

    ASSERT_EQ(trimmed_details, expected_str);
    ASSERT_EQ(trimmed_details.size(), expected_str.size());

    std::cout << expected_str << std::endl;
    std::cout << trimmed_details << std::endl;

    IdAttr id_attr_1;
    id_attr_1.parse_from_trimmed_bucketed_attribute(trimmed_details);

    std::string trimmed_details_1 = id_attr_1.serialize_to_trimmed_bucketed_attribute();
    ASSERT_EQ(expected_str, trimmed_details_1);
    ASSERT_EQ(expected_str.size(), trimmed_details_1.size());
}

TEST_F(TestIdDimAttrSuite, add_bucket_key) {
    string nul = string(1, '\0');
    string s = "b" + nul + "b" + nul + "c" + nul + "c";
    string s2 = "b" + nul + nul + "b" + nul + "c" + nul + "c" + nul + nul;
    string s1 = add_bucket_key_fragment(s);
    ASSERT_EQ(s2, s1);
}

TEST_F(TestIdDimAttrSuite, id_attr_parse_no_bukcet_key) { 
    std::ifstream ifs("./test_data_attr.txt");
    std::vector<std::string> inputs;
    std::string s;
    while (getline(ifs, s)) {
        inputs.push_back(s);
    }
    ifs.close();
    std::string raw_details = inputs[7];

    IdAttr id_attr;
    int ret = id_attr.parse_from_raw_attribute(raw_details);
    ASSERT_EQ(ret, 0);

    std::string trimmed_details = id_attr.serialize_to_trimmed_attribute();
    std::string expected_str; 
    std::string nul(1, '\0');
    expected_str = 
            "udw_id_attribute_group_all" + nul
            + "3" + nul
            + "00022A3152A045DFDDD87B53AFDAB940" + nul +
            + "[\"1972603697,1414404000,2,0\"]" + nul
            + nul
            + nul
            + nul
            + nul
            + "[\"{\\\"hour\\\":\\\"1414404000\\\",\\\"topics\\\":[{\\\"id\\\":7" 
            + "97,\\\"ratio\\\":0.60},{\\\"id\\\":855,\\\"ratio\\\":0.40}]}\"]" + nul
            + "[\"0,3,1\",\"8,8,1\"]" + nul
            + nul
            + "20141027" + nul
            + "0";

    ASSERT_EQ(trimmed_details, expected_str);
    ASSERT_EQ(trimmed_details.size(), expected_str.size());

    std::cout << expected_str << std::endl;
    std::cout << trimmed_details << std::endl;

    IdAttr id_attr_1;
    id_attr_1.parse_from_trimmed_attribute(trimmed_details);

    std::string trimmed_details_1 = id_attr_1.serialize_to_trimmed_attribute();
    ASSERT_EQ(expected_str, trimmed_details_1);
    ASSERT_EQ(expected_str.size(), trimmed_details_1.size());
}

TEST_F(TestIdDimAttrSuite, attr_size_wrong) { 
    IdAttr id_attr_1;
    int ret = id_attr_1.parse_from_raw_attribute("");

    ASSERT_EQ(ret, -1);
}

TEST_F(TestIdDimAttrSuite, compute_event_day_fregment_client_type) { 
    std::ifstream ifs("./test_data_attr.txt");
    std::vector<std::string> inputs;
    std::string s;
    while (getline(ifs, s)) {
        inputs.push_back(s);
    }
    ifs.close();
    std::string raw_details = inputs[8];

    IdAttr id_attr;
    int ret = id_attr.parse_from_raw_bucketed_attribute(raw_details);
    ASSERT_EQ(ret, 0);

    std::string raw_details_1 = inputs[9];

    std::cerr << raw_details_1 << std::endl;

    IdAttr id_attr1;
    ret = id_attr1.parse_from_trimmed_attribute(raw_details_1);
    ASSERT_EQ(ret, 0);
    ASSERT_EQ(id_attr1.product_client_type_set.size(), 5);

}

TEST_F(TestIdDimAttrSuite, compute_bucket_ip_set) { 
    std::ifstream ifs("./test_data_attr.txt");
    std::vector<std::string> inputs;
    std::string s;
    while (getline(ifs, s)) {
        inputs.push_back(s);
    }
    ifs.close();
    std::string raw_details = inputs[10];
    
    IdAttr id_attr;
    compute_id_attr(raw_details, &id_attr);
    ASSERT_EQ(id_attr.bucket_ip_set.size(), 1);
    ASSERT_EQ(id_attr.bucket_ip_set[0], 1972603697);

    raw_details = inputs[11];
    compute_id_attr(raw_details, &id_attr);
    ASSERT_EQ(id_attr.bucket_ip_set.size(), 2);
    ASSERT_EQ(id_attr.bucket_ip_set[0], 1972603697);
    ASSERT_EQ(id_attr.bucket_ip_set[1], 1972603698);

    raw_details = inputs[12];
    compute_id_attr(raw_details, &id_attr);
    ASSERT_EQ(id_attr.bucket_ip_set.size(), 0);

    raw_details = inputs[13];
    compute_id_attr(raw_details, &id_attr);
    ASSERT_EQ(id_attr.bucket_ip_set.size(), 0);
}

}
}
}
