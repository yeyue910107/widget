if [[ "$1" = "" || "$1" = "build" ]]; then
    echo $1
    mkdir -p output/bin
    mkdir -p tar
    cp src/* output/bin/
    mkdir -p resource/bin
    tar -cvf resource/bin/ip_net_type_lib.tar output
elif [ "$1" = "clean" ]; then
    echo "clean"
    rm -rf output
    rm -rf tar
    rm -rf resource/bin
else
    echo 1
fi
