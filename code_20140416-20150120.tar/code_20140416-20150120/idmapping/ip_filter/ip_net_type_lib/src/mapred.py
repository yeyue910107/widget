#!/usr/bin/env python2.7
# -*- coding: utf-8 -*-

################################################################################
#
# Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
Brief: get ip and net type from udw_ip_loc_stat,
       make segments for 2/3/4G ips in the same segment(A.B.C.X)
Date: 2014.12.09
Author: yeyue@baidu.com
"""
import sys
import time
import pybistreaming
import json

def ip2int(ip):
    """ip string to int
    """
    ip_fields = ip.split(".")
    if len(ip_fields) != 4:
        return 0
    return int(ip_fields[0]) * 256 * 256 * 256 + \
           int(ip_fields[1]) * 256 * 256 + \
           int(ip_fields[2]) * 256 + \
           int(ip_fields[3])


def ip2key(ip, n=4):
    """ip alignment for partition
    """
    ip_fields = ip.split(".")
    if len(ip_fields) == 4:
        ip_fields = ip_fields[0:n]
        key = '.'.join([seg.zfill(3) for seg in ip_fields])
        return key
    return ""

    
class Index(object):
    """Papi read fields index
    """
    table_name = 0
    ip = 1
    ip_net_type = 2
    fields_num = 3 


class IdAttributeMapper(pybistreaming.BistreamingMapper):
    """extract fields we need
    """
    def on_task_begin(self):
        """Obviously
        """
        print >> sys.stderr, "on_task_begin"
        return 0

    def on_task_end(self):
        """Obviously
        """
        print >> sys.stderr, "on_task_end"
        return 0

    def on_task_cancel(self):
        """Obviously
        """
        print >> sys.stderr, "on_task_cancel"
        return 0

    def map(self, input_record):
        """map
        """
        key = input_record.key()
        value = input_record.value()

        fields = value.split("\0")
        if len(fields) !=  Index.fields_num:
            print >> sys.stderr, "fields num: ", len(fields)
            return 0
        ip = fields[Index.ip]
        ip_net_type = fields[Index.ip_net_type]
        
        #if ip_net_type != "" and ip_net_type != "unknown" and ip_net_type != "ps":
        if ip_net_type != "":
            output_key = ip2key(ip, 3)
            #output_key = ip2key(ip)
            if output_key != "":
                output_value = str([ip, ip_net_type])
                print >> sys.stderr, output_key, output_value
                self.emit(output_key, output_value)

        return 0


class IdAttributeReducer(pybistreaming.BistreamingReducer):
    """make segments for 2/3/4G ips in the same segment(A.B.C.x)
    """
    def on_task_begin(self):
        """Obviously
        """
        return 0

    def on_task_end(self):
        """Obviously
        """
        return 0

    def reduce(self, key, itervalues):
        """reduce
        """
        values = list(itervalues)

        values.sort(cmp=lambda x, y: cmp(ip2int(eval(x)[0]), ip2int(eval(y)[0])))
        (prev_ip, prev_net_type) = eval(values[0])
        last_ip = prev_ip

        for value in values:
            [cur_ip, cur_net_type] = eval(value)
            #print >> sys.stderr, "current:", cur_ip, cur_net_type
            if cur_net_type != prev_net_type:
                #if prev_net_type == "wifi":
                #if prev_net_type != "" and prev_net_type != "unknown" and prev_net_type != "ps":
                #if prev_net_type != "":
                if prev_net_type == "2g" or \
                   prev_net_type == "3g" or \
                   prev_net_type == "4g":
                    print >> sys.stderr, '|'.join([prev_ip, last_ip, prev_net_type])
                    self.emit(ip2key(prev_ip), '|'.join([prev_ip, last_ip, prev_net_type]))
                prev_net_type = cur_net_type
                prev_ip = cur_ip
            last_ip = cur_ip
	
        #if prev_net_type == "wifi":
        #if prev_net_type != "" and prev_net_type != "unknown" and prev_net_type != "ps":
        #if prev_net_type != "":
        if prev_net_type == "2g" or \
           prev_net_type == "3g" or \
           prev_net_type == "4g":
            print >> sys.stderr, '|'.join([prev_ip, last_ip, prev_net_type])
            self.emit(ip2key(prev_ip), '|'.join([prev_ip, last_ip, prev_net_type]))
        return 0


class IdAttributeReducer2(pybistreaming.BistreamingReducer):
    """merge to one reducer and sort
    """
    def on_task_begin(self):
        return 0

    def on_task_end(self):
        return 0

    def reduce(self, key, itervalues):
        """reduce
        """
        for value in itervalues:
            self.emit("", value)
        return 0


def main():
    """main
    """
    framework = pybistreaming.BistreamingFramework(
        mapper=IdAttributeMapper(), reducer=IdAttributeReducer())
    task = sys.argv[1]
    if "run_map" == task:
        return framework.run_map()
    elif "run_reduce" == task:
        return framework.run_reduce()
    elif "run_reduce2" == task:
        job2 = pybistreaming.BistreamingFramework(
            mapper=None, reducer=IdAttributeReducer2())
        job2.run_reduce()
    else:
        logging.warning("task type:%s error".format(task))
        return -1

if __name__ == '__main__':
    sys.exit(main())
