#!/usr/bin/env python2.7
# -*- coding: utf-8 -*-

################################################################################
#
# Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
Date: 2014.11.18
Author: yeyue@baidu.com

"""
import sys
sys.path.append(".")
import pybistreaming
import unittest
import mapred

class TestCase(unittest.TestCase):
    """test
    """
    def test_map(self):
        """test_map
        """
        mapper = mapred.MyMapper()
        records = open("data/test_map.txt").readlines()
        for record in records:
            mapper.map(record.strip())

    def test_reduce(self):
        """test_reduct
        """
        reducer = mapred.MyReducer()
        records = open("data/test_reduce.txt").readlines()
        records = [record.strip() for record in records]
        reducer.reduce("", records)

if __name__ == '__main__':
    unittest.main()
