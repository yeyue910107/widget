tar -xf python2.7.tar
./python2.7/bin/python2.7 mapred.py run_reduce
