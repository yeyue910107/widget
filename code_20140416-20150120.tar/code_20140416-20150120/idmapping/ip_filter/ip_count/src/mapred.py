#!/usr/bin/env python2.7
# -*- coding: utf-8 -*-

################################################################################
#
# Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
Brief:  Preprocess ip client type count for idmapping
Date:   2014.12.12
Author: hanzhao@baidu.com
        yeyue@baidu.com
"""
import sys
import time
import pybistreaming

class Index(object):
    """Papi read fields index of udw_ip_loc_base
    """
    id_type = 1
    ip_attr_0 = 2                         # ip attr
    product_clienttype_attr = 3           # product client type
    event_day = 4                         # partition
    fields_num = 5

    
class IdType(object):
    """ See http://wiki.baidu.com/display/IDMAPPING/COMMON
    """
    ADID       = 0
    BAIDUID    = 1
    CPROID     = 2
    CUID       = 3
    IMEI       = 4
    PCCODE     = 5
    UDWID      = 6
    USERID     = 7
    WISE_ID    = 8
    WEIBO_ID   = 9
    IQIYI_ID   = 10
    BD91_ID    = 11
    MAC        = 12
    UDW_RECORD = 13
    COMMON_ID  = 14   
    IDFA       = 15
    

class MyMapper(pybistreaming.BistreamingMapper):
    """extract ip and client_type from udw_id_attribute_all
    """
    def on_task_begin(self):
        """before map
        """
        print >> sys.stderr, "on_task_begin"
        return 0

    def on_task_end(self):
        """after map
        """
        print >> sys.stderr, "on_task_end"
        return 0

    def on_task_cancel(self):
        """Obviously
        """
        print >> sys.stderr, "on_task_cancel"
        return 0

    def __get_client_type(self, ct_str):
        CLIENT_TYPE_MAP = {\
            "mobile":"mobile_app", \
            "mobile__from_event":"mobile_app", \
            "mobile_app":"mobile_app", \
            "mobile_app__from_event":"mobile_app", \
            "pad_app":"pad_app", \
            "pad_app__from_event":"pad_app", \
            "pad_web":"pad_web", \
            "pad_web__from_event":"pad_web", \
            "pc":"pc_web", \
            "pc__from_event":"pc_web", \
            "pc_web":"pc_web", \
            "pc_web__from_event":"pc_web", \
            "__from_event":"unknown", \
            "__HIVE_DEFAULT_PARTITION__":"unknown", \
            "other":"unknown", \
            "other__from_event":"unknown", \
            "unknown":"unknown", \
            "unknown__from_event":"unknown", \
            "mobile_web":"wap_common", \
            "wap_common":"wap_common", \
            "wap_common__from_event":"wap_common", \
            "wap_smart":"wap_smart", \
            "wap_smart__from_event":"wap_smart", \
            "webapp":"wap_smart", \
            "webapp__from_event":"wap_smart"}

        if ct_str in CLIENT_TYPE_MAP.keys():
            return CLIENT_TYPE_MAP[ct_str]
        else:
            return "unknown"

    def map(self, input_record):
        """map
        """
        key = input_record.key()
        value = input_record.value()
        #value = input_record

        fields = value.split("\0")
        if len(fields) !=  Index.fields_num:
            print >> sys.stderr, "fields num error", str(fields)
            return 0
        
        id_type = int(fields[Index.id_type])
        if id_type != IdType.BAIDUID and \
            id_type != IdType.CUID and \
            id_type != IdType.IMEI and \
            id_type != IdType.MAC and \
            id_type != IdType.IDFA:
            return 0
            
        ip_set = set()
        
        ip_attr_list = eval(fields[Index.ip_attr_0])
        for item in ip_attr_list:
            ip_str = item.split(",")[0]
            if ip_str != "":
                ip_set.add(ip_str)
        
        clienttype_set = set()
        product_set = set()
        clienttype_attr_list = eval(fields[Index.product_clienttype_attr])
        for item in clienttype_attr_list:
            ct_fields = item.split(",")
            product = ct_fields[0]
            ct = ct_fields[1]
            if product != "":
                product_set.add(product)
            if ct != "":
                real_ct = self.__get_client_type(ct)
                clienttype_set.add(real_ct)
        
        clienttype = ""
        # if multiple client types
        # baiduid -> pc_web, else unknown
        if len(clienttype_set) > 1:
            if id_type == IdType.BAIDUID:
                clienttype = 'pc_web'
            else:
                clienttype = 'unknown'
        elif len(clienttype_set) == 1:
            clienttype = list(clienttype_set)[0]
        else:
            clienttype = 'unknown'

        # client type is unknown
        # if only ps product -> pc_web
        # if only wise product -> wap_common
        if clienttype == 'unknown' and len(product_set) == 1:
            if 'ps' in product_set:
                clienttype = 'pc_web'
            elif 'wise' in product_set:
                clienttype = 'wap_common'
        
        for ip in ip_set:
            out_key = ip
            out_value = clienttype
            #print >> sys.stderr, out_key, out_value
            self.emit(out_key, out_value)
       
        return 0


class MyReducer(pybistreaming.BistreamingReducer):
    """count pc/wise/unknown id num of each ip
    """
    def on_task_begin(self):
        """Obviously
        """
        print >> sys.stderr, "on_task_begin"
        return 0

    def on_task_end(self):
        """Obviously
        """
        print >> sys.stderr, "on_task_end"
        return 0

    def reduce(self, key, itervalues):
        """reduce
        """
        client_type_count = {\
            "pc_web":0, \
            "wap_common":0, \
            "wap_smart":0, \
            "mobile_app":0, \
            "pad_app":0, \
            "pad_web":0, \
            "unknown":0}

        for value in itervalues:
            client_type_count[value] += 1

        int_pc = client_type_count['pc_web']
        int_wise = client_type_count['wap_common'] + \
            client_type_count['wap_smart'] + \
            client_type_count['mobile_app'] + \
            client_type_count['pad_app'] + \
            client_type_count['pad_web']
        int_unknown = client_type_count['unknown']
        
        out_value = '\0'.join([str(int_pc), str(int_wise), str(int_unknown)])
        print >> sys.stderr, key, out_value
        
        self.emit(key, out_value)
        
        return 0


def main():
    """main
    """
    job = pybistreaming.BistreamingFramework(
        mapper=MyMapper(), reducer=MyReducer())
    task = sys.argv[1]
    if "run_map" == task:
        return job.run_map()
    elif "run_reduce" == task:
        return job.run_reduce()
    else:
        log_warn("task type:%s error" % task)
        return -1

if __name__ == '__main__':
    sys.exit(main())
    
