if [[ "$1" = "" || "$1" = "build" ]]; then
    echo $1
    mkdir -p output/bin
    mkdir -p tar
    mkdir -p resource/bin
    cp src/* output/bin/
    tar -cvf resource/bin/ip_count.tar output
elif [ "$1" = "clean" ]; then
    echo "clean"
    rm -rf output
    rm -rf tar
    rm -f resource/bin/id_count.tar
    rm -rf resource/bin
else
    echo 1
fi
