if [[ "$1" = "" || "$1" = "build" ]]; then
    echo $1
    mkdir -p output/bin
    mkdir -p tar
    cp -r src/* output/bin/
    mkdir -p resource
    tar -cvf resource/idmapping_tieba_dict.tar output
    mkdir idmapping_tieba_dict/
    mkdir idmapping_tieba_dict/DQConf
    mkdir idmapping_tieba_dict/so
    mkdir idmapping_tieba_dict/file
    mkdir idmapping_tieba_dict/flow
    mv resource/idmapping_tieba_dict.tar idmapping_tieba_dict/file
    cp resource/run_tieba_dict.sh idmapping_tieba_dict/file
    cp resource/dag_idmapping_tieba_dict.xml idmapping_tieba_dict/dag.xml
    mkdir -p output/tar
    tar -cvf output/tar/idmapping_tieba_dict.tar idmapping_tieba_dict/*

elif [ "$1" = "clean" ]; then
    echo "clean"
    rm -rf output
    rm -rf tar
    rm -rf idmapping_tieba_dict/
    rm -rf resource/bin/
else
    echo 1
fi
