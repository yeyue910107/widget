#!/usr/bin/env python2.7
# -*- coding: utf-8 -*-

################################################################################
#
# Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
Brief: get tieba list with probability of trending to log in after filtering
low and high pv tiebas
Algorithm: 
assume in N days, the probability of trending to log in a tieba for K days is pk.
then 
    pk^K = baiduid_K_days_count / (baiduid_N_days_count * C(N,K))
    p = avg(sum(pk))
for now N=10, K=3,4,5,6
    
Date: 2015.01.11
Author: yeyue@baidu.com
"""

import sys
import math
import operator
import itertools
import pybistreaming

class TiebaViewIndex(object):
    """Papi read fields index of udw_event_attribute
    """
    table_name = 0
    event_action = 1
    baiduid = 2
    tieba_fid = 3
    event_day = 4
    fields_num = 5


class TiebaStatIndex(object):
    """Papi read fields index of udw_tieba_stat
    """
    table_name = 0
    tieba_fid = 1
    tieba_pv = 2
    fields_num = 3


class Conf(object):
    """conf
    """
    LOW_DAY_PV_LIMIT = 1
    HIGH_DAY_PV_LIMIT = 10000
    DAYS = 10
    MIN_DAY = 3
    MAX_DAY = 6


class Util(object):
    """util
    """
    @staticmethod
    def c(n, k):
        """ combination
        """
        return reduce(operator.mul, range(n - k + 1, n + 1)) /\
            reduce(operator.mul, range(1, k + 1)) 


class TiebaStatMapper(pybistreaming.BistreamingMapper):
    """extract fields we need
    """
    def on_task_begin(self):
        """Obviously
        """
        print >> sys.stderr, "on_task_begin"
        return 0

    def on_task_end(self):
        """Obviously
        """
        print >> sys.stderr, "on_task_end"
        return 0

    def on_task_cancel(self):
        """Obviously
        """
        print >> sys.stderr, "on_task_cancel"
        return 0

    def map(self, input_record):
        """map 
           input1: get baiduid-event_day pairs of each tieba
           input2: filter low and high pv tiebas, make tag 
        """
        value = input_record.value()
        # for unit test
        #value = input_record
        fields = value.split("\0")

        if len(fields) == TiebaViewIndex.fields_num and \
            fields[TiebaViewIndex.table_name] == "udw_event_attribute" and \
            fields[TiebaViewIndex.event_action] == 'udw.udw_event.tieba_view':
            tieba_fid = fields[TiebaViewIndex.tieba_fid]
            baiduid = fields[TiebaViewIndex.baiduid]
            event_day = fields[TiebaViewIndex.event_day]
            if tieba_fid != '0' and \
                tieba_fid != '' and \
                baiduid != '0' and \
                baiduid != '' and \
                baiduid != '-':
                self.emit(tieba_fid, '#'.join([baiduid, event_day]))
                #print >> sys.stderr, tieba_fid + '\t' + '#'.join([baiduid, event_day])

        elif len(fields) == TiebaStatIndex.fields_num and \
            fields[TiebaStatIndex.table_name] == "udw_tieba_stat":
            try:
                tieba_fid = fields[TiebaStatIndex.tieba_fid]
                tieba_pv = int(fields[TiebaStatIndex.tieba_pv])
                if tieba_pv <= Conf.LOW_DAY_PV_LIMIT * Conf.DAYS:
                    pybistreaming.incr_counter(\
                        group="TIEBA", counter="TIEBA_BLACK_LIST_COUNT_LOW", amount="1")
                if tieba_pv >= Conf.HIGH_DAY_PV_LIMIT * Conf.DAYS:
                    pybistreaming.incr_counter(\
                        group="TIEBA", counter="TIEBA_BLACK_LIST_COUNT_HIGH", amount="1")
                    
                if tieba_fid != '0' and \
                    tieba_fid != '' and \
                    tieba_pv > Conf.LOW_DAY_PV_LIMIT * Conf.DAYS and \
                    tieba_pv < Conf.HIGH_DAY_PV_LIMIT * Conf.DAYS:
                    pybistreaming.incr_counter(\
                        group="TIEBA", counter="TIEBA_WHITE_LIST_COUNT", amount="1")
                    self.emit(tieba_fid, "stat")
                    #print >> sys.stderr, tieba_fid + '\tstat'
            except:
                return 0

        return 0


class TiebaStatReducer(pybistreaming.BistreamingReducer):
    """ reducer
    """
    def on_task_begin(self):
        """Obviously
        """
        return 0

    def on_task_end(self):
        """Obviously
        """
        return 0

    def reduce(self, key, itervalues):
        """ filter tieba_fid by join on 'stat' tag
            then get the probability 
        """
        is_stat = False
        id_day_map = {}

        #itervalues2 = itertools.tee(itervalues, 1)
        #lst = list(itervalues)
        #for value in lst:
        lst = []
        for value in itervalues:
            if value == 'stat':
                is_stat = True
            if len(lst) <= Conf.HIGH_DAY_PV_LIMIT * Conf.DAYS:
                lst.append(value)

        if is_stat:
            #for value in itervalues2[0]:
            for value in lst:
                if value != 'stat':
                    [baiduid, event_day] = value.split('#')
                    id_day_map.setdefault(baiduid, set()).add(event_day)
            
            prob_avg = 0.0
            baiduid_all_num = len(id_day_map)
            if baiduid_all_num == 0:
                self.emit(key, str(prob_avg))
                return 0
            
            baiduid_count = [0] * (Conf.DAYS + 1)
            prob = [0.0] * (Conf.DAYS + 1)
            for item in id_day_map.items():
                if len(item[1]) >= Conf.MIN_DAY:
                    for i in xrange(Conf.MIN_DAY, len(item[1]) + 1):
                        baiduid_count[i] += 1
			    
            assert(Conf.MIN_DAY > 0)
            for k in xrange(Conf.MIN_DAY, Conf.MAX_DAY + 1):
                prob[k] = math.pow(\
                    (float)(baiduid_count[k]) / (baiduid_all_num * Util.c(Conf.DAYS, k)),\
                    1 / (float)(k))
                #print >> sys.stderr, k, baiduid_count[k], baiduid_all_num, Util.c(Conf.DAYS, k), prob[k]

            assert(Conf.MAX_DAY >= Conf.MIN_DAY)
            prob_avg = sum(prob) / (Conf.MAX_DAY - Conf.MIN_DAY + 1)

            """
            output_value = [str(item) for item in \
                [baiduid_count[1], \
                baiduid_count[2], \
                baiduid_count[3], \
                baiduid_count[4], \
                baiduid_count[5], \
                baiduid_count[6], \
                baiduid_all_num, \
                prob_avg]]
            self.emit(key, '#'.join(output_value))
            """
            self.emit(key, str(prob_avg))

        return 0


class TiebaStatReducer2(pybistreaming.BistreamingReducer):
    """ reducer2
    """
    def on_task_begin(self):
        """Obviously
        """
        return 0

    def on_task_end(self):
        """Obviously
        """
        return 0

    def reduce(self, key, itervalues):
        """ merge
        """
        for value in itervalues:
            self.emit(key, value)
        return 0


def main():
    """main
    """
    framework = pybistreaming.BistreamingFramework(
        mapper=TiebaStatMapper(), reducer=TiebaStatReducer())
    task = sys.argv[1]
    if "run_map" == task:
        return framework.run_map()
    elif "run_reduce" == task:
        return framework.run_reduce()
    elif "run_reduce2":
        job2 = pybistreaming.BistreamingFramework(
            mapper=None, reducer=TiebaStatReducer2())
        job2.run_reduce()
    else:
        logging.warning("task type:%s error".format(task))
        return -1

if __name__ == '__main__':
    sys.exit(main())
