#!/bin/bash
export LANG='en_US'

# ETL-Framework 框架输入的参数为
# {DAY} {HOUR} {MIN} {WORK_PATH} {HADOOP_HOME} {LIB_JARS_PATH} {JOB_NAME} {queue_name} {username,password} {zk_path}
#   1     2      3       4           5               6             7          8              9                10
#-----------------------------------------------conf begin-------------------------------------------
DAY=${1}
HOUR=${2}
JOB_WORK_PATH=${4}
HADOOP_HOME=${5}
JAVA_HOME="${HADOOP_HOME}/../java6"
LIB_DIR=${6}
JOB_NAME=${7}
QUEUE_NAME=${8}
HADOOP_UGI=${9}
PAPI_META=${10}

cd $JOB_WORK_PATH/bin
echo $JOB_WORK_PATH
tar xf ps_id_all.tar

################################################################################

#WRITE_META="szwg-qatest-dpf005.szwg01.baidu.com:2181/tunningbox/dtmeta_tunningbox_3"
#READ_META="szwg-qatest-dpf005.szwg01.baidu.com:2181/tunningbox/dtmeta_tunningbox_2"
#WRITE_META="szwg-qatest-dpf005.szwg01.baidu.com:2181/tunningbox/dtmeta_tunningbox_2"
READ_META=${PAPI_META}
WRITE_META=${PAPI_META}

NOW=`date +%F' '%H:'00:00' -d "$1 $2"`
LAST_DAY=`date +%Y%m%d -d "${NOW} +0800 -1 day"`

IS_TOPID='0'
#BUCKETS='ip'
#FRAG='25'
#INPUT_PROJECT="udw_id_attribute_all_group.event_day=${DAY}.is_topid=${IS_TOPID}.buckets=${BUCKETS}.fragment=${FRAG}"
#INPUT_PROJECT="udw_id_attribute_all.event_day=${DAY}.is_topid=${IS_TOPID}"
INPUT_PROJECT="udw_id_attribute_delta.event_day=${DAY}.is_topid=${IS_TOPID}"
INPUT_COLS="id_type,\
id,\
ip_attr_0,\
product_clienttype_attr"

INPUT_INFO_FILE="papi_info_file"

for jar in ${LIB_DIR}/*.jar ; do
    HADOOP_CLASSPATH=$HADOOP_CLASSPATH:$jar
done
export HADOOP_CLASSPATH
echo ${LIB_DIR}

${JAVA_HOME}/bin/java -jar ${LIB_DIR}/udw-program-api.jar GetJobInfo \
    -server ${READ_META} \
    -user "InternalUser" \
    -inputProj ${INPUT_PROJECT} \
    -inputCols ${INPUT_COLS} \
    -cluster "hdfs://yq01-wutai-hdfs.dmop.baidu.com:54310" \
    -ifile ${INPUT_INFO_FILE}
    #-inputProj ${INPUT_PROJECT2} \

if [ $? -ne 0 ];then
    echo "Getting Input Job Info fails"
    exit 1
fi
echo `(date)`

echo "papi GetJobInfo OK"

# get output table info
#OUTPUT_TABLES="udw_id_attribute_record_all.event_day=${DAY}"
#OUTPUT_INFO_FILE="papi_out_info_file"
#${JAVA_HOME}/bin/java -jar ${LIB_DIR}/udw-program-api.jar com.baidu.udw.mapred.GetJobInfo \
#    -server ${WRITE_META} \
#    -user "InternalUser" \
#    -output ${OUTPUT_TABLES} \
#    -ofile ${OUTPUT_INFO_FILE}
#echo `(date)`

#if [ $? -ne 0 ];then
#    echo "Getting Output Job Info fails"
#    exit 1
#fi

OUTPUT_DIR="/app/dt/udw/idmapping/yeyue/ps_id_all/${DAY}"
${HADOOP_HOME}/bin/hadoop fs -rmr ${OUTPUT_DIR}

INPUT_DIR=${INPUT_INFO_FILE}  
LIB_JARS=""
for jar in ${LIB_DIR}/*.jar; do
    if [ -z $LIB_JARS ]; then
        LIB_JARS="${jar}"
    else LIB_JARS="${LIB_JARS},${jar}";
    fi
done

echo "jars:" $LIB_JARS
${HADOOP_HOME}/bin/hadoop bistreaming -libjars ${LIB_JARS} \
    -D hadoop.job.ugi="${HADOOP_UGI}" \
    -D udw.mapred.input.info=${INPUT_INFO_FILE} \
    -D mapred.map.tasks=2000 \
    -D mapred.reduce.tasks=1000 \
    -D mapred.job.map.capacity=3000 \
    -D mapred.job.reduce.capacity=2000 \
    -D abaci.appmaster.memory.min.mb=1000 \
    -D abaci.job.map.child.memory.mb=3000 \
    -D udw.mapred.streaming.separator=0x0 \
    -D child.max.memory=3000 \
    -D stream.memory.limit=2000 \
    -D mapred.job.priority=HIGH \
    -D udw.mapred.combine.inputformat=true \
    -D mapred.job.name="${JOB_NAME}" \
    -input ${INPUT_DIR} \
    -output ${OUTPUT_DIR} \
    -inputformat com.baidu.udw.mapred.MultiTableInputFormat \
    -outputformat org.apache.hadoop.mapred.TextOutputFormat \
    -mapper 'bash map_task.sh' \
    -reducer 'bash reduce_task.sh' \
    -file ./output/bin/mapred.py \
    -file ./output/bin/pybistreaming.py \
    -file ./output/bin/map_task.sh \
    -file ./output/bin/reduce_task.sh \
    -cacheFile hdfs://yq01-wutai-hdfs.dmop.baidu.com:54310/app/dt/udw/idmapping/tar/python2.7.tar#python2.7.tar \
    -file ./${INPUT_INFO_FILE} \

    #-outputformat com.baidu.udw.mapred.MultiTableOutputFormat \
#    -outputformat org.apache.hadoop.mapred.TextOutputFormat \

err=$?
if [ $err -ne 0 ];then
    echo "M/R Job 1 Info fails, error:" $err
    exit 1
fi
echo `(date)`

#commit result
#${JAVA_HOME}/bin/java -jar ${LIB_DIR}/udw-program-api.jar com.baidu.udw.mapred.OutputCommit \
#    -server ${WRITE_META} \
#    -outputJobInfo ${OUTPUT_INFO_FILE} \
#    -outputDir ${OUTPUT_DIR}

#if [ $? -ne 0 ];then
#    echo "Commit fails"
#    exit 1
#fi

cd -
echo "~~~job sucessful~~~"
