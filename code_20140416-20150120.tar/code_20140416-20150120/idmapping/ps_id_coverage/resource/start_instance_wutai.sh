# {DAY} {HOUR} {MIN} {WORK_PATH} {HADOOP_HOME} {LIB_JARS_PATH} {JOB_NAME} {queue_name} {username,password} {zk_path}
#   1     2      3       4           5               6             7          8              9                10
run_script=$1
day=$2
hour=$3
if [ "" = "$run_script" ]; then
    echo "need $1 run_script.sh"
    exit 1
fi
if [ "" = "$day" ]; then
    echo "need $2 day"
    exit 1
fi
if [ "" = "$hour" ]; then
    echo "hour set default 00"
    hour=00
fi

#bash $run_script $day $hour 00 . /home/udw/sunjie04/hadoop-client/hadoop_yulong /home/udw/yangxiaoliang01/papi_sandbox/lib "${run_script}_${day}${hour}" udw dt-udw,udwudw db-dt-udw10.db01:2183,jx-dt-udw06.jx:2183,jx-dt-udw07.jx:2183,tc-dt-udw01.tc:2183,tc-dt-udw02.tc:2183/biglog/metadebug
bash $run_script $day $hour 00 . /home/udw/yeyue/hadoop-client/hadoop_wutai /home/udw/yeyue/papi_sandbox/lib "${run_script}_${day}${hour}" udw dt-udw,dt-udw udw-off-zk.dmop.baidu.com:2183/biglog/metadebug
