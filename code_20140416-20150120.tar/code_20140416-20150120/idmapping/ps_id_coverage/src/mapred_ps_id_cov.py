#!/usr/bin/env python2.7
# -*- coding: utf-8 -*-

################################################################################
#
# Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
evaluate the strategy's coverage of ps baiduid
Date: 2014.12.11
Author: yeyue@baidu.com
"""

import sys
import pybistreaming

class Index(object):
    """Papi read fields index of udw_id_attribute_id_pair_sim
    """
    table_name = 0
    id_1 = 1
    id_1_type = 2
    id_1_timestamps = 3
    id_2 = 4
    id_2_type = 5
    id_2_timestamps = 6
    sim = 7
    id_1_client_type = 8
    id_2_client_type = 9
    event_day = 10
    buckets = 11
    fragment = 12
    fields_num = 13


class Conf(object):
    """conf
    """
    SIM_THRESHOLD = 0.5


class IdAttributeMapper(pybistreaming.BistreamingMapper):
    """extract fields we need
    """
    def on_task_begin(self):
        """Obviously
        """
        print >> sys.stderr, "on_task_begin"
        return 0

    def on_task_end(self):
        """Obviously
        """
        print >> sys.stderr, "on_task_end"
        return 0

    def on_task_cancel(self):
        """Obviously
        """
        print >> sys.stderr, "on_task_cancel"
        return 0

    def map(self, input_record):
        """ input1: select baiduid from id_pair_sim table where sim >= SIM_THRESHOLD
            input2: ps baiduids from all_group
        """
        value = input_record.value()
        fields = value.split("\0")

        if len(fields) == Index.fields_num and \
            fields[Index.table_name] == "udw_id_attribute_id_pair_sim":
            if float(fields[Index.sim]) >= Conf.SIM_THRESHOLD:
                if int(fields[Index.id_1_type]) == 1:
                    #print >> sys.stderr, "id_pair1: ", fields[1]
                    if fields[Index.id_1] != fields[Index.id_2]:
                        self.emit(fields[Index.id_1], "get")
                        pybistreaming.incr_counter(\
                            group="PsBaiduduCoverage", counter="ID_PAIR_PS_BAIDU_NUM", amount="1")

        elif len(fields) == 1:
            #print >> sys.stderr, "id: ", fields[0]
            pybistreaming.incr_counter(\
                group="PsBaiduduCoverage", counter="ID_ALL_PS_BAIDU_NUM", amount="1")
            self.emit(fields[0].strip(), "all")

        return 0


class IdAttributeReducer(pybistreaming.BistreamingReducer):
    """ reducer
    """
    def on_task_begin(self):
        """Obviously
        """
        return 0

    def on_task_end(self):
        """Obviously
        """
        return 0

    def reduce(self, key, itervalues):
        """ join id_pair's ps baiduid with all_group's ps baiduid and count
        """
        is_get = False
        is_all = False
        for value in itervalues:
            if value == "get":
                is_get = True
            if value == "all":
                is_all = True
            
        if is_get and is_all:
            self.emit(key, "")
            pybistreaming.incr_counter(\
                group="PsBaiduduCoverage", counter="COV_PS_BAIDU_NUM", amount="1")
        return 0


def main():
    """main
    """
    framework = pybistreaming.BistreamingFramework(
        mapper=IdAttributeMapper(), reducer=IdAttributeReducer())
    task = sys.argv[1]
    if "run_map" == task:
        return framework.run_map()
    elif "run_reduce" == task:
        return framework.run_reduce()
    else:
        logging.warning("task type:%s error".format(task))
        return -1

if __name__ == '__main__':
    sys.exit(main())
