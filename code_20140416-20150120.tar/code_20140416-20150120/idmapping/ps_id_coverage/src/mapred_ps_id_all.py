#!/usr/bin/env python2.7
# -*- coding: utf-8 -*-

################################################################################
#
# Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
get ps baiduid from udw_id_attribute_all
Date: 2014.12.11
Author: yeyue@baidu.com
"""

import sys
import pybistreaming

class Index(object):
    """ table index of udw_id_attribute_all or udw_id_attribute_all_group
    """
    table_name = 0
    id_type = 1
    id = 2
    ip_attr = 3
    product_clienttype_attr = 4
    fields_num = 5


class IdType(object):
    """ See http://wiki.baidu.com/display/IDMAPPING/COMMON
    """
    ADID       = 0
    BAIDUID    = 1
    CPROID     = 2
    CUID       = 3
    IMEI       = 4
    PCCODE     = 5
    UDWID      = 6
    USERID     = 7
    WISE_ID    = 8
    WEIBO_ID   = 9
    IQIYI_ID   = 10
    BD91_ID    = 11
    MAC        = 12
    UDW_RECORD = 13
    COMMON_ID  = 14   
    IDFA       = 15


class ProductType(object):
    """ product type
    """
    PROD_UNKNOWN = 0
    PROD_BAIKE = 1
    PROD_IKNOW = 2
    PROD_LBS = 3
    PROD_NOVA = 4
    PROD_PS = 5
    PROD_TIEBA = 6
    PROD_WENKU = 7
    PROD_WISE = 8


class IdAttributeMapper(pybistreaming.BistreamingMapper):
    """extract fields we need
    """
    def on_task_begin(self):
        """Obviously
        """
        print >> sys.stderr, "on_task_begin"
        return 0

    def on_task_end(self):
        """Obviously
        """
        print >> sys.stderr, "on_task_end"
        return 0

    def on_task_cancel(self):
        """Obviously
        """
        print >> sys.stderr, "on_task_cancel"
        return 0

    def map(self, input_record):
        """ get ps baiduid from id_attr_all
        """
        value = input_record.value()
        fields = value.split("\0")

        if len(fields) !=  Index.fields_num:
            print >> sys.stderr, "fields num error", str(fields)
            return 0
        id_type = fields[Index.id_type]
        id = fields[Index.id]

        if int(id_type) == IdType.BAIDUID:
            if id != '' and id != '-' and id != '0':
                #print >> sys.stderr, "product attr: ", fields[Index.product_clienttype_attr]
                product_attr_list = eval(fields[Index.product_clienttype_attr])
                for product_attr in product_attr_list:
                    product_fields = product_attr.split(",")
                    assert(len(product_fields) == 3)
                    product = product_fields[0]
                    #if int(product) == ProductType.PROD_PS:
                    if product == 'ps':
                        #print >> sys.stderr, "id: ", id, "ps: ", product
                        pybistreaming.incr_counter(\
                            group="PsBaiduduCoverage", counter="PS_BAIDU_NUM", amount="1")
                        self.emit(id, "")
                        return 0
                
        return 0


class IdAttributeReducer(pybistreaming.BistreamingReducer):
    """ reducer
    """
    def on_task_begin(self):
        return 0

    def on_task_end(self):
        return 0

    def reduce(self, key, itervalues):
        """reduce distinct
        """
        self.emit(key, "")
        return 0


def main():
    """ main
    """
    framework = pybistreaming.BistreamingFramework(
        mapper=IdAttributeMapper(), reducer=IdAttributeReducer())
    task = sys.argv[1]
    if "run_map" == task:
        return framework.run_map()
    elif "run_reduce" == task:
        return framework.run_reduce()
    else:
        logging.warning("task type:%s error".format(task))
        return -1

if __name__ == '__main__':
    sys.exit(main())
