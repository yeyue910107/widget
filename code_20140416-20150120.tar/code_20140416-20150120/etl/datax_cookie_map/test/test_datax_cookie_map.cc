/***************************************************************************
 * 
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
     

      
 /**
  * @file test/test_datax_cookie_map.cc
  * @author yeyue(yeyue@baidu.com)
  * @date 2014-07-09 11:54:57
  * @brief 
  *  
  **/

#include "gtest/gtest.h"
#include "datax_cookie_map.h"

int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
};

class test_datax_cookie_map_suite:public :: testing::Test {
    protected:
            test_datax_cookie_map_suite() {};
            virtual ~test_datax_cookie_map_suite() {};
            virtual void SetUp() {};
            virtual void TearDown() {};
};

TEST_F(test_datax_cookie_map_suite, ComputeConvertTimeCase) {
    std::vector<EachColumn> in;
    std::vector<EachColumn> out;
    EXPECT_EQ(-1, ComputeConvertTime(in, out));
    
    in.resize(1);
    out.resize(8);
    in[0].value = "1405483200000";
    EXPECT_EQ(0, ComputeConvertTime(in, out));
    for (int i = 0; i < out.size(); i++) {
        std::cout << out[i].value << std::endl;
    }
}

TEST_F(test_datax_cookie_map_suite, ComputeDataxUrlParams) {
    std::vector<EachColumn> in;
    std::vector<EachColumn> out;
    EXPECT_EQ(-1, ComputeDataxUrlParams(in, out));
    
    in.resize(2);
    out.resize(2);
    in[0].value = "/x.js";
    in[1].value = "/x.gif?si=40b2221d03ba33984479d5a1a425c3f4&dm=demo.com&ac=third-party-account&rnd=1405308392489";
    EXPECT_EQ(-1, ComputeDataxUrlParams(in, out));
    
    in[0].value = "/x.gif";
    EXPECT_EQ(0, ComputeDataxUrlParams(in, out));
    EXPECT_EQ("demo", out[0].value);
    EXPECT_EQ("third-party-account", out[1].value);

    in[0].value = "/x.gif";
    in[1].value = "/x.gif?si=40b2221d03ba33984479d5a1a425c3f4&dm=iqiyi&ac=third-party-account&rnd=1405308392489";
    EXPECT_EQ(0, ComputeDataxUrlParams(in, out));
    EXPECT_EQ("iqiyi", out[0].value);
    EXPECT_EQ("third-party-account", out[1].value);
}

TEST_F(test_datax_cookie_map_suite, ComputeDataxUrlParams1) {
    std::vector<EachColumn> in;
    std::vector<EachColumn> out;
    
    in.resize(2);
    out.resize(2);

    in[0].value = "/x.gif";
    in[1].value = "/x.gif?si=40b2221d03ba33984479d5a1a425c3f4&ac=third-party-account&rnd=1405308392489";
    EXPECT_EQ(0, ComputeDataxUrlParams(in, out));
    EXPECT_EQ("", out[0].value);
    EXPECT_EQ("third-party-account", out[1].value);
}

TEST_F(test_datax_cookie_map_suite, ComputeDataxUrlParams2) {
    std::vector<EachColumn> in;
    std::vector<EachColumn> out;
    
    in.resize(2);
    out.resize(2);

    in[0].value = "/x.gif";
    in[1].value = "/x.gif?dm=eduglobal.com&ac=MTE2LjEuNzcuODl8MTQwNzM2OTkzNjE1NQ%3D%3D&v=1.0.0&rnd=1407369937887";
    EXPECT_EQ(0, ComputeDataxUrlParams(in, out));
    EXPECT_EQ("eduglobal", out[0].value);
    EXPECT_EQ("MTE2LjEuNzcuODl8MTQwNzM2OTkzNjE1NQ==", out[1].value);
}
/* vim: set ts=4 sw=4: */
