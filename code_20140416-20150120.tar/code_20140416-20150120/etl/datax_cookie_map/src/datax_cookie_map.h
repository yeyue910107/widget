/***************************************************************************
 * 
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file datax_cookie_map.h
 * @author yeyue(yeyue@baidu.com)
 * @date 2014-07-09 11:52:43
 * @brief datax cookie map
 *  
 **/

#include "common_lib.h"
#include "etllib.h"

#ifndef  DATAX_COOKIE_MAP_H
#define  DATAX_COOKIE_MAP_H

namespace common_ns = baidu::dt::udw::common_lib;

extern "C" {
    int ComputeConvertTime(const std::vector<EachColumn> &in, std::vector<EachColumn> &out);

    int ComputeDataxUrlParams(const std::vector<EachColumn>& in, std::vector<EachColumn>& out);

}

#endif  //DATAX_COOKIE_MAP_H

/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
