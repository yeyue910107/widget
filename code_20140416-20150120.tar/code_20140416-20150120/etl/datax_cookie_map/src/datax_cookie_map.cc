/***************************************************************************
 * 
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 

 
/**
 * @file src/datax_cookie_map.cc
 * @author yeyue(yeyue@baidu.com)
 * @date 2014-07-09 11:52:15
 * @brief 
 *  
 **/

#include "datax_cookie_map.h"
#include "common_lib.h"

namespace common_ns = baidu::dt::udw::common_lib;

/**
 * @brief 
 *
 * @param in
 * @param out
 *
 * @return 
 */
int ComputeConvertTime(const std::vector<EachColumn> &in, std::vector<EachColumn> &out) {
    if (in.size() != 1 || out.size() != 8) {
        return -1;
    }

    std::string timestamp = in[0].value;
    std::string date_str;
    if (timestamp.size() < 3) {
        return -1;
    }
    timestamp = timestamp.substr(0, timestamp.size() - 3);

    std::vector<EachColumn> tmp_in;
    tmp_in.resize(1);
    tmp_in[0].value = timestamp;
    CommonParseTimestamp(tmp_in, out);
    
    return 0;
}

/**
 * @brief 
 *
 * @param in
 * @param out
 *
 * @return 
 */
int ComputeDataxUrlParams(const std::vector<EachColumn>& in, std::vector<EachColumn>& out) {
    if (in.size() != 2 || out.size() != 2) {
        return -1;
    }

    std::string action_name = in[0].value;
    std::string in_url = in[1].value;
    //std::cerr << "action_name: " << action_name << std::endl;
    //std::cerr << "url: " << in_url << std::endl;
    if (action_name != "/x.gif") {
        std::cerr << "invalid url: " << in_url << std::endl;
        return -1;
    }

    EachColumn &dm = out[0];
    EachColumn &ac = out[1];

    common_ns::urlparser_t result;
    static common_ns::CodeConv code_conv;
    std::string in_host = "";
    std::string param_str;

    if (common_ns::CommonParseUrlBase(in_url, in_host, false, result, &param_str) == 0) {
        if (result.params.count("dm") == 1) {
            dm.value = result.params["dm"];
            int index = dm.value.find('.');
            if (index != std::string::npos) {
                dm.value = dm.value.substr(0, index);
            }
        }
        if (result.params.count("ac") == 1) {
            if (code_conv.URLNormalize(result.params["ac"], ac.value) != 0) {
                std::cerr << "url normalize error." << std::endl;
                return -1;
            }
            //ac.value = result.params["ac"];
        }
    } else {
        std::cerr << "parse url error." << std::endl;
        return -1;
    }

    return 0;
}

/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
