/***************************************************************************
 * 
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
     

      
 /**
  * @file test/test_mgame_order.cpp
  * @author yeyue(yeyue@baidu.com)
  * @date 2014-08-18 21:40:00
  * @brief 
  *  
  **/

#include "gtest/gtest.h"
#include "mgame_order.h"

int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
};

class test_mgame_order_suite:public :: testing::Test {
    protected:
            test_mgame_order_suite() {};
            virtual ~test_mgame_order_suite() {};
            virtual void SetUp() {};
            virtual void TearDown() {};
};

TEST_F(test_mgame_order_suite, ComputeTimeCase) {
    std::vector<EachColumn> in;
    std::vector<EachColumn> out;
    EXPECT_EQ(-1, ComputeTime(in, out));
    
    in.resize(1);
    out.resize(8);
    in[0].value = "1405483200000";
    EXPECT_EQ(0, ComputeTime(in, out));
    for (std::size_t i = 0; i < out.size(); i++) {
        std::cout << out[i].value << std::endl;
    }
}

TEST_F(test_mgame_order_suite, ComputeParseCuidCase) {
    std::vector<EachColumn> in;
    std::vector<EachColumn> out;
    EXPECT_EQ(-1, ComputeParseCuid(in, out));
    
    in.resize(1);
    out.resize(2);
    in[0].value = "|317118010458568";
    EXPECT_EQ(0, ComputeParseCuid(in, out));
    EXPECT_EQ("", out[0].value);
    EXPECT_EQ("865854010811713", out[1].value);

    in[0].value = "884A4A522026CFDF4D8A30F4006EAF0B0|A0000040FCE691";
    EXPECT_EQ(0, ComputeParseCuid(in, out));
    EXPECT_EQ("884A4A522026CFDF4D8A30F4006EAF0B0", out[0].value);
    EXPECT_EQ("196ECF0400000A", out[1].value);
}

TEST_F(test_mgame_order_suite, ComputeRechargeResultCpCase) {
    std::vector<EachColumn> in;
    std::vector<EachColumn> out;
    EXPECT_EQ(-1, ComputeRechargeResultCp(in, out));
    
    in.resize(1);
    out.resize(1);
    //case 1 "0"
    in[0].value = "0";
    EXPECT_EQ(0, ComputeRechargeResultCp(in, out));
    EXPECT_EQ("UNKNOWN", out[0].value);
    //case 2 "1"
    in[0].value = "1";
    EXPECT_EQ(0, ComputeRechargeResultCp(in, out));
    EXPECT_EQ("SUCCESS", out[0].value);
    //case 3 "2"
    in[0].value = "2";
    EXPECT_EQ(0, ComputeRechargeResultCp(in, out));
    EXPECT_EQ("FAIL", out[0].value);
    //case 4 "7"
    in[0].value = "7";
    EXPECT_EQ(-1, ComputeRechargeResultCp(in, out));
}
/* vim: set ts=4 sw=4: */
