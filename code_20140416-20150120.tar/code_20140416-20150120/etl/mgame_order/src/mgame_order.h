/***************************************************************************
 * 
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file mgame_order.h
 * @author yeyue(yeyue@baidu.com)
 * @date 2014-08-18 15:17:00
 * @brief mgame order
 *  
 **/

#include "common_lib.h"
#include "etllib.h"

#ifndef  MGAME_ORDER_H
#define  MGAME_ORDER_H

namespace common_ns = baidu::dt::udw::common_lib;

extern "C" {
    int ComputeTime(const std::vector<EachColumn> &in, std::vector<EachColumn> &out);

    int ComputeParseCuid(const std::vector<EachColumn>& in, std::vector<EachColumn>& out);

    int ComputeRechargeResultCp(const std::vector<EachColumn>& in, std::vector<EachColumn>& out);
}

#endif  // MGAME_ORDER_H

/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
