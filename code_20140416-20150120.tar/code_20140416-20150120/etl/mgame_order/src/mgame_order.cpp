/***************************************************************************
 * 
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 

 
/**
 * @file src/mgame_order.cpp
 * @author yeyue(yeyue@baidu.com)
 * @date 2014-08-18 15:20:00
 * @brief 
 *  
 **/

#include "mgame_order.h"

namespace common_ns = baidu::dt::udw::common_lib;

/**
 * @brief 
 *
 * @param in
 * @param out
 *
 * @return 
 */
int ComputeTime(const std::vector<EachColumn> &in, std::vector<EachColumn> &out) {
    if (in.size() != 1 || out.size() != 8) {
        return -1;
    }

    std::string timestamp = in[0].value;
    std::string date_str;
    if (timestamp.size() < 3) {
        return -1;
    }
    timestamp = timestamp.substr(0, timestamp.size() - 3);

    std::vector<EachColumn> tmp_in;
    tmp_in.resize(1);
    tmp_in[0].value = timestamp;
    CommonParseTimestamp(tmp_in, out);
    
    return 0;
}

/**
 * @brief 
 *
 * @param in
 * @param out
 *
 * @return 
 */
int ComputeParseCuid(const std::vector<EachColumn>& in, std::vector<EachColumn>& out) {
    if (in.size() != 1 || out.size() != 2) {
        return -1;
    }

    std::string input = in[0].value;
    EachColumn &event_cuid = out[0];
    EachColumn &event_imei = out[1];

    std::size_t index = input.find('|');
    if (index != std::string::npos) {
        event_cuid.value = input.substr(0, index);
        std::string imei = input.substr(index + 1);
        std::reverse(imei.begin(), imei.end());
        event_imei.value = imei;
    }
    else {
        event_imei.value = input;
    }

    return 0;
}

int ComputeRechargeResultCp(const std::vector<EachColumn>& in, std::vector<EachColumn>& out) {
    if (in.size() != 1 || out.size() != 1) {
        return -1;
    }
    const std::string &result = in[0].value;
    EachColumn &recharge_result = out[0];
    int status;
    std::stringstream stream;
    stream << result;
    stream >> status;
    stream.clear();
    std::cerr << "recharge_result" << result << std::endl;
    switch (status) {
        case 0:
            recharge_result.value = "UNKNOWN";
            break;
        case 1:
            recharge_result.value = "SUCCESS";
            break;
        case 2:
            recharge_result.value = "FAIL";
            break;
        default:
            return -1;
    }
    return 0;
}
/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
