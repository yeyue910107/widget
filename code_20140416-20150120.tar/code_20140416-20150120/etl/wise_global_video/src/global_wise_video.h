/***************************************************************************
 *
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 **************************************************************************/

/***************************************************************************
 * Name        : global_wise_video.h
 * Author      : yeyue(@baidu.com)
 * Create Time : 2014-09-18 13:42:10
 * Description : global_wise_video.h
 **************************************************************************/
#ifndef __GLOBAL_WISE_VIDEO_H
#define __GLOBAL_WISE_VIDEO_H

#include <sys/socket.h>
#include <time.h>

#include <vector>

#include "common_lib.h"
#include "etllib.h"

extern "C" {
int ComputeGlobalWiseUrl(const std::vector<EachColumn>& in, std::vector<EachColumn>& out);
int ComputeGlobalWiseReferer(const std::vector<EachColumn>& in, std::vector<EachColumn>& out);
int ComputeIntIp(const std::vector<EachColumn>& in, std::vector<EachColumn>& out);
int ComputeGlobalWiseTimestamp(const std::vector<EachColumn>& in, std::vector<EachColumn>& out);
int ComputeGlobalWiseNetType(const std::vector<EachColumn>& in, std::vector<EachColumn>& out);
int ComputeMapJson(const std::vector<EachColumn>& in, std::vector<EachColumn>& out);
int ComputeArrayJson(const std::vector<EachColumn>& in, std::vector<EachColumn>& out);
}
int GlobalWiseIp2Str(const uint32_t ip, std::string& value); 
int CommonMapJson(const std::string& in, std::string& out);

#endif


/* vim: set ts=4 sw=4: */
