/***************************************************************************
 *
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 **************************************************************************/

/***************************************************************************
 * Name        : global_wise_video.cpp
 * Author      : yeyue(@baidu.com)
 * Create Time : 2014-09-18 14:39:31
 * Description : global_wise_video.cpp
 **************************************************************************/
#include "global_wise_video.h"
#include "boost/algorithm/string/regex.hpp"

namespace common_ns = baidu::dt::udw::common_lib;

int CommonMapJson(const std::string& in, std::string& out) {
    Json::Reader reader;
    Json::FastWriter writer;
    Json::Value map_obj;
    if (in.empty()) {
        out = "";
        return 0;
    }
    reader.parse(in, map_obj, false);
    std::map<std::string, std::string> temp_map;
    if (map_obj.isObject()) {
        Json::Value::Members members = map_obj.getMemberNames();
        for (Json::Value::Members::iterator iter = members.begin(); iter != members.end(); ++iter) {
            std::string member_name = static_cast<std::string>(*iter);
            Json::Value member_value = map_obj[member_name];
            if (!member_name.empty() && member_value.isString()) {
                std::string member_value_str = member_value.asString();
                temp_map[member_name] = member_value_str;
            }
            else if (!member_name.empty()) {
                std::string member_value_str = writer.write(member_value);
                int member_value_size = member_value_str.size();
                if (member_value_size > 0 && member_value_str[member_value_size - 1] == '\n') {
                    member_value_str = member_value_str.substr(0, member_value_size - 1);
                }
                temp_map[member_name] = member_value_str;
            }
        }
    }
    common_ns::Map2Json2(temp_map, out);
    return 0;
}

int ComputeGlobalWiseUrl(const std::vector<EachColumn>& in, std::vector<EachColumn>& out) {
    if (in.size() != 1 || out.size() != 4) {
        return -1;
    }
    if (in.at(0).value == "-" || in.at(0).value == "") {
        return 0;
    }
    
    std::string origin_url = in.at(0).value;
    std::string& event_url = out.at(0).value;
    std::string& event_url_hostname = out.at(1).value;
    std::string& event_urlpath = out.at(2).value;
    std::string& event_urlparams = out.at(3).value;
    
    common_ns::urlparser_t url_result;
    int errno = common_ns::ParseUrl(
            origin_url.c_str(),
            origin_url.length(),
            NULL,
            NULL,
            url_result);
    if (0 == errno && !origin_url.empty()) {
        event_url = url_result.url;
        event_urlpath = url_result.path;
        event_url_hostname = url_result.host;
        std::map<std::string, std::string> temp_map;
        std::map<std::string, std::string>::iterator iter = url_result.params.begin();
        // 去掉空的情况
        for (; iter != url_result.params.end(); ++iter) {
            if ("" != iter->first) {
                temp_map[iter->first] = iter->second;
            }
        }
        common_ns::Map2Json2(temp_map, event_urlparams);
    }
    return 0;
}

int ComputeGlobalWiseReferer(const std::vector<EachColumn>& in, std::vector<EachColumn>& out) {
    return ComputeGlobalWiseUrl(in, out);
}

int ComputeIntIp(const std::vector<EachColumn>& in, std::vector<EachColumn>& out) {
    if ( 1 != in.size()) {
        fprintf(stderr, "function ComputeIntIp input size %d != 1\n", in.size());
        return 1;
    }

    const std::string in_val = in[0].value;
    if (!in_val.empty()) {
        if (!common_ns::IsInt(in_val.c_str(), in_val.length(), false)) {
            fprintf(stderr, "function ComputeIntIp input value %s is not integer\n", in_val.c_str());
            return 2;            
        }
        // 转换成int
        uint64_t tmp_int;    
        tmp_int = strtoul(in_val.c_str(), NULL, 10);
        if ( tmp_int > UINT32_MAX) {
            fprintf(stderr, "function ComputeIntIp input value %s is error\n", in_val.c_str());
            return 3;            
        }
        std::vector<EachColumn> tmp_in(1);
        if (0 == GlobalWiseIp2Str(tmp_int, tmp_in[0].value)) {
            return common_convert_ip(tmp_in, out);
        }
    }
    return 0;
}

int GlobalWiseIp2Str(const uint32_t ip, std::string& value) {
    struct in_addr in;
    char tmp_chars[33] = {0};
    in.s_addr = ip;
    if (inet_ntop(AF_INET, &in, tmp_chars, 33) == NULL) {
        return -1;
    }
    std::string tmp_value;
    tmp_value.assign(tmp_chars);
    std::vector<std::string> tmp_vector;
    common_ns::Str2Vector(tmp_value, ".", tmp_vector);
    if (tmp_vector.size() != 4) {
        return -2;
    }
    value = tmp_vector[3] + "." + tmp_vector[2] + "." + tmp_vector[1] + "." + tmp_vector[0];
    return 0;
}      

int ComputeGlobalWiseTimestamp(const std::vector<EachColumn>& in, std::vector<EachColumn>& out) {
    if (in.size() != 1 || out.size() != 8) {
        return -1;
    }

    std::string timestamp = in[0].value;
    if (timestamp.size() < 3) {
        return -1;
    }
    timestamp = timestamp.substr(0, timestamp.size() - 3);
    std::vector<EachColumn> tmp_in;
    tmp_in.resize(1);

    tmp_in[0].value = timestamp;
    return CommonParseTimestamp(tmp_in, out);
}

int ComputeGlobalWiseNetType(const std::vector<EachColumn>& in, std::vector<EachColumn>& out) {
    if (in.size() != 1 || out.size() != 1) {
        return -1;
    }
    const std::string& orgin_net_type =in.at(0).value;
    std::string& event_net_type = out.at(0).value;
    if ("NET_WIFI" == orgin_net_type) {
        event_net_type = "Wifi";
    } 
    else if ("NET_2G" == orgin_net_type) {
        event_net_type = "2G";
    }
    else if ("NET_3G" == orgin_net_type) {
        event_net_type = "3G";
    }
    else if ("NET_4G" == orgin_net_type) {
        event_net_type = "4G";
    }
    else {
        event_net_type = "Unkown";
    }

    return 0;
}

int ComputeMapJson(const std::vector<EachColumn>& in, std::vector<EachColumn>& out) {
    if (in.size() != 1 || out.size() != 1) {
        return -1;
    }
    const std::string& input_json = in.at(0).value;
    std::string& output_json = out.at(0).value;
    CommonMapJson(input_json, output_json);
    return 0;
}

int ComputeArrayJson(const std::vector<EachColumn>& in, std::vector<EachColumn>& out) {
    if (in.size() != 1 || out.size() != 1) {
        return -1;
    }
    const std::string& input_json = in.at(0).value;
    std::string& output_json = out.at(0).value;
    output_json = "";
    Json::Reader reader;
    Json::FastWriter writer;
    Json::Value array_obj;
    reader.parse(input_json, array_obj, false);
    std::vector<std::string> array_json_vector;
    if (array_obj.isArray()) {
        for (int i = 0; i < array_obj.size(); ++i) {
            if (array_obj[i].isObject()) {
                std::string temp_output = "";
                std::string temp_input = writer.write(array_obj[i]);
                CommonMapJson(temp_input, temp_output);
                array_json_vector.push_back(temp_output);
            }
        }
    }
    int vector_size = array_json_vector.size();
    output_json = "[";
    for (int i = 0; i < vector_size; ++i) {
        if (i < vector_size - 1) {
            output_json += (array_json_vector[i] + ",");
            continue;
        }
        output_json += array_json_vector[i];
    }
    output_json += "]";
    // edited by wenjurong
    // 下游反馈\00001 特殊字符，影响qe展示结果，因此将\0001字符替换掉
    string replace_str = " ";
    boost::regex reg("\\\\u0001|\\\\u0002|\\\\u0003|\\\\u0004|\\\\u0005");          // need to be replace 
    //    std::cerr << "old output_json: " << output_json << std::endl;
    boost::replace_all_regex(output_json, reg, replace_str, boost::format_default);
    return 0;
}
/* vim: set ts=4 sw=4: */
