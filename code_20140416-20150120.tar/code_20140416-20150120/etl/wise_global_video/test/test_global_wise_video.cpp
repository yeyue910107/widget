/***************************************************************************
 *
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 **************************************************************************/

/***************************************************************************
 * Name        : test_global_wise_video.cpp
 * Author      : yeyue
 * Create Time : 2014-09-18 15:10:29
 * Description : test_global_wise_video.cpp
 **************************************************************************/
#include "gtest/gtest.h"

#include "global_wise_video.h"

namespace common_ns = baidu::dt::udw::common_lib;

void PrintOut(const std::vector<EachColumn>& out) {
    for (int i = 0; i < out.size(); ++i) {
        std::cout << out.at(i).value << std::endl;
    }
}

class GlobalWiseTest : public testing::Test {
    public:
        static void SetUpTestCase(){}
        static void TearDownTestCase(){}
        virtual void SetUp(){}
        virtual void TearDown(){}   
};

int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    testing::FLAGS_gtest_death_test_style = "threadsafe";
    return RUN_ALL_TESTS();
};

TEST_F(GlobalWiseTest, ComputeGlobalWiseUrl) {
    std::vector<EachColumn> in;
    std::vector<EachColumn> out;
    int ret = ComputeGlobalWiseUrl(in, out);
    EXPECT_NE(0, ret);   
    in.resize(1);   
    out.resize(4);  
    in.at(0).value = "/file/c1c74136a2fdeb4aa33ce309e6b9be80?xcode=c5a25338ce36b81699f7a7bf9b9d293f584b0a8a34a500ef&wd=%25u6D4B%25u8BD5%250A&fid=187334886-250528-4077772540&time=1388151174&sign=FDTAXER-DCb740ccc5511e5e8fedcff06b081203-r2vAR37G7o3dqOdvKDwP4I%2FvqVY%3D&to=cb&fm=N,B,U,ny&expires=1388152526&rt=sh&r=487204592&logid=3803752454&sh=1&vuk=50618335&fn=RESCUE-ENG.pdf&wsiphost=ipdbm";
    ret = ComputeGlobalWiseUrl(in, out);
    //in.at(0).value = "http://nsclick.baidu.com/v.gif?pid=112&wd=%25C4%25C9%25C3%25D7&url=http%3A//baidu.com&type=01000011&t=1373558393037&docId=f964936f1eb91a37f1115c2c&docType=doc&ext=doc&page=4&fr=in&version=6&cid1=3&cid2=230&cid3=89&cid4=0&ply=html&nsact=view.browse&path=cde&pj=baiduhp#abc";
    //in.at(0).value = "vui_servers/r/video_tc?pt=1&tn=GSE_4vbn0_n74ft5wt&lc=th-TH&an=as&san=&wd=%E0%B8%AB%E0%B8%B5%E0%B8%84%E0%B8%99%E0%B9%81%E0%B8%81%E0%B9%88&pos=0&pn=0&title=&srcid=0&xp=&rsv_videoplay=1-f-2-f-3-t-4-t-5-f-6-t-7-f-8-f-9-f-10-f";
    in.at(0).value = "http://image.baidu.com.br/s?la=34&lo=32&sa=3&tn=GSE_3w706_pj8thnaa&ts=0&pos=0&bt=0&fm=iphone&ie=utf-8&word=mulhers+pelada&rq=mulhers+pelada";
    ret = ComputeGlobalWiseUrl(in, out);
    EXPECT_EQ(0, ret);   
    common_ns::CodeConv code_conv;
    std::string temp,new_temp;
    code_conv.URLNormalize(out.at(3).value, temp);
    std::cout << out.at(0).value << std::endl;
    std::cout << out.at(3).value << std::endl;
    std::cout << temp << std::endl;
    code_conv.URLNormalize(temp, new_temp);
    std::cout << new_temp << std::endl;
}

TEST_F(GlobalWiseTest, ComputeGlobalWiseReferer) {
    std::vector<EachColumn> in;
    std::vector<EachColumn> out;
    int ret = ComputeGlobalWiseReferer(in, out);
    EXPECT_NE(0, ret);   
}

TEST_F(GlobalWiseTest, ComputeIntIp) {
    std::vector<EachColumn> in;
    std::vector<EachColumn> out;
    int ret = ComputeIntIp(in, out);
    EXPECT_NE(0, ret);
    in.resize(1);
    out.resize(6);
    //in.at(0).value = "1971856426";
    in.at(0).value = "-1312270906";
    ret = ComputeIntIp(in, out);
    EXPECT_EQ(0, ret);
    std::cout << out.at(0).value << std::endl;
}

TEST_F(GlobalWiseTest, ComputeGlobalWiseTimestamp) {
    std::vector<EachColumn> in;
    std::vector<EachColumn> out;
    int ret = ComputeGlobalWiseTimestamp(in, out);
    EXPECT_EQ(-1, ret);  
    in.resize(1);
    out.resize(8);  
    in.at(0).value = "1339344000000";
    ret = ComputeGlobalWiseTimestamp(in, out);
    EXPECT_EQ(0, ret);   
    EXPECT_EQ("2012-06-11 00:00:00",out[0].value);
    EXPECT_EQ("20120611",out[1].value);
    EXPECT_EQ("00",out[2].value);
    EXPECT_EQ("2012",out[3].value);
    EXPECT_EQ("06",out[4].value);
    EXPECT_EQ("24",out[5].value);
    EXPECT_EQ("11",out[6].value);
    EXPECT_EQ("1339344000",out[7].value);
    in.at(0).value = "abc";
    ret = ComputeGlobalWiseTimestamp(in, out);
    EXPECT_EQ(-2, ret);
}

TEST_F(GlobalWiseTest, ComputeGlobalWiseNetType) {
    std::vector<EachColumn> in;
    std::vector<EachColumn> out;
    int ret = ComputeGlobalWiseNetType(in, out);
    EXPECT_EQ(-1, ret);  
    in.resize(1);
    out.resize(1);  
    in.at(0).value = "NET_WIFI";
    ret = ComputeGlobalWiseNetType(in, out);
    EXPECT_EQ(0, ret);
    EXPECT_EQ("Wifi", out.at(0).value);
    in.at(0).value = "NET_3G";
    ret = ComputeGlobalWiseNetType(in, out);
    EXPECT_EQ(0, ret);
    EXPECT_EQ("3G", out.at(0).value);
    in.at(0).value = "NET_4G";
    ret = ComputeGlobalWiseNetType(in, out);
    EXPECT_EQ(0, ret);
    EXPECT_EQ("4G", out.at(0).value);
    in.at(0).value = "NET_2G";
    ret = ComputeGlobalWiseNetType(in, out);
    EXPECT_EQ(0, ret);
    EXPECT_EQ("2G", out.at(0).value);
    in.at(0).value = "aa";
    ret = ComputeGlobalWiseNetType(in, out);
    EXPECT_EQ(0, ret);
    EXPECT_EQ("Unkown", out.at(0).value);
}

TEST_F(GlobalWiseTest, ComputeMapJson) {
    std::vector<EachColumn> in;
    std::vector<EachColumn> out;
    int ret = ComputeMapJson(in, out);
    EXPECT_EQ(-1, ret);
    in.resize(1);
    out.resize(1);
    in.at(0).value = "{\"box_type\":0,\"guide_search_position\":0,\"page_num\":0,\"query\":\"xxx\",\"result_count\":10,\"search_type\":12, \"inner\":[{\"box_type\":0,\"guide_search_position\":0,\"page_num\":0,\"query\":\"xxx\",\"result_count\":10,\"search_type\":12}]}";
    ret = ComputeMapJson(in, out);
    EXPECT_EQ(0, ret);
    PrintOut(out);
}

TEST_F(GlobalWiseTest, ComputeArrayJson) {
    std::vector<EachColumn> in;
    std::vector<EachColumn> out;
    int ret = ComputeArrayJson(in, out);
    EXPECT_EQ(-1, ret);
    in.resize(1);
    out.resize(1);
    in.at(0).value = "[{\"crawl_time\":\"1364140800\",\"index\":1,\"template_name\":\"www_normal\"},{\"crawl_time\":\"1364140800\",\"index\":1,\"template_name\":\"www_normal\"}]";
    ret = ComputeArrayJson(in, out);
    EXPECT_EQ(0, ret);
    PrintOut(out);
}
/* vim: set ts=4 sw=4: */
