mkdir -p output/tar
mkdir -p output/tar
mkdir -p dag_global_wise_video_display/so dag_global_wise_video_display/flow dag_global_wise_video_display/DQConf dag_global_wise_video_display/file 
cp resource/dag_global_wise_video_display.xml dag_global_wise_video_display/dag.xml
cp *.so dag_global_wise_video_display/so
cp resource/fm_global_wise_video.xml dag_global_wise_video_display/flow
tar -cvf output/tar/dag_global_wise_video_display.tar dag_global_wise_video_display
rm -rf dag_global_wise_video_display

mkdir -p dag_global_wise_video_click/so dag_global_wise_video_click/flow dag_global_wise_video_click/DQConf dag_global_wise_video_click/file 
cp resource/dag_global_wise_video_click.xml dag_global_wise_video_click/dag.xml
cp *.so dag_global_wise_video_click/so
cp resource/fm_global_wise_video.xml dag_global_wise_video_click/flow
tar -cvf output/tar/dag_global_wise_video_click.tar dag_global_wise_video_click
rm -rf dag_global_wise_video_click
