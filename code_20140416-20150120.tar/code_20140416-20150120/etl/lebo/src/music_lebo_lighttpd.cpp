/***************************************************************************
 *
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 **************************************************************************/

/***************************************************************************
 * Name        : music_lebo_lighttpd.cpp
 * Author      : yeyue(@baidu.com)
 * Create Time : 2014-03-06 16:40:33
 * Description : music_lebo_lighttpd.cpp
 **************************************************************************/
#include "music_lebo_lighttpd.h"

namespace common_ns = baidu::dt::udw::common_lib;

namespace udw {
namespace music {

int ComputeConvertTime(const std::vector<EachColumn> &in, std::vector<EachColumn> &out) {
    if (in.size() != 1 || out.size() != 8) {
        return -1;
    }

    std::string timestamp = in[0].value;
    std::string date_str;
    if (timestamp.size() < 3) {
        return -1;
    }
    timestamp = timestamp.substr(0, timestamp.size() - 3);
    /*int ret = common_ns::Timestamp2Date(timestamp, date_str);
    if (ret != 0) {
        return -1;
    }
    */
    std::vector<EachColumn> tmp_in;
    tmp_in.resize(1);
    //tmp_in[0].value = date_str;
    //common_parse_time_all(tmp_in, out);

    tmp_in[0].value = timestamp;
    CommonParseTimestamp(tmp_in, out);
    return 0;
}

int ComputeConvertIp(const std::vector<EachColumn> &in, std::vector<EachColumn> &out) {
    if (in.size() != 1 || out.size() != 6) {
        return -1;
    }

    uint32_t ip_int = 0;
    //std::stringstream stream;
    //stream << in[0].value;
    //stream >> ip_int;
    if (in[0].value.size() > 0) {
        if (in[0].value[0] != '-') {
            ip_int = common_ns::Str2Uint64(in[0].value.c_str());
        }
        else {
            ip_int = -common_ns::Str2Uint64(in[0].value.c_str() + 1);
        }
    }

    if (ip_int == 0) {
        return -1;
    }

    std::string ip_string;
    if (IpInt2Str(ip_int, ip_string) != 0) {
        std::cerr << "convert ip from int to string error." << std::endl;
        return -1;
    }
    std::vector<EachColumn> new_in;
    new_in.resize(1);
    new_in[0].value = ip_string;

    return common_convert_ip(new_in, out);
}

int ComputeLeboParseUrlLighttpd(const std::vector<EachColumn> &in, std::vector<EachColumn> &out) {
    if (in.size() != 1 || out.size() != 4) {
        return -1;
    }

    const std::string &in_url = in[0].value;

    std::string &event_url = out[0].value;
    std::string &host = out[1].value;
    std::string &url_path = out[2].value;
    std::string &url_params = out[3].value;

    common_ns::urlparser_t result;
    std::string in_host = "lebo.baidu.com";
    
    //static baidu::dt::udw::common_lib::CodeConv s_code_conv;

    if (common_ns::CommonParseUrlBase(
                in_url,
                in_host,
                false,
                result,
                &url_params) == 0 ) {
        event_url = result.url;
        host = result.host;
        url_path = result.path;
    } else {
        return -1;
    }
    //std::string event_url_encode = event_url;
    //s_code_conv.URLNormalize(event_url_encode.c_str(), event_url_encode.length(), event_url);
    //std::string url_params_encode = url_params;
    //s_code_conv.URLNormalize(url_params_encode.c_str(), url_params_encode.length(), url_params);
    
    return 0;
}

int ComputeLeboParseReferer(const std::vector<EachColumn> &in, std::vector<EachColumn> &out) {
    if (in.size() != 1 || out.size() != 4) {
        return -1;
    }

    const std::string &in_referer_encode = in[0].value;

    std::string &referer = out[0].value;
    std::string &params = out[1].value;
    std::string &path = out[2].value;
    std::string &host = out[3].value;

    common_ns::urlparser_t result;
    
    static baidu::dt::udw::common_lib::CodeConv s_code_conv;
    std::string in_referer;
    s_code_conv.URLNormalize(in_referer_encode.c_str(), in_referer_encode.length(), in_referer);
    if (common_ns::CommonParseUrlBase(
                in_referer,
                host,
                false,
                result,
                &params) == 0 ) {
        referer = result.url;
        host = result.host;
        path = result.path;
    } else {
        return -1;
    }
    
    return 0;
}

int IpInt2Str(const uint32_t ip, std::string& ip_str) {
    vector<std::string> ip_vector;
    ip_vector.resize(4);
    uint32_t tmp = 0;
    for (int i = 0; i < 4; i++) {
        tmp = ((ip & (0xFFFFFFFF >> (8 * i))) >> (24 - 8 * i));
        std::stringstream stream;
        stream << tmp;
        stream >> ip_vector[i];
    }
    
    ip_str = "";
    for (int i = 0; i < 4; i++) {
        ip_str += ip_vector[i];
        if (i < 3) {
            ip_str += ".";
        }
    }

    return 0;
}

}
}

/* vim: set ts=4 sw=4: */
