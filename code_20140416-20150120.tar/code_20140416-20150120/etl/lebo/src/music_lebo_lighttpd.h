/***************************************************************************
 *
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 **************************************************************************/

/***************************************************************************
 * Name        : music_lebo_lighttpd.h
 * Author      : yeyue
 * Create Time : 2014-07-10 16:44:03
 * Description : music_lebo_lighttpd.h
 **************************************************************************/
#ifndef __MUSIC_LEBO_LIGHTTPD_H
#define __MUSIC_LEBO_LIGHTTPD_H

#include "common_lib.h"
#include "etllib.h"

namespace udw {
namespace music {

extern "C" {

int ComputeConvertTime(const std::vector<EachColumn> &in, std::vector<EachColumn> &out);

int ComputeConvertIp(const std::vector<EachColumn> &in, std::vector<EachColumn> &out);

int ComputeLeboParseUrlLighttpd(const std::vector<EachColumn> &in, std::vector<EachColumn> &out);

int ComputeLeboParseReferer(const std::vector<EachColumn> &in, std::vector<EachColumn> &out);

int IpInt2Str(const uint32_t ip, std::string& ip_str); 

}

}
}

#endif



/* vim: set ts=4 sw=4: */
