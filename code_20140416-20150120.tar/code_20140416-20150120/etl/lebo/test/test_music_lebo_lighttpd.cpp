    /***************************************************************************
     *
     * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
     *
     **************************************************************************/

    /***************************************************************************
     * Name        : test_music_lebo_lighttpd.cpp
     * Author      : yeyue
     * Create Time : 2014-07-10 16:46:02
     * Description : test_music_lebo_lighttpd.cpp
     **************************************************************************/

#include "gtest/gtest.h"
#include "music_lebo_lighttpd.h"

class MusicLeboLighttpdTest : public testing::Test {
    public:
        static void SetUpTestCase(){}
        static void TearDownTestCase(){}
        virtual void SetUp(){}
        virtual void TearDown(){}   
};

int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    testing::FLAGS_gtest_death_test_style = "threadsafe";
    return RUN_ALL_TESTS();
};

TEST_F(MusicLeboLighttpdTest, ComputeConvertTimeCase) {
    vector<EachColumn> in;
    vector<EachColumn> out;
    int ret = udw::music::ComputeConvertTime(in, out);
    EXPECT_NE(0, ret);
    in.resize(1);
    out.resize(8);
    in[0].value = "1405483200000";
    ret = udw::music::ComputeConvertTime(in, out);
    EXPECT_EQ(0, ret);
    for (int i = 0; i < out.size(); i++) {
        std::cout << out[i].value << std::endl;
    }
}

TEST_F(MusicLeboLighttpdTest, ComputeConvertIpCase) {
    vector<EachColumn> in;
    vector<EachColumn> out;
    int ret = udw::music::ComputeConvertIp(in, out);
    EXPECT_NE(0, ret);

    in.resize(1);
    out.resize(6);
    in[0].value = "16777343";
    ret = udw::music::ComputeConvertIp(in, out);
    EXPECT_EQ(0, ret);
    for (int i = 0; i < out.size(); i++) {
        std::cout << out[i].value << std::endl;
    }
}

TEST_F(MusicLeboLighttpdTest, ComputeConvertIpCase1) {
    vector<EachColumn> in;
    vector<EachColumn> out;
    int ret = udw::music::ComputeConvertIp(in, out);
    EXPECT_NE(0, ret);

    in.resize(1);
    out.resize(6);
    in[0].value = "-592107927";
    ret = udw::music::ComputeConvertIp(in, out);
    EXPECT_EQ(0, ret);
    for (int i = 0; i < out.size(); i++) {
        std::cout << out[i].value << std::endl;
    }
}

TEST_F(MusicLeboLighttpdTest, ComputeLeboParseUrlLighttpdCase) {
    vector<EachColumn> in;
    vector<EachColumn> out;
    int ret = udw::music::ComputeLeboParseUrlLighttpd(in, out);
    EXPECT_NE(0, ret);
    in.resize(1);
    out.resize(4);
    //in[0].value = "cms/mobile.gif?pid=323&os=android&ref=webapp&type=&v=1.0.0&r=1388246398427&page=search&page_url=http%3A%2F%2Fmusic.baidu.com%2F%23search%2F%25E7%258E%258B%25E8%258B%25A5%25E7%2590%25B3%2F&page_refer=http%3A%2F%2Fm.baidu.com%2Fpu%3Dsz%25401320_1001%2Fs%3Fword%3D%25E5%25A4%25A9%25E9%25BB%2591%25E9%25BB%2591%25E6%25AD%258C%25E8%25AF%258D%26st%3D11104i%26ts%3D5682920%26sa%3Dis_1%26ss%3D11%26rq%3D%25E5%25A4%25A9%25E9%25BB%2591%25E9%25BB%2591&channel=undefined";
    in[0].value = "/static/mobile.gif?pid=323&ref=leeboo&type=&os=android&page=home&page_url=http%3A%2F%2Flebo.baidu.com%2F%23tag%2F%25E7%259B%25B8%25E5%25A3%25B0%25E6%259B%25B2%25E8%2589%25BA%3Ffr%3Dmusic_webapp_home_tag&page_refer=http%3A%2F%2Fmusic.baidu.com%2F%3Fitj%3D420%26fr%3Dmusic_wise1%26ssid%3D0%26from%3D381a_cp_mz%26uid%3D%26pu%3Dsz%25401320_1001%252Cta%2540iphone_2_2.3_3_533%26bd_page_type%3D1";
    //in[0].value = "/static/mobile.gif?pid=323&ref=leeboo&type=&os=android&page=home&page_url=http%3A%2F%2Flebo.baidu.com%2F%23tag%2F%25E7%259B%25B8%25E5%25A3%25B0%25E6%259B%25B2%25E8%2589%25BA%3Ffr%3Dmusic_webapp_home_tag";
    ret = udw::music::ComputeLeboParseUrlLighttpd(in, out);
    EXPECT_EQ(0, ret);
    for (int i = 0; i < out.size(); i++) {
        std::cout << out[i].value << std::endl;
    }
}

TEST_F(MusicLeboLighttpdTest, ComputeLeboParseUrlLighttpdCase1) {
    vector<EachColumn> in;
    vector<EachColumn> out;
    int ret = udw::music::ComputeLeboParseUrlLighttpd(in, out);
    EXPECT_NE(0, ret);
    in.resize(1);
    out.resize(4);
    in[0].value = "/tag/%E6%B5%AA%E6%BC%AB%E8%A8%80%E6%83%85";
    ret = udw::music::ComputeLeboParseUrlLighttpd(in, out);
    EXPECT_EQ(0, ret);
    for (int i = 0; i < out.size(); i++) {
        std::cout << out[i].value << std::endl;
    }
}

TEST_F(MusicLeboLighttpdTest, ComputeLeboParseRefererCase) {
    vector<EachColumn> in;
    vector<EachColumn> out;
    int ret = udw::music::ComputeLeboParseReferer(in, out);
    EXPECT_NE(0, ret);
    in.resize(1);
    out.resize(4);
    in[0].value = "http://lebo.baidu.com/tag/%E8%84%B1%E5%8F%A3%E7%A7%80";
    ret = udw::music::ComputeLeboParseReferer(in, out);
    EXPECT_EQ(0, ret);
    for (int i = 0; i < out.size(); i++) {
        std::cout << out[i].value << std::endl;
    }
}

TEST_F(MusicLeboLighttpdTest, ComputeLeboParseRefererCase1) {
    vector<EachColumn> in;
    vector<EachColumn> out;
    int ret = udw::music::ComputeLeboParseReferer(in, out);
    EXPECT_NE(0, ret);
    in.resize(1);
    out.resize(4);
    in[0].value = "http://music.baidu.com/?itj=420&fr=music_wise1&ssid=0&from=1269a&uid=&pu=sz%401320_1001%2Cta%40iphone_2_4.3_3_534&bd_page_type=1";
    ret = udw::music::ComputeLeboParseReferer(in, out);
    EXPECT_EQ(0, ret);
    for (int i = 0; i < out.size(); i++) {
        std::cout << out[i].value << std::endl;
    }
}
/* vim: set ts=4 sw=4: */
