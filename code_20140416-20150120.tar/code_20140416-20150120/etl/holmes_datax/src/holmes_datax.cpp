/***************************************************************************
 * 
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 

 
/**
 * @file src/holmes_datax.cpp
 * @author yeyue(yeyue@baidu.com)
 * @date 2014-01-07 11:52:15
 * @brief 
 *  
 **/

#include "holmes_datax.h"
#include <boost/algorithm/string.hpp>
#include "common_lib.h"

namespace common_ns = baidu::dt::udw::common_lib;

namespace bdg {
namespace udw {
namespace holmes {

// in or out params size
const int ALL_IN_SIZE = 6;
const int IP_OUT_SIZE = 6;
const int TIME_OUT_SIZE = 8;
const int URL_OUT_SIZE = 3;
const int REFERER_OUT_SIZE = 1;
const int UA_OUT_SIZE = 8;
const int COOKIE_OUT_SIZE = 2;
const int ALL_OUT_SIZE = 28;

/**
 * @brief parse raw log
 * @param in: raw_log
 * @param out
 * 0:ip;1:date_time;2:url;3:ua;4:cookie
 * @return 
 */
int log_format(const std::string& raw_log, 
        std::vector<std::string>* out) {
    if (out == NULL) {
        return -1;
    }

    std::vector<std::string> fields;
    boost::algorithm::split(fields, 
            raw_log, 
            boost::algorithm::is_any_of("\""));
    if (fields.size() != 9) {
        std::cerr << "fields size: " << fields.size() << std::endl;
        return -1;
    }

    std::vector<std::string> ip_time_fields;
    boost::algorithm::split(ip_time_fields, 
            fields[0], 
            boost::algorithm::is_any_of("[]"));
    if (ip_time_fields.size() != 3) {
        return -1;
    }

    out->clear();
    out->resize(ALL_IN_SIZE);
    (*out)[0] = ip_time_fields[0];
    boost::trim((*out)[0]);
    (*out)[1] = ip_time_fields[1];
    (*out)[2] = fields[1];
    (*out)[3] = fields[3];
    (*out)[4] = fields[5];
    (*out)[5] = fields[7];
    
    return 0;
}

/**
 * @brief parse url params to get account and domain
 * @param in:url
 * @param out
 * 0:domain(event_product);1:account;2:url
 * @return 
 */
int compute_datax_url_params(const std::vector<EachColumn>& in, 
        std::vector<EachColumn>& out) {
    if (in.size() != 1) {
        return -1;
    }
    std::string in_url(in[0].value);

    if (in_url.find("/x.gif") == std::string::npos) {
        std::cerr << "invalid url: " << in_url << std::endl;
        return -1;
    }

    out.resize(URL_OUT_SIZE);

    common_ns::urlparser_t result;
    static common_ns::CodeConv code_conv;
    std::string in_host = "";
    std::string param_str;

    if (common_ns::CommonParseUrlBase(
            in_url, in_host, false, result, &param_str) == 0) {
        if (result.params.count("dm") == 1) {
            std::string dm = result.params["dm"];
            std::vector<std::string> dm_fields;
            // dm format: dm=loginwifi.com
            boost::algorithm::split(dm_fields, 
                    dm, 
                    boost::algorithm::is_any_of("."));
            if (dm_fields.size() <= 2) {
                out[0].value = dm_fields[0];
            }
        }
        if (result.params.count("ac") == 1) {
            if (code_conv.URLNormalize(result.params["ac"], out[1].value) != 0) {
                std::cerr << "url normalize error." << std::endl;
                return -1;
            }
        }
    } else {
        std::cerr << "parse url error." << std::endl;
        return -1;
    }
    
    out[2].value = in_url;

    return 0;
}

/**
 * @brief parse cookie to get baiduid
 * @param in:cookie
 * @param out
 * 0:baiduid;1:cookie
 * @return 
 */
int compute_datax_cookie_baiduid(const std::vector<EachColumn>& in,
        std::vector<EachColumn>& out) {
    if (in.size() != 1) {
        return -1;
    }
    out.resize(COOKIE_OUT_SIZE);
    std::string cookie(in[0].value);

    size_t found = cookie.find("BAIDUID=");
    if (found != std::string::npos) {
        out[0].value = cookie.substr(found + 8, 32);
    }
    out[1].value = cookie;

    return 0;
}

/**
 * @brief compute datax info
 * @param in: raw_log
 * @param out: ip,time,url,referer,ua,cookie
 * @return 
 */
int compute_datax_info(const std::vector<EachColumn>& in, 
        std::vector<EachColumn>& out) {
    if (in.size() != 1 || out.size() != (size_t)ALL_OUT_SIZE) {
        std::cerr << "size error" << std::endl;
        return -1;
    }

    std::vector<std::string> format_in;
    if (log_format(in[0].value, &format_in) != 0) {
        std::cerr << "log format error" << std::endl;
        return -1;
    }

    std::vector<std::vector<EachColumn> > new_in(ALL_IN_SIZE);
    std::vector<std::vector<EachColumn> > new_out(ALL_IN_SIZE);

    for (size_t i = 0; i < new_in.size(); i++) {
        new_in[i].resize(1);
        new_in[i][0].value = format_in[i];
    }
    
    // ip out, size:6
    new_out[0].resize(IP_OUT_SIZE);
    if (common_convert_ip(new_in[0], new_out[0]) != 0) {
        std::cerr << "common_convert_ip error." << std::endl;
        return -1;
    }
    // time out, size:8
    new_out[1].resize(TIME_OUT_SIZE);
    if (common_parse_time_all(new_in[1], new_out[1]) != 0) {
        std::cerr << "common_parse_time_all error." << std::endl;
        return -1;
    }
    // url out, size:3
    if (compute_datax_url_params(new_in[2], new_out[2]) != 0) {
        std::cerr << "compute_datax_url_params error." << std::endl;
        return -1;
    }
    // referer out, size:3
    new_out[3].resize(REFERER_OUT_SIZE);
    common_copy(new_in[3], new_out[3]);
    // ua out, size:8
    new_out[4].resize(UA_OUT_SIZE);
    if (common_convert_useragent(new_in[4], new_out[4]) != 0) {
        std::cerr << "common_convert_useragent error." << std::endl;
        return -1;
    }
    // cookie out, size:2
    if (compute_datax_cookie_baiduid(new_in[5], new_out[5]) != 0) {
        std::cerr << "compute_datax_cookie_baiduid error." << std::endl;
        return -1;
    }
    
    int k = 0;
    for (size_t i = 0; i < new_out.size(); i++) {
        for (size_t j = 0; j < new_out[i].size(); j++) {
            out[k++].value = new_out[i][j].value;
        }
    }

    return 0;
}

} // holmes
} // udw
} // bdg

/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
