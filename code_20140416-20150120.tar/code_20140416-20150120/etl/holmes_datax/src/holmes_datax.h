/***************************************************************************
 * 
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file holmes_datax.h
 * @author yeyue(yeyue@baidu.com)
 * @date 2014-01-06 11:52:43
 * @brief holmes_datax
 *  
 **/

#include "common_lib.h"
#include "etllib.h"

#ifndef  INF_BUDW_ETL_HOLMES_HOLMES_DATAX_H
#define  INF_BUDW_ETL_HOLMES_HOLMES_DATAX_H

namespace bdg {
namespace udw {
namespace holmes {

extern "C" {

    int log_format(const std::string& raw_log, 
            std::vector<std::string>* out);

    int compute_datax_url_params(const std::vector<EachColumn>& in, 
            std::vector<EachColumn>& out);
        
    int compute_datax_cookie_baiduid(const std::vector<EachColumn>& in, 
            std::vector<EachColumn>& out);
 
    int compute_datax_info(const std::vector<EachColumn>& in, 
            std::vector<EachColumn>& out);

}

}
}
}
#endif  // HOLMES_DATAX_H

/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
