/***************************************************************************
 * 
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
     
      
 /**
  * @file test/test_holmes_datax.cc
  * @author yeyue(yeyue@baidu.com)
  * @date 2014-01-07 11:54:57
  * @brief 
  *  
  **/

#include "holmes_datax.h"
#include <iostream>
#include <fstream>
#include "gtest/gtest.h"

int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
};

namespace bdg{
namespace udw{
namespace holmes{

class TestHolmesDataxSuite : public::testing::Test {
    protected:
        TestHolmesDataxSuite() {};
        virtual ~TestHolmesDataxSuite() {};
        virtual void SetUp() {};
        virtual void TearDown() {};
};

TEST_F(TestHolmesDataxSuite, LogFormatCase) {
    std::vector<std::string> out;
    EXPECT_EQ(-1, log_format("", &out));

    std::string in("123.181.239.152 [03/Jan/2015:19:59:59 +0800] \"GET /x.gif?"
        "si=c202865d524849216eea846069349eb9&dm=zongheng.com&ac=13411190&v=hm-"
        "1.0.173&li=283061851&rnd=1205359982 HTTP/1.1\" 200 \"http://book.zong"
        "heng.com/book/408586.html\" \"Mozilla/5.0 (Windows NT 6.1; WOW64) App"
        "leWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.63 Safari/537.36"
        "\" \"BAIDUID=AFBF1489CA36B853CE6AF545F60435A6:FG=1; BAIDUPSID=AFBF148"
        "9CA36B853CE6AF545F60435A6; BDUSS=WV-TGJKVzFPVWR1ekN5cWpRMn5DZTZ-eX5Pa"
        "m5Ibm5CNlZrVnd3N2RnN0Vwc0JVQVFBQUFBJCQAAAAAAAAAAAEAAAB97eE6X9e30uTO9M"
        "Tq2LwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        "AAAAAAMQZmVTEGZlUQ; Hm_lvt_f4165db5a1ac36eadcfa02a10a6bd243=141874596"
        "5,1418911783,1418912200,1420193200; __zpspc=188.1.1420194470.14201944"
        "70.1%232%7Cwww.so.com%7C%7C%7C%25E9%2593%25AD%25E7%2589%258C%25E6%259"
        "6%2587%25E5%25AD%2597%7C%23\"");
    EXPECT_EQ(0, log_format(in, &out));
    EXPECT_EQ(6, out.size());
    for (size_t i = 0; i < out.size(); i++) {
        std::cout << out[i] << std::endl;
    }
}

TEST_F(TestHolmesDataxSuite, ComputeDataxUrlParams) {
    std::vector<EachColumn> in;
    std::vector<EachColumn> out;
    EXPECT_EQ(-1, compute_datax_url_params(in, out));
    
    in.resize(1);
    out.resize(3);
    in[0].value = "/x.action?si=40b2221d03ba33984479d5a1a425c3f4&dm=demo.com&"
        "ac=third-party-account&rnd=1405308392489";
    EXPECT_EQ(-1, compute_datax_url_params(in, out));
    
    out.clear();
    in[0].value = "/x.gif?si=40b2221d03ba33984479d5a1a425c3f4&dm=demo.com&ac="
        "third-party-account&rnd=1405308392489";
    EXPECT_EQ(0, compute_datax_url_params(in, out));
    EXPECT_EQ("demo", out[0].value);
    EXPECT_EQ("third-party-account", out[1].value);

    out.clear();
    in[0].value = "/x.gif?si=40b2221d03ba33984479d5a1a425c3f4&dm=www.iqiyi.com"
        "&ac=third-party-account&rnd=1405308392489";
    EXPECT_EQ(0, compute_datax_url_params(in, out));
    EXPECT_EQ("", out[0].value);
    EXPECT_EQ("third-party-account", out[1].value);

    out.clear();
    in[0].value = "/x.gif?si=40b2221d03ba33984479d5a1a425c3f4&ac=third-party-"
        "account&rnd=1405308392489";
    EXPECT_EQ(0, compute_datax_url_params(in, out));
    EXPECT_EQ("", out[0].value);
    EXPECT_EQ("third-party-account", out[1].value);

    out.clear();
    in[0].value = "/x.gif?dm=eduglobal.com&"
        "ac=MTE2LjEuNzcuODl8MTQwNzM2OTkzNjE1NQ%3D%3D&v=1.0.0&rnd=1407369937887";
    EXPECT_EQ(0, compute_datax_url_params(in, out));
    EXPECT_EQ("eduglobal", out[0].value);
    EXPECT_EQ("MTE2LjEuNzcuODl8MTQwNzM2OTkzNjE1NQ==", out[1].value);
}

TEST_F(TestHolmesDataxSuite, ComputeDataxCookieBaiduid) {
    std::vector<EachColumn> in;
    std::vector<EachColumn> out;
    
    in.resize(1);
    out.resize(2);

    in[0].value = "BAIDUPSID=D9153F1C0C97143B2AAC8E6DA9D944A; "
        "BAIDUID=ABE00EDF3C34AB3D7930E36EB8DBC354:FG=1";
    EXPECT_EQ(0, compute_datax_cookie_baiduid(in, out));
    EXPECT_EQ("ABE00EDF3C34AB3D7930E36EB8DBC354", out[0].value);
    EXPECT_EQ("BAIDUPSID=D9153F1C0C97143B2AAC8E6DA9D944A; "
        "BAIDUID=ABE00EDF3C34AB3D7930E36EB8DBC354:FG=1", out[1].value);

    out.clear();
    in[0].value = "BAIDUPSID=D9153F1C0C97143B2AAC8E6DA9D944A;";
    EXPECT_EQ(0, compute_datax_cookie_baiduid(in, out));
    EXPECT_EQ("", out[0].value);
    EXPECT_EQ("BAIDUPSID=D9153F1C0C97143B2AAC8E6DA9D944A;", out[1].value);
}

TEST_F(TestHolmesDataxSuite, ComputeDataxInfoCase) {
    std::string in_str("123.181.239.152 [03/Jan/2015:19:59:59 +0800] \"GET /x.gif?"
        "si=c202865d524849216eea846069349eb9&dm=zongheng.com&ac=13411190&v=hm-"
        "1.0.173&li=283061851&rnd=1205359982 HTTP/1.1\" 200 \"http://book.zong"
        "heng.com/book/408586.html\" \"Mozilla/5.0 (Windows NT 6.1; WOW64) App"
        "leWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.63 Safari/537.36"
        "\" \"BAIDUID=AFBF1489CA36B853CE6AF545F60435A6:FG=1; BAIDUPSID=AFBF148"
        "9CA36B853CE6AF545F60435A6; BDUSS=WV-TGJKVzFPVWR1ekN5cWpRMn5DZTZ-eX5Pa"
        "m5Ibm5CNlZrVnd3N2RnN0Vwc0JVQVFBQUFBJCQAAAAAAAAAAAEAAAB97eE6X9e30uTO9M"
        "Tq2LwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        "AAAAAAMQZmVTEGZlUQ; Hm_lvt_f4165db5a1ac36eadcfa02a10a6bd243=141874596"
        "5,1418911783,1418912200,1420193200; __zpspc=188.1.1420194470.14201944"
        "70.1%232%7Cwww.so.com%7C%7C%7C%25E9%2593%25AD%25E7%2589%258C%25E6%259"
        "6%2587%25E5%25AD%2597%7C%23\"");
    std::vector<EachColumn> in;
    std::vector<EachColumn> out;
    EXPECT_EQ(-1, compute_datax_info(in, out));

    in.resize(1);
    out.resize(28);
    in[0].value = in_str;
    EXPECT_EQ(0, compute_datax_info(in, out));
    for (size_t i = 0; i < out.size(); i++) {
        std::cout << out[i].value << std::endl;
    }
}

} // holmes
} // udw
} // bdg
/* vim: set ts=4 sw=4: */
