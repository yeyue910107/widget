#!/bin/sh

# {DAY} {HOUR} {MIN} {WORK_PATH} {HADOOP_HOME} {LIB_JARS_PATH} {JOB_NAME} {queue_name} {username,password} {zk_path}

if [ $# != 10 ]; then
	echo "running iqiyi_flash_cookie_map job, parameter size error != 10"
	exit 1
fi

DAY=$1
HOUR=$2
MIN=$3
WORK_PATH=$4
HADOOP_HOME=$5
LIB_JARS_PATH=$6
JOB_NAME=$7
QUEUE_NAME=$8
USER_PWD=$9
ZK_PARH=$10

NOW=`date +%F' '%H:'00:00' -d "$1 $2"`
LAST_HOUR_DAY=`date +%Y%m%d -d "${NOW} +0800 -1 hour"`
LAST_HOUR_HOUR=`date +%H -d "${NOW} +0800 -1 hour"`

if [ ${#DAY} -ne 8 ]; then
	echo "Date format error"
	exit 2
fi

if [ ${#HOUR} -ne 2 ]; then
	echo "HOUR format error"
	exit 3
fi

if [ ${#MIN} -ne 2 ]; then
	echo "MIN format error"
	exit 4
fi

cd ${WORK_PATH}/bin
tar -xf iqiyi_flash_cookie_map_antispam.tar

# check if last_hour's task was finished
while true
do
#online
#~/lib/queryengine-client/queryengine/bin/queryengine -f iqiyi_map_baiduid_check.hql --hivevar DAY=${DAY} --hivevar HOUR=${HOUR} > ${WORK_PATH}/bin/check_log
${QUERYENGINE_HOME}/bin/queryengine -f iqiyi_map_baiduid_check.hql --hivevar DAY=${DAY} --hivevar HOUR=${HOUR} > ${WORK_PATH}/bin/check_log
#offline
#cd /home/ns-lsp/tunningbox-9/udw/dtmetaHive/hive/bin/
#./hive -f ${WORK_PATH}/bin/cookie_map_check.hql --hivevar LAST_HOUR_DAY=${LAST_HOUR_DAY} --hivevar LAST_HOUR_HOUR=${LAST_HOUR_HOUR} > ${WORK_PATH}/bin/check_log
#sandbox
#/home/ns-lsp/queryengineSandBox/queryengine-client-1.6.11-online/queryengine/bin/queryengine -f cookie_map_check.hql --hivevar LAST_HOUR_DAY=${LAST_HOUR_DAY} --hivevar LAST_HOUR_HOUR=${LAST_HOUR_HOUR} > ${WORK_PATH}/bin/check_log
num=`cat ${WORK_PATH}/bin/check_log | wc -l`
if [ $num = 1 ]; then
break
fi
sleep 180
done

while true
do
#online
#~/lib/queryengine-client/queryengine/bin/queryengine -f cookie_map_check.hql --hivevar LAST_HOUR_DAY=${LAST_HOUR_DAY} --hivevar LAST_HOUR_HOUR=${LAST_HOUR_HOUR} > ${WORK_PATH}/bin/check_log
${QUERYENGINE_HOME}/bin/queryengine -f cookie_map_check.hql --hivevar LAST_HOUR_DAY=${LAST_HOUR_DAY} --hivevar LAST_HOUR_HOUR=${LAST_HOUR_HOUR} > ${WORK_PATH}/bin/check_log
#offline
#cd /home/ns-lsp/tunningbox-9/udw/dtmetaHive/hive/bin/
#./hive -f ${WORK_PATH}/bin/cookie_map_check.hql --hivevar LAST_HOUR_DAY=${LAST_HOUR_DAY} --hivevar LAST_HOUR_HOUR=${LAST_HOUR_HOUR} > ${WORK_PATH}/bin/check_log
#sandbox
#/home/ns-lsp/queryengineSandBox/queryengine-client-1.6.11-online/queryengine/bin/queryengine -f cookie_map_check.hql --hivevar LAST_HOUR_DAY=${LAST_HOUR_DAY} --hivevar LAST_HOUR_HOUR=${LAST_HOUR_HOUR} > ${WORK_PATH}/bin/check_log
num=`cat ${WORK_PATH}/bin/check_log | wc -l`
if [ $num = 1 ]; then
break
fi
sleep 180
done

#do the job
#online
#~/lib/queryengine-client/queryengine/bin/queryengine -f cookie_map.hql --hivevar DAY=${DAY} --hivevar HOUR=${HOUR} --hivevar LAST_HOUR_DAY=${LAST_HOUR_DAY} --hivevar LAST_HOUR_HOUR=${LAST_HOUR_HOUR} --hivevar WORK_PATH=${WORK_PATH}
${QUERYENGINE_HOME}/bin/queryengine -f cookie_map.hql --hivevar DAY=${DAY} --hivevar HOUR=${HOUR} --hivevar LAST_HOUR_DAY=${LAST_HOUR_DAY} --hivevar LAST_HOUR_HOUR=${LAST_HOUR_HOUR} --hivevar WORK_PATH=${WORK_PATH}
#offline
#/home/ns-lsp/tunningbox-9/udw/bin/queryengine -f cookie_map.hql --hivevar DAY=${DAY} --hivevar HOUR=${HOUR} --hivevar LAST_HOUR_DAY=${LAST_HOUR_DAY} --hivevar LAST_HOUR_HOUR=${LAST_HOUR_HOUR} --hivevar WORK_PATH=${WORK_PATH}
#cd /home/ns-lsp/tunningbox-9/udw/dtmetaHive/hive/bin/
#./hive -f ${WORK_PATH}/bin/cookie_map.hql --hivevar DAY=${DAY} --hivevar HOUR=${HOUR} --hivevar LAST_HOUR_DAY=${LAST_HOUR_DAY} --hivevar LAST_HOUR_HOUR=${LAST_HOUR_HOUR} --hivevar WORK_PATH=${WORK_PATH}
#sandbox
#/home/ns-lsp/queryengineSandBox/queryengine-client-1.6.11-online/queryengine/bin/queryengine -f cookie_map.hql --hivevar DAY=${DAY} --hivevar HOUR=${HOUR} --hivevar LAST_HOUR_DAY=${LAST_HOUR_DAY} --hivevar LAST_HOUR_HOUR=${LAST_HOUR_HOUR} --hivevar WORK_PATH=${WORK_PATH}

if [ $? -ne 0 ]
then
	echo "run iqiyi_flash_cookie_map error"
	exit 1
fi

cd -
